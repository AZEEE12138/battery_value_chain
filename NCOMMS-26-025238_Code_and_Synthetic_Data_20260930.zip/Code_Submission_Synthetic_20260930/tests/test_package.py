"""Contract tests for synthetic input and the preserved archived branch."""
import csv
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from run import load
from scripts.generate_synthetic import generate


class PackageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.nodes,cls.edges,cls.engine,cls.config=load()

    def test_synthetic_contract(self):
        self.assertEqual(len(self.nodes),108);self.assertEqual(len(self.edges),739)
        self.assertEqual(len(self.edges[['Source_Code','Target_Code']].drop_duplicates()),739)
        self.assertTrue((self.edges.Weight>0).all())
        self.assertTrue((self.edges.Source_Code!=self.edges.Target_Code).all())
        codes=set(self.nodes.Industry_Code)
        self.assertTrue(set(self.edges.Source_Code)|set(self.edges.Target_Code)<=codes)

    def test_matrix_round_trip(self):
        order=json.loads((ROOT/'data/node_order.json').read_text())
        with (ROOT/'data/adjacency_synthetic.csv').open() as f:
            rows=list(csv.reader(f))
        self.assertEqual(rows[0][1:],order);self.assertEqual([r[0] for r in rows[1:]],order)
        expected={(r.Source_Code,r.Target_Code):r.Weight for r in self.edges.itertuples()}
        nonzero=0
        for row in rows[1:]:
            for v,value in zip(order,row[1:]):
                x=float(value);nonzero+=x>0
                self.assertAlmostEqual(x,expected.get((row[0],v),0),places=7)
        self.assertEqual(nonzero,739)

    def test_fresh_generation_reproducible(self):
        with tempfile.TemporaryDirectory() as directory:
            generate(directory)
            for filename in ['nodes_synthetic.csv','edges_synthetic.csv','adjacency_synthetic.csv','node_order.json']:
                self.assertEqual((ROOT/'data'/filename).read_bytes(),(Path(directory)/filename).read_bytes())

    def test_reweighting_contract(self):
        from src.core.network_rewiring import rewire_network_to_target_BED
        for bed in [.3,.55,.9]:
            a,achieved,stats=rewire_network_to_target_BED(self.nodes,self.edges,bed,verbose=False)
            self.assertAlmostEqual(achieved,bed,places=12)
            self.assertAlmostEqual(a.Weight.sum(),self.edges.Weight.sum(),places=6)
            self.assertEqual(len(a),739)

    def test_preserved_legacy_attribute_contract(self):
        from src.core.cascade_failure import build_network_from_data
        from src.core.ev_shock_recovery import calculate_node_recovery_priority
        g=build_network_from_data(self.nodes,self.edges)
        self.assertEqual(len(g),108)
        # The archived builder stores lower-case total_weight; priority reads Total_Weight.
        self.assertIn('total_weight',g.nodes['36901']);self.assertNotIn('Total_Weight',g.nodes['36901'])
        before=calculate_node_recovery_priority('36901',g,g,set())
        g.nodes['36901']['total_weight']*=10
        self.assertEqual(before,calculate_node_recovery_priority('36901',g,g,set()))

    def test_archived_one_node_mode(self):
        import run_resilience_simulation
        self.assertTrue(run_resilience_simulation.LIMIT_ONE_RECOVERY_PER_STEP)
        self.assertEqual(self.config['max_cascade_rounds'],15)


if __name__=='__main__':unittest.main(verbosity=2)
