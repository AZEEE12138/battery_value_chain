"""Generate fresh synthetic inputs without opening any empirical file."""
import csv
import json
from pathlib import Path
import random

ROOT=Path(__file__).resolve().parents[1]


def generate(destination=None):
    dest=Path(destination) if destination else ROOT/'data'
    dest.mkdir(parents=True,exist_ok=True)
    config=json.loads((ROOT/'config/example_parameters.json').read_text())
    rng=random.Random(config['generator_seed'])
    codes=['36901','37111']+[str(10000+i) for i in range(1,107)]
    pairs={(codes[i],codes[(i+1)%108]) for i in range(108)}
    pairs.update(('36901',c) for c in codes[2:22])
    pairs.update((c,'36901') for c in codes[22:42])
    while len(pairs)<739:
        u,v=rng.sample(codes,2);pairs.add((u,v))
    weights={p:round(rng.lognormvariate(7,0.8),8) for p in sorted(pairs)}
    other=sum(w for (u,v),w in weights.items() if u=='36901' and v!='37111')
    weights['36901','37111']=other*config['initial_BED']/(1-config['initial_BED'])
    nodes=[]
    for i,c in enumerate(codes):
        out=[w for (u,v),w in weights.items() if u==c];inc=[w for (u,v),w in weights.items() if v==c]
        name='Synthetic battery role' if i==0 else 'Synthetic EV role' if i==1 else f'Synthetic sector {i-1:03d}'
        # The keyword exercises the archived material classifier, not a real sector identity.
        if 2<=i<16:name+=' \u91d1\u5c5e'
        nodes.append({'Industry_Code':c,'Node_Code':c,'Id':c,'Node_Name':name,'Abbreviation':f'S{i+1:03d}',
                      'Out_Degree':len(out),'In_Degree':len(inc),'Out_Weight':sum(out),'In_Weight':sum(inc),
                      'Total_Weight':sum(out)+sum(inc),'Data_Origin':'SYNTHETIC'})
    edges=[{'Source_Code':u,'Target_Code':v,'Source':u,'Target':v,'Weight':w,'Transactions':1,'Data_Origin':'SYNTHETIC'} for (u,v),w in sorted(weights.items())]
    for name,rows in [('nodes_synthetic.csv',nodes),('edges_synthetic.csv',edges)]:
        with (dest/name).open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
    with (dest/'adjacency_synthetic.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['source_id']+codes)
        for u in codes:writer.writerow([u]+[weights.get((u,v),0) for v in codes])
    (dest/'node_order.json').write_text(json.dumps(codes,indent=2),encoding='utf-8')
    return nodes,edges


if __name__=='__main__':
    generate();print('Generated synthetic 108-node / 739-edge inputs and matrix. No empirical inputs accessed.')
