# -*- coding: utf-8 -*-
"""
路径配置管理模块

功能:
- 统一管理项目中所有文件路径
- 自动检测项目根目录
- 确保跨平台兼容性（使用pathlib）
- 自动创建必要的目录

作者：Claude Code
日期：2025-12-05
"""

from pathlib import Path


class PathConfig:
    """
    路径配置管理类

    自动检测项目根目录并提供统一的路径访问接口
    """

    def __init__(self):
        """初始化路径配置"""
        # 自动检测项目根目录（从当前文件位置向上4级）
        self.base_dir = Path(__file__).resolve().parent.parent.parent.parent

        # 输入数据目录（新结构）
        self.data_inputs_dir = self.base_dir / 'data' / 'input' / 'inputs'
        self.data_outputs_dir = self.base_dir / 'data' / 'output' / 'outputs'

        # 输出结果目录（新结构）
        self.results_data_dir = self.base_dir / 'data' / 'output' / 'results_data'
        self.results_figures_dir = self.base_dir / 'rusult' / 'figure' / 'figures'

        # 日志目录（新结构，可选）
        self.logs_dir = self.base_dir / 'rusult' / 'report' / 'logs'

        # 确保所有目录存在
        self._ensure_directories()

    def _ensure_directories(self):
        """确保所有必需的目录存在"""
        directories = [
            self.data_inputs_dir,
            self.data_outputs_dir,
            self.results_data_dir,
            self.results_figures_dir,
            self.logs_dir
        ]

        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)

    def get_input_file(self, filename: str) -> Path:
        """
        获取输入数据文件路径

        参数:
            filename: 文件名（如 'battery_value_chain_nodes_recalculated.csv'）

        返回:
            完整的文件路径
        """
        return self.data_inputs_dir / filename

    def get_results_file(self, filename: str, subdir: str = 'data') -> Path:
        """
        获取结果文件路径

        参数:
            filename: 文件名
            subdir: 子目录类型 ('data' 或 'figures')

        返回:
            完整的文件路径
        """
        if subdir == 'data':
            return self.results_data_dir / filename
        elif subdir == 'figures':
            return self.results_figures_dir / filename
        else:
            raise ValueError(f"无效的subdir参数: {subdir}，必须是 'data' 或 'figures'")

    def __repr__(self):
        """返回PathConfig对象的字符串表示"""
        return (
            f"PathConfig(\n"
            f"  base_dir={self.base_dir},\n"
            f"  data_inputs={self.data_inputs_dir},\n"
            f"  data_outputs={self.data_outputs_dir},\n"
            f"  results_data={self.results_data_dir},\n"
            f"  results_figures={self.results_figures_dir}\n"
            f")"
        )


# 测试代码
if __name__ == '__main__':
    print("="*80)
    print("PathConfig 测试")
    print("="*80)

    # 创建PathConfig实例
    paths = PathConfig()

    # 打印配置信息
    print(paths)

    # 测试文件路径获取
    print("\n[测试文件路径]")
    nodes_path = paths.get_input_file('battery_value_chain_nodes_recalculated.csv')
    print(f"  节点文件: {nodes_path}")
    print(f"  存在: {nodes_path.exists()}")

    results_csv = paths.get_results_file('battery_chain_resilience_results_final.csv', 'data')
    print(f"  结果CSV: {results_csv}")

    figure_png = paths.get_results_file('robustness_vs_bed.png', 'figures')
    print(f"  图表PNG: {figure_png}")

    print("\n[目录创建验证]")
    print(f"  data/input/inputs: {paths.data_inputs_dir.exists()}")
    print(f"  data/output/outputs: {paths.data_outputs_dir.exists()}")
    print(f"  data/output/results_data: {paths.results_data_dir.exists()}")
    print(f"  rusult/figure/figures: {paths.results_figures_dir.exists()}")

    print("="*80)
