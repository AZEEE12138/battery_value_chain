# -*- coding: utf-8 -*-
"""
Supply stability policy hooks for dynamic resilience simulations.

Mechanisms:
- Contract floor (long-term contracts): enforce w(t) >= beta * w(t-1)
  on upstream -> battery edges.
- Early-warning smoothing: if an upstream node's outflow ratio falls below
  a threshold, slow down the edge weight decline to the battery node.
- Inventory buffer: divert a fraction of upstream shipment decrease to a
  buffer node S.
- Finance support: reduce effective profit loss for upstream nodes, lowering
  failure probability.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Set, Tuple

import pandas as pd
import networkx as nx


def _normalize_id(value: str) -> str:
    digits = "".join(ch for ch in str(value) if ch.isdigit())
    return digits if digits else str(value).strip()


@dataclass
class SupplyStabilityConfig:
    enable_contract_floor: bool = False
    contract_beta: float = 0.8

    enable_early_warning: bool = False
    warning_threshold: float = 0.7
    warning_slowdown: float = 0.4

    enable_buffer: bool = False
    buffer_gamma: float = 0.3
    buffer_node_id: str = "S_BUFFER"

    enable_finance_boost: bool = False
    finance_boost: float = 0.05


def load_key_upstream_material_codes(csv_path: Path | str) -> Set[str]:
    df = pd.read_csv(csv_path)
    col = "Industry_Code" if "Industry_Code" in df.columns else df.columns[0]
    codes = set()
    for value in df[col].dropna().astype(str):
        codes.add(_normalize_id(value))
    return codes


def resolve_upstream_nodes(nodes_df: pd.DataFrame, upstream_codes: Set[str]) -> Set[str]:
    if not upstream_codes:
        return set()
    if "Industry_Code" in nodes_df.columns:
        return set(_normalize_id(v) for v in nodes_df["Industry_Code"].astype(str) if _normalize_id(v) in upstream_codes)
    if "Node_Code" in nodes_df.columns:
        return set(_normalize_id(v) for v in nodes_df["Node_Code"].astype(str) if _normalize_id(v) in upstream_codes)
    if "Id" in nodes_df.columns:
        return set(_normalize_id(v) for v in nodes_df["Id"].astype(str) if _normalize_id(v) in upstream_codes)
    return set()


def list_upstream_battery_edges(
    G: nx.DiGraph,
    upstream_nodes: Set[str],
    battery_node: str,
) -> List[Tuple[str, str]]:
    edges: List[Tuple[str, str]] = []
    if not upstream_nodes or not G.has_node(battery_node):
        return edges
    for u in upstream_nodes:
        if G.has_edge(u, battery_node):
            edges.append((u, battery_node))
    return edges


def apply_contract_floor(
    G_current: nx.DiGraph,
    G_prev: nx.DiGraph,
    edges: Sequence[Tuple[str, str]],
    beta: float,
) -> int:
    if not edges or beta <= 0:
        return 0
    updated = 0
    for u, v in edges:
        if not (G_prev.has_edge(u, v) and G_current.has_edge(u, v)):
            continue
        prev_w = G_prev[u][v].get("weight", 0.0)
        cur_w = G_current[u][v].get("weight", 0.0)
        floor_w = beta * prev_w
        if cur_w < floor_w:
            G_current[u][v]["weight"] = floor_w
            updated += 1
    return updated


def apply_early_warning_smoothing(
    G_current: nx.DiGraph,
    G_prev: nx.DiGraph,
    G_original: nx.DiGraph,
    upstream_nodes: Set[str],
    battery_node: str,
    threshold: float,
    slowdown: float,
) -> int:
    if not upstream_nodes or slowdown <= 0:
        return 0
    updated = 0
    for u in upstream_nodes:
        if not G_original.has_node(u):
            continue
        original_out = sum(G_original[u][v].get("weight", 0.0) for v in G_original.successors(u))
        if original_out <= 0:
            continue
        current_out = sum(
            G_current[u][v].get("weight", 0.0)
            for v in G_current.successors(u)
            if G_current.has_node(v)
        )
        ratio = current_out / original_out if original_out > 0 else 1.0
        if ratio > threshold:
            continue
        if not (G_prev.has_edge(u, battery_node) and G_current.has_edge(u, battery_node)):
            continue
        prev_w = G_prev[u][battery_node].get("weight", 0.0)
        cur_w = G_current[u][battery_node].get("weight", 0.0)
        if cur_w >= prev_w:
            continue
        adjusted = prev_w - slowdown * (prev_w - cur_w)
        if adjusted > cur_w:
            G_current[u][battery_node]["weight"] = adjusted
            updated += 1
    return updated


def apply_inventory_buffer(
    G_current: nx.DiGraph,
    G_prev: nx.DiGraph,
    upstream_nodes: Set[str],
    battery_node: str,
    buffer_node_id: str,
    gamma: float,
) -> int:
    if not upstream_nodes or gamma <= 0:
        return 0
    if not G_current.has_node(buffer_node_id):
        G_current.add_node(buffer_node_id, label="Supply Buffer", industry_code="BUFFER")

    updated = 0
    for u in upstream_nodes:
        if not (G_prev.has_edge(u, battery_node) and G_current.has_edge(u, battery_node)):
            continue
        prev_w = G_prev[u][battery_node].get("weight", 0.0)
        cur_w = G_current[u][battery_node].get("weight", 0.0)
        delta = prev_w - cur_w
        if delta <= 0:
            continue
        add_w = gamma * delta
        if G_current.has_edge(u, buffer_node_id):
            G_current[u][buffer_node_id]["weight"] += add_w
        else:
            G_current.add_edge(u, buffer_node_id, weight=add_w)
        updated += 1
    return updated


def adjust_profit_loss_for_finance(
    profit_loss: float,
    node_id: str,
    finance_boost: float,
    upstream_nodes: Set[str],
) -> float:
    if finance_boost <= 0 or node_id not in upstream_nodes:
        return profit_loss
    adjusted = profit_loss - finance_boost
    if adjusted < 0:
        return 0.0
    if adjusted > 1.0:
        return 1.0
    return adjusted
