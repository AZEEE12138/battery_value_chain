# -*- coding: utf-8 -*-
"""
网络重连算法 - 生成具有目标BED值的模拟网络

功能：
通过调整边权重，生成一系列具有不同BED特征值的模拟网络
BED = (蓄电池→EV的边权重) / (蓄电池总出度权重)

约束条件：
1. 保持蓄电池节点的Out_Weight守恒
2. 保持其他节点的In_Weight尽可能接近原值
3. 达到目标BED值

更新日期：2025-12-22
- 新增双向守恒网络重连算法


日期：2025-12-03
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Dict

# 导入双向权重守恒验证器
from src.core.weight_conservation_validator import WeightConservationValidator

# 关键节点ID
BATTERY_NODE = '36901'
EV_NODE = '37111'

def _edge_code_cols(edges_df: pd.DataFrame) -> Tuple[str, str]:
    source_col = 'Source_Code' if 'Source_Code' in edges_df.columns else 'Source'
    target_col = 'Target_Code' if 'Target_Code' in edges_df.columns else 'Target'
    return source_col, target_col



def calculate_current_BED(edges_df: pd.DataFrame, battery_node: str, ev_node: str) -> Tuple[float, float, float]:
    """
    ???????BED??
    """
    source_col, target_col = _edge_code_cols(edges_df)
    src_series = edges_df[source_col].astype(str)
    tgt_series = edges_df[target_col].astype(str)

    battery_to_ev = edges_df[(src_series == str(battery_node)) & (tgt_series == str(ev_node))]
    if len(battery_to_ev) == 0:
        raise ValueError(f"??????({battery_node}) ? EV({ev_node})??")

    weight_battery_to_ev = battery_to_ev['Weight'].iloc[0]
    battery_out_edges = edges_df[src_series == str(battery_node)]
    total_out_weight = battery_out_edges['Weight'].sum()
    BED = weight_battery_to_ev / total_out_weight if total_out_weight > 0 else 0.0

    return BED, weight_battery_to_ev, total_out_weight


def rewire_network_to_target_BED(
    nodes_df: pd.DataFrame,
    edges_df: pd.DataFrame,
    target_BED: float,
    battery_node: str = BATTERY_NODE,
    ev_node: str = EV_NODE,
    verbose: bool = True,
    validate_bilateral_conservation: bool = True  # ⭐ 新增：是否验证双向守恒
) -> Tuple[pd.DataFrame, float, Dict]:
    """
    通过边权重调整生成目标BED值的网络

    算法步骤:
    1. 计算当前BED值
    2. 计算目标权重: W_target = target_BED × Out_Weight(battery)
    3. 调整蓄电池→EV边权重为W_target
    4. 按比例调整蓄电池→其他节点的边权重以维持Out_Weight守恒
    5. 验证守恒性和BED值

    参数:
        nodes_df: 节点数据
        edges_df: 边数据
        target_BED: 目标BED值 (0.10-1.00)
        battery_node: 蓄电池节点ID
        ev_node: EV节点ID
        verbose: 是否打印详细信息

    返回:
        (调整后的edges_df, 实际达到的BED值, 统计信息字典)
    """

    if verbose:
        print(f"\n{'='*80}")
        print(f"网络重连算法: 目标BED = {target_BED:.3f}")
        print(f"{'='*80}")

    # 创建副本避免修改原数据
    edges_adjusted = edges_df.copy()

    source_col, target_col = _edge_code_cols(edges_adjusted)
    src_series = edges_adjusted[source_col].astype(str)
    tgt_series = edges_adjusted[target_col].astype(str)

    # 确保Weight列是float类型,避免pandas FutureWarning
    if edges_adjusted['Weight'].dtype != 'float64':
        edges_adjusted['Weight'] = edges_adjusted['Weight'].astype('float64')

    # 步骤1: 计算当前BED
    BED_current, weight_current, total_out_weight = calculate_current_BED(
        edges_adjusted, battery_node, ev_node
    )

    if verbose:
        print(f"\n[步骤1] 当前网络状态:")
        print(f"  当前BED: {BED_current:.6f}")
        print(f"  蓄电池→EV权重: {weight_current:,.0f}")
        print(f"  蓄电池总出度权重: {total_out_weight:,.0f}")

    # 步骤2: 计算目标权重
    weight_target = target_BED * total_out_weight

    if verbose:
        print(f"\n[步骤2] 目标权重计算:")
        print(f"  目标BED: {target_BED:.3f}")
        print(f"  目标权重(蓄电池→EV): {weight_target:,.0f}")
        print(f"  权重变化: {weight_target - weight_current:+,.0f}")

    # 步骤3: 调整蓄电池→EV边权重
    battery_to_ev_idx = edges_adjusted[(src_series == str(battery_node)) & (tgt_series == str(ev_node))].index

    edges_adjusted.loc[battery_to_ev_idx, 'Weight'] = weight_target

    # 步骤4: 调整蓄电池→其他节点的边权重以维持守恒
    # 找到蓄电池的所有其他出边
    other_out_edges_idx = edges_adjusted[(src_series == str(battery_node)) & (tgt_series != str(ev_node))].index

    if len(other_out_edges_idx) > 0:
        # 计算其他出边需要分配的总权重
        weight_remaining = total_out_weight - weight_target

        # 允许小的数值误差（浮点精度问题）
        if weight_remaining < -1.0:  # 容忍1单位的误差
            raise ValueError(f"目标BED={target_BED}超过1.0，无法实现")

        # 获取其他出边的原始权重
        other_weights_original = edges_adjusted.loc[other_out_edges_idx, 'Weight'].values
        total_other_weights = other_weights_original.sum()

        # 修复: 设置最小权重阈值防止权重归零，高BED时特殊处理确保守恒性
        MIN_WEIGHT_RATIO = 0.05  # ⭐ 降低到0.05，减少对高BED的干扰

        # 确保weight_remaining不为负
        if weight_remaining < 0:
            weight_target = total_out_weight
            weight_remaining = 0.0
            actual_BED = 1.0
            if verbose:
                print(f"[警告] 目标BED={target_BED:.2f}超过1.0，调整为BED=1.0")

        # ⭐ 极端BED特殊处理
        if target_BED >= 0.95:
            # 高BED时：不强制保留最小权重比例，仅保留1单位防止数值不稳定
            min_total_weight = 1.0

            if weight_remaining < min_total_weight:
                # 不调整weight_target，保持BED精度和权重守恒
                scaling_factor = min_total_weight / total_other_weights if total_other_weights > 0 else 0
            else:
                scaling_factor = weight_remaining / total_other_weights if total_other_weights > 0 else 0
        else:
            # 中低BED时：保持MIN_WEIGHT_RATIO保护
            min_total_weight = total_other_weights * MIN_WEIGHT_RATIO

            if weight_remaining < min_total_weight:
                weight_target = total_out_weight - min_total_weight
                weight_remaining = min_total_weight
                actual_BED = weight_target / total_out_weight
                if verbose:
                    print(f"[警告] 目标BED={target_BED:.2f}会导致其他边权重过低")
                    print(f"       实际BED调整为{actual_BED:.2f}以保持网络连通性")

            scaling_factor = weight_remaining / total_other_weights if total_other_weights > 0 else 0

        if total_other_weights > 0:
            # 按原始权重比例重新分配
            other_weights_adjusted = other_weights_original * scaling_factor
            edges_adjusted.loc[other_out_edges_idx, 'Weight'] = other_weights_adjusted

            if verbose:
                print(f"\n[步骤3-4] 边权重调整:")
                print(f"  蓄电池→EV: {weight_current:,.0f} → {weight_target:,.0f}")
                print(f"  其他出边数量: {len(other_out_edges_idx)}")
                print(f"  其他出边总权重: {total_other_weights:,.0f} → {weight_remaining:,.0f}")
                print(f"  缩放系数: {scaling_factor:.6f}")
        else:
            if verbose:
                print(f"\n[警告] 其他出边原始权重为0，无法按比例调整")

    # 步骤5: 验证守恒性和BED值
    BED_achieved, weight_achieved, total_out_achieved = calculate_current_BED(
        edges_adjusted, battery_node, ev_node
    )

    # 验证Out_Weight守恒
    conservation_error = abs(total_out_achieved - total_out_weight)
    conservation_error_pct = (conservation_error / total_out_weight) * 100 if total_out_weight > 0 else 0

    # 验证BED准确性
    BED_error = abs(BED_achieved - target_BED)
    BED_error_pct = (BED_error / target_BED) * 100 if target_BED > 0 else 0

    if verbose:
        print(f"\n[步骤5] 验证结果:")
        print(f"  实际BED: {BED_achieved:.6f}")
        print(f"  目标BED: {target_BED:.6f}")
        print(f"  BED误差: {BED_error:.6f} ({BED_error_pct:.4f}%)")
        print(f"  Out_Weight守恒验证:")
        print(f"    调整前: {total_out_weight:,.0f}")
        print(f"    调整后: {total_out_achieved:,.0f}")
        print(f"    误差: {conservation_error:,.2f} ({conservation_error_pct:.6f}%)")

    # ⭐ 新增：双向权重守恒验证
    if validate_bilateral_conservation:
        validator = WeightConservationValidator()
        conservation_results = validator.validate_bilateral_conservation(
            edges_df, edges_adjusted, verbose=verbose
        )
    else:
        conservation_results = None

    # 统计信息
    stats = {
        'target_BED': target_BED,
        'achieved_BED': BED_achieved,
        'BED_error': BED_error,
        'BED_error_pct': BED_error_pct,
        'weight_battery_to_ev_original': weight_current,
        'weight_battery_to_ev_adjusted': weight_achieved,
        'total_out_weight_original': total_out_weight,
        'total_out_weight_adjusted': total_out_achieved,
        'conservation_error': conservation_error,
        'conservation_error_pct': conservation_error_pct,
        'num_other_out_edges': len(other_out_edges_idx),
        'bilateral_conservation': conservation_results  # ⭐ 新增：双向守恒验证结果
    }

    if verbose and not validate_bilateral_conservation:
        # 仅当未启用双向验证时才打印旧版本的验证信息
        if conservation_error_pct < 0.001 and BED_error_pct < 1.0:
            print(f"\n[成功] 网络重连完成，守恒性和BED准确性验证通过")
        else:
            print(f"\n[警告] 存在较大误差:")
            if conservation_error_pct >= 0.001:
                print(f"  - Out_Weight守恒误差: {conservation_error_pct:.4f}%")
            if BED_error_pct >= 1.0:
                print(f"  - BED准确性误差: {BED_error_pct:.4f}%")
        print(f"{'='*80}\n")

    return edges_adjusted, BED_achieved, stats


def test_rewiring_algorithm():
    """
    测试网络重连算法

    测试用例: BED = 0.1, 0.5, 1.0
    """
    import sys
    BASE_DIR = Path(__file__).resolve().parent.parent.parent
    sys.path.insert(0, str(BASE_DIR))

    from src.utils.path_config import PathConfig

    print("="*80)
    print("网络重连算法测试")
    print("="*80)

    # 使用PathConfig加载数据
    paths = PathConfig()
    nodes_path = paths.get_input_file('battery_value_chain_nodes_recalculated.csv')
    edges_path = paths.get_input_file('battery_value_chain_edges.csv')

    print(f"\n[数据加载]")
    print(f"  节点文件: {nodes_path}")
    print(f"  边文件: {edges_path}")

    nodes_df = pd.read_csv(nodes_path, encoding='utf-8-sig')
    edges_df = pd.read_csv(edges_path, encoding='utf-8-sig')

    print(f"  节点数: {len(nodes_df)}")
    print(f"  边数: {len(edges_df)}")

    # 测试用例
    test_BED_values = [0.1, 0.5, 1.0]

    results = []

    for target_BED in test_BED_values:
        edges_adjusted, BED_achieved, stats = rewire_network_to_target_BED(
            nodes_df, edges_df, target_BED, verbose=True
        )

        results.append({
            'Target_BED': target_BED,
            'Achieved_BED': BED_achieved,
            'BED_Error': stats['BED_error'],
            'BED_Error_Pct': stats['BED_error_pct'],
            'Conservation_Error_Pct': stats['conservation_error_pct'],
            'Battery_to_EV_Weight': stats['weight_battery_to_ev_adjusted'],
            'Total_Out_Weight': stats['total_out_weight_adjusted']
        })

    # 输出测试结果汇总
    results_df = pd.DataFrame(results)

    print("\n" + "="*80)
    print("测试结果汇总")
    print("="*80)
    print(results_df.to_string(index=False))
    print("="*80)

    # 保存测试结果到results目录
    output_file = paths.results_data_dir / 'rewiring_test_results.csv'
    results_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"\n测试结果已保存: {output_file}")

    return results_df


if __name__ == '__main__':
    # 运行测试
    test_rewiring_algorithm()
