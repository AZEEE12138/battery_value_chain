#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
改进的资源回收政策模块

改进点:
1. 增强的节点查找机制（支持短代码和完整格式）
2. 详细的连接日志记录（成功/失败/原因）
3. 自动验证网络中的可用节点
4. 连接边的详细统计和导出功能


日期：2025-12-16
"""

import networkx as nx
import pandas as pd
from typing import Tuple, Dict, List, Optional
from pathlib import Path
import sys
import re
from src.utils.path_config import PathConfig


class RecyclingEdgeLogger:
    """回收边连接日志记录器"""

    def __init__(self):
        self.success_edges = []  # 成功添加的边
        self.failed_edges = []   # 失败的边
        self.warnings = []        # 警告信息

    def log_success(self, edge_num: int, target_code: str, source_code: str,
                   target_full: str, source_full: str, weight: float, sector: str):
        """记录成功添加的边"""
        self.success_edges.append({
            'edge_num': edge_num,
            'target_code': target_code,
            'source_code': source_code,
            'target_full_id': target_full,
            'source_full_id': source_full,
            'weight': weight,
            'sector': sector,
            'status': 'SUCCESS'
        })

    def log_failure(self, edge_num: int, target_code: str, source_code: str,
                   reason: str, sector: str):
        """记录失败的边"""
        self.failed_edges.append({
            'edge_num': edge_num,
            'target_code': target_code,
            'source_code': source_code,
            'reason': reason,
            'sector': sector,
            'status': 'FAILED'
        })

    def log_warning(self, message: str):
        """记录警告信息"""
        self.warnings.append(message)

    def get_summary(self) -> Dict:
        """获取统计摘要"""
        return {
            'total_attempts': len(self.success_edges) + len(self.failed_edges),
            'successful': len(self.success_edges),
            'failed': len(self.failed_edges),
            'success_rate': len(self.success_edges) / (len(self.success_edges) + len(self.failed_edges))
                           if (len(self.success_edges) + len(self.failed_edges)) > 0 else 0
        }

    def export_to_dataframe(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """导出为DataFrame"""
        df_success = pd.DataFrame(self.success_edges) if self.success_edges else pd.DataFrame()
        df_failed = pd.DataFrame(self.failed_edges) if self.failed_edges else pd.DataFrame()
        return df_success, df_failed

    def print_summary(self):
        """打印摘要统计"""
        summary = self.get_summary()
        print(f"\n{'='*80}")
        print(f"回收边连接统计摘要")
        print(f"{'='*80}")
        print(f"  尝试连接总数: {summary['total_attempts']}")
        print(f"  成功连接数: {summary['successful']}")
        print(f"  失败连接数: {summary['failed']}")
        print(f"  成功率: {summary['success_rate']*100:.1f}%")

        if self.failed_edges:
            print(f"\n失败连接详情:")
            failure_reasons = {}
            for failed in self.failed_edges:
                reason = failed['reason']
                failure_reasons[reason] = failure_reasons.get(reason, 0) + 1

            for reason, count in failure_reasons.items():
                print(f"  - {reason}: {count} 条边")

        print(f"{'='*80}\n")


def _find_node_in_graph_enhanced(G: nx.DiGraph, node_code: str, logger: RecyclingEdgeLogger = None) -> Optional[str]:
    """
    增强的节点查找函数，支持两种格式：
    - '36901'（仅代码）
    - '36901'（完整格式）

    参数：
        G: 网络图
        node_code: 节点代码（短格式或完整格式）
        logger: 日志记录器（可选）

    返回：
        str: 找到的完整节点ID，如果未找到则返回None
    """
    # 确保node_code是字符串
    node_code = str(node_code)

    # 优先查找完整格式
    if G.has_node(node_code):
        return node_code

    # 如果是短格式，搜索包含该代码的节点
    matches = []
    for node in G.nodes():
        # 确保node也是字符串
        node_str = str(node)
        # 检查节点是否以 "代码_" 开头
        if node_str.startswith(node_code + '_'):
            matches.append(node)

    if len(matches) == 0:
        if logger:
            logger.log_warning(f"节点 {node_code} 在网络中不存在")
        return None
    elif len(matches) == 1:
        return matches[0]
    else:
        # 多个匹配，返回第一个并记录警告
        if logger:
            logger.log_warning(f"节点代码 {node_code} 匹配到多个节点: {matches}，使用第一个")
        return matches[0]


def verify_recycling_paths(G: nx.DiGraph, recycling_paths: List[Tuple],
                           max_loops: int = None) -> pd.DataFrame:
    """
    验证回收路径中的节点是否在网络中存在

    参数：
        G: 网络图
        recycling_paths: 回收路径列表 [(target, source, sector, multiplier), ...]
        max_loops: 只验证前 max_loops 条路径（默认全部）

    返回：
        验证结果DataFrame，包含每条路径的验证状态
    """
    logger = RecyclingEdgeLogger()
    results = []

    paths_to_check = recycling_paths[:max_loops] if max_loops else recycling_paths

    for i, path in enumerate(paths_to_check):
        target_code = path[0]
        source_code = path[1]
        sector = path[2] if len(path) > 2 else 'Unknown'

        target_full = _find_node_in_graph_enhanced(G, target_code, logger)
        source_full = _find_node_in_graph_enhanced(G, source_code, logger)

        result = {
            'edge_num': i + 1,
            'target_code': target_code,
            'source_code': source_code,
            'sector': sector,
            'target_exists': target_full is not None,
            'source_exists': source_full is not None,
            'target_full_id': target_full if target_full else 'NOT_FOUND',
            'source_full_id': source_full if source_full else 'NOT_FOUND',
            'can_connect': (target_full is not None) and (source_full is not None)
        }

        results.append(result)

    df = pd.DataFrame(results)

    # 打印摘要
    print(f"\n{'='*80}")
    print(f"回收路径验证结果（共 {len(paths_to_check)} 条路径）")
    print(f"{'='*80}")
    print(f"  可连接路径: {df['can_connect'].sum()} 条 ({df['can_connect'].sum()/len(df)*100:.1f}%)")
    print(f"  目标节点不存在: {(~df['target_exists']).sum()} 条")
    print(f"  源节点不存在: {(~df['source_exists']).sum()} 条")
    print(f"  双节点均不存在: {((~df['target_exists']) & (~df['source_exists'])).sum()} 条")

    if (~df['can_connect']).sum() > 0:
        print(f"\n不可连接路径详情:")
        failed_df = df[~df['can_connect']]
        for idx, row in failed_df.iterrows():
            reason = []
            if not row['target_exists']:
                reason.append(f"目标节点 {row['target_code']} 不存在")
            if not row['source_exists']:
                reason.append(f"源节点 {row['source_code']} 不存在")
            print(f"  边 {row['edge_num']}: {', '.join(reason)}")

    print(f"{'='*80}\n")

    return df


def _pick_column(columns: List[str], candidates: List[str]) -> Optional[str]:
    """Pick the first matching column name from candidates (case-insensitive, substring fallback)."""
    cols = list(columns)
    lower_map = {c.lower(): c for c in cols}
    for cand in candidates:
        key = cand.lower()
        if key in lower_map:
            return lower_map[key]
    for cand in candidates:
        key = cand.lower()
        for col in cols:
            if key in col.lower():
                return col
    return None


def load_recycling_edges_from_csv(
    csv_path: Path,
    profit_allocation: Dict[str, float] = None,
    use_first_three_cols: bool = True
) -> List[Tuple[str, str, str, float]]:
    """
    Load recycling edges from a CSV file that includes source, target, and edge type.

    By default, it uses the first three columns as:
      1) source, 2) target, 3) edge_type
    You can disable this behavior and rely on column name matching instead.

    Expected columns (flexible matching):
      - source/start/from/起始节点/起点
      - target/to/end/目标节点/终点
      - edge_type/type/category/sector/边类型/类型
    Returns tuples in the internal format:
      (target, source, sector, multiplier)
    """
    df = pd.read_csv(csv_path, encoding='utf-8-sig')
    cols = list(df.columns)

    source_col = None
    target_col = None
    type_col = None

    if use_first_three_cols:
        if len(cols) < 2:
            raise ValueError(f"CSV至少需要2列(起始/目标): {csv_path}")
        source_col = cols[0]
        target_col = cols[1]
        type_col = cols[2] if len(cols) >= 3 else None
    else:
        source_col = _pick_column(cols, [
            'source', 'start', 'from', 'src', '起始节点', '起点'
        ])
        target_col = _pick_column(cols, [
            'target', 'to', 'end', 'dst', '目标节点', '终点'
        ])
        type_col = _pick_column(cols, [
            'edge_type', 'type', 'category', 'sector', '边类型', '类型'
        ])

        if source_col is None or target_col is None:
            raise ValueError(f"CSV缺少起始/目标列: {csv_path} (columns={cols})")

    if profit_allocation is None:
        # Default for closed-loop core edges (方案A: 回收边与原边权重相近)
        profit_allocation = {
            'second-life': 1.5,           # 梯次利用：价值保留度高
            'material recycling': 1.0,    # 材料回收：基准价值
            'secondary material': 0.8,    # 二次材料：价值略低
            'second life': 1.5            # 兼容别名
        }

    # Try to map node names/abbreviations to node IDs (nodes.csv)
    weight_map, label_map, abbr_map = _load_node_profit_weights(PathConfig().base_dir)

    paths = []
    for _, row in df.iterrows():
        source_raw = str(row[source_col]).strip()
        target_raw = str(row[target_col]).strip()

        source_code = _resolve_node_id(source_raw, weight_map, label_map, abbr_map) or source_raw
        target_code = _resolve_node_id(target_raw, weight_map, label_map, abbr_map) or target_raw

        edge_type = str(row[type_col]).strip() if type_col else 'DR'

        edge_key = edge_type.lower().strip()
        multiplier = profit_allocation.get(edge_key, profit_allocation.get(edge_type, 1.0))

        paths.append((target_code, source_code, edge_type, multiplier))

    return paths


def _load_node_profit_weights(base_dir: Path) -> Tuple[Dict[str, float], Dict[str, str], Dict[str, str]]:
    """Load node total profit weights (Total_Weight) and label/abbr maps from nodes.csv."""
    node_file = base_dir / 'data' / 'input' / 'legacy' / 'original_data' / 'nodes.csv'
    if not node_file.exists():
        return {}, {}, {}
    df = pd.read_csv(node_file, encoding='utf-8-sig')
    if 'Id' not in df.columns or 'Total_Weight' not in df.columns:
        return {}, {}, {}

    df['Id'] = df['Id'].astype(str)
    weight_map = dict(zip(df['Id'], df['Total_Weight'].astype(float)))

    label_map = {}
    if 'Label' in df.columns:
        label_map = {str(v).strip().lower(): k for k, v in zip(df['Id'], df['Label']) if pd.notna(v)}

    abbr_map = {}
    if 'Abbreviation' in df.columns:
        abbr_map = {str(v).strip().lower(): k for k, v in zip(df['Id'], df['Abbreviation']) if pd.notna(v)}

    return weight_map, label_map, abbr_map


def _resolve_node_id(code: str,
                     weight_map: Dict[str, float],
                     label_map: Dict[str, str],
                     abbr_map: Dict[str, str]) -> Optional[str]:
    """Resolve node code/name/abbr to numeric node ID string."""
    if code is None:
        return None
    s = str(code).strip()
    if s in weight_map:
        return s
    s_lower = s.lower()
    if s_lower in label_map:
        return label_map[s_lower]
    if s_lower in abbr_map:
        return abbr_map[s_lower]
    m = re.match(r'^(\\d+)', s)
    if m and m.group(1) in weight_map:
        return m.group(1)
    return None


def get_default_recycling_paths(ev_node: str, battery_node: str, profit_allocation: Dict[str, float]) -> List[Tuple[str, str, str, float]]:
    """Return default recycling paths list."""
    return [
        # 1-5: EV -> battery
        (ev_node, battery_node, 'EV', profit_allocation['EV']),
        (ev_node, '36131', 'EV', profit_allocation['EV']),
        (ev_node, '35103', 'EV', profit_allocation['EV']),
        (ev_node, '34541', 'EV', profit_allocation['EV']),
        (ev_node, '33111', 'EV', profit_allocation['EV']),

        # 6-10: battery -> materials
        (battery_node, '28199', 'DES', profit_allocation['DES']),
        (battery_node, '33401', 'DES', profit_allocation['DES']),
        (battery_node, '32809', 'DES', profit_allocation['DES']),
        (battery_node, '33111', 'DES', profit_allocation['DES']),
        (battery_node, '28221', 'DES', profit_allocation['DES']),

        # 11-15: materials loop
        ('28199', '28212', 'DR', profit_allocation['DR']),
        ('33401', '33509', 'DR', profit_allocation['DR']),
        ('32809', '29201', 'DR', profit_allocation['DR']),
        ('33111', '33143', 'DR', profit_allocation['DR']),
        ('28221', '28299', 'DR', profit_allocation['DR']),

        # 16-20
        ('36131', '33401', 'DR', profit_allocation['DR']),
        ('35103', '33111', 'DR', profit_allocation['DR']),
        ('34541', '33111', 'DR', profit_allocation['DR']),
        ('33611', '33401', 'DR', profit_allocation['DR']),
        ('32705', '28199', 'DR', profit_allocation['DR']),

        # 21-30: EV -> upstream materials
        (ev_node, '33401', 'EV', profit_allocation['EV']),
        (ev_node, '32809', 'EV', profit_allocation['EV']),
        (ev_node, '32201', 'EV', profit_allocation['EV']),
        (ev_node, '32211', 'EV', profit_allocation['EV']),
        (ev_node, '28199', 'EV', profit_allocation['EV']),
        (ev_node, '33121', 'EV', profit_allocation['EV']),
        (ev_node, '34521', 'EV', profit_allocation['EV']),
        (ev_node, '34531', 'EV', profit_allocation['EV']),
        (ev_node, '36121', 'EV', profit_allocation['EV']),
        (ev_node, '27199', 'EV', profit_allocation['EV']),

        # 31-40: battery -> more materials
        (battery_node, '32211', 'DES', profit_allocation['DES']),
        (battery_node, '32201', 'DES', profit_allocation['DES']),
        (battery_node, '33121', 'DES', profit_allocation['DES']),
        (battery_node, '27219', 'DES', profit_allocation['DES']),
        (battery_node, '28121', 'DES', profit_allocation['DES']),
        (battery_node, '32102', 'DES', profit_allocation['DES']),
        (battery_node, '33131', 'DES', profit_allocation['DES']),
        (battery_node, '36121', 'DES', profit_allocation['DES']),
        (battery_node, '34531', 'DES', profit_allocation['DES']),
        (battery_node, '34521', 'DES', profit_allocation['DES']),

        # 41-50: material-to-material
        ('28199', '27219', 'DR', profit_allocation['DR']),
        ('33401', '33131', 'DR', profit_allocation['DR']),
        ('32809', '27219', 'DR', profit_allocation['DR']),
        ('32211', '32102', 'DR', profit_allocation['DR']),
        ('32201', '33111', 'DR', profit_allocation['DR']),
        ('33121', '33111', 'DR', profit_allocation['DR']),
        ('33131', '33401', 'DR', profit_allocation['DR']),
        ('32102', '32211', 'DR', profit_allocation['DR']),
        ('28121', '28199', 'DR', profit_allocation['DR']),
        ('27219', '28199', 'DR', profit_allocation['DR']),

        # 51-60: material -> battery (closed-loop)
        ('32211', battery_node, 'DR', profit_allocation['DR'] * 2.0),
        ('33401', battery_node, 'DR', profit_allocation['DR'] * 2.0),
        ('28199', battery_node, 'DR', profit_allocation['DR'] * 2.0),
        ('32809', battery_node, 'DR', profit_allocation['DR'] * 2.0),
        ('32201', battery_node, 'DR', profit_allocation['DR'] * 1.5),
        ('32102', battery_node, 'DR', profit_allocation['DR'] * 2.5),
        ('33131', battery_node, 'DR', profit_allocation['DR'] * 1.5),
        ('28121', battery_node, 'DR', profit_allocation['DR'] * 1.5),
        ('33121', battery_node, 'DR', profit_allocation['DR'] * 1.0),
        ('36131', battery_node, 'DR', profit_allocation['DR'] * 1.0),

        # 61-70: supplemental
        ('36121', '33401', 'DR', profit_allocation['DR']),
        ('27199', '27219', 'DR', profit_allocation['DR']),
        ('34531', '33111', 'DR', profit_allocation['DR']),
        ('34521', '32201', 'DR', profit_allocation['DR']),
        (ev_node, '32102', 'EV', profit_allocation['EV'] * 0.8),
        (ev_node, '28121', 'EV', profit_allocation['EV'] * 0.8),
        (ev_node, '27219', 'EV', profit_allocation['EV'] * 0.7),
        ('35103', battery_node, 'DR', profit_allocation['DR'] * 0.8),
        ('34541', battery_node, 'DR', profit_allocation['DR'] * 0.8),
        ('27199', battery_node, 'DR', profit_allocation['DR'] * 0.5),
    ]

def add_recycling_loops_strategy2_improved(
    G: nx.DiGraph,
    num_loops: int = None,  # None表示添加所有可用回收边
    recycling_intensity: float = 0.1,
    battery_node: str = '36901',
    ev_node: str = '37111',
    retired_battery_price: float = 138.0,
    profit_allocation: Dict[str, float] = None,
    verbose: bool = True,
    export_log: bool = False,
    log_path: Path = None,
    custom_paths: List[Tuple[str, str, str, float]] = None
) -> Tuple[nx.DiGraph, Dict]:
    """
    改进的策略2回收边添加函数

    新增功能:
    1. 详细的连接日志记录（成功/失败/原因）
    2. 自动跳过不存在的节点，继续连接后续可用边
    3. 连接统计和导出功能
    4. 更详细的控制台输出
    5. 支持添加所有可用回收边（num_loops=None）

    参数：
        G: 原始网络图（DiGraph）
        num_loops: 要添加的内循环数量（0-87，None=全部添加）
        recycling_intensity: 回收物质流强度（0.0-1.0）
        battery_node: 蓄电池制造节点代码（默认36901）
        ev_node: EV制造节点代码（默认37111）
        retired_battery_price: 退役电池价格参数（US$/kWh）
        profit_allocation: 回收价值系数字典（方案A默认值）
        verbose: 是否打印详细日志（默认True）
        export_log: 是否导出连接日志到CSV（默认False）
        log_path: 日志导出路径（默认为 rusult/report/logs/）

    返回：
        (修改后的网络图, 统计信息字典)

    统计信息字典包含：
        - 'num_added_edges': 成功添加的边数
        - 'num_attempted_edges': 尝试添加的边数
        - 'num_failed_edges': 失败的边数
        - 'success_rate': 成功率
        - 'total_recycling_weight': 回收边的总权重（日元/年）
        - 'recycling_edges': 添加的边列表 [(source, target, weight), ...]
        - 'failed_edges': 失败的边列表（包含原因）
        - 'logger': 详细日志记录器对象
        - 'policy_metrics': 政策参数字典
    """
    G_recycling = G.copy()
    logger = RecyclingEdgeLogger()
    total_recycling_weight = 0.0

    # 默认回收价值系数（方案A: 回收边与原边权重相近）
    if profit_allocation is None:
        profit_allocation = {
            'EV': 1.5,   # Second-life (梯次利用): 价值保留度高
            'DES': 1.0,  # Material recycling (材料回收): 基准价值
            'DR': 0.8    # Secondary material (二次材料): 价值略低
        }

    # 使用自定义路径或默认路径
    if custom_paths is not None:
        recycling_paths = custom_paths
    else:
        recycling_paths = get_default_recycling_paths(ev_node, battery_node, profit_allocation)

    # 确定要添加的边数
    max_available_edges = len(recycling_paths)
    if num_loops is None:
        edges_to_add = max_available_edges  # 添加所有可用边
    elif num_loops == 0:
        # 特殊情况：不添加任何边
        return G_recycling, {
            'num_added_edges': 0,
            'num_attempted_edges': 0,
            'num_failed_edges': 0,
            'success_rate': 1.0,
            'total_recycling_weight': 0.0,
            'recycling_edges': [],
            'failed_edges': [],
            'logger': logger,
            'policy_metrics': {
                'retired_battery_price': retired_battery_price,
                'price_factor_applied': 1.0,
                'profit_allocation': profit_allocation
            }
        }
    else:
        edges_to_add = min(num_loops, max_available_edges)  # 不超过可用边数

    # calculate price factor
    price_factor = retired_battery_price / 138.0
    price_factor = max(0.5, min(1.5, price_factor))

    if verbose:
        print(f"\n{'='*80}")
        print(f"开始添加回收边（Strategy 2 改进版）")
        print(f"{'='*80}")
        print(f"  目标边数: {edges_to_add} 条 ({edges_to_add}/{max_available_edges})")
        print(f"  价格因子: {price_factor:.3f}")
        print(f"  回收强度: {recycling_intensity:.3f}")
        sys.stdout.flush()

    # Use baseline out-edges from original graph (exclude newly added recycling edges)
    base_out_weight = {}
    base_out_degree = {}
    for node in G.nodes():
        base_out_degree[node] = G.out_degree(node)
        base_out_weight[node] = sum(
            data.get('weight', 0.0) for _, _, data in G.out_edges(node, data=True)
        )


    # 尝试添加边，跳过失败的继续下一条
    attempted = 0
    added = 0

    # Precompute weights for sorting (baseline only; exclude added recycling edges)
    paths_with_weights = []
    for i, (target, source, sector, multiplier) in enumerate(recycling_paths):
        target_node = _find_node_in_graph_enhanced(G_recycling, target, None)
        source_node = _find_node_in_graph_enhanced(G_recycling, source, None)
        weight = None
        if target_node is not None and source_node is not None:
            base_deg = base_out_degree.get(target_node, 0)
            if base_deg > 0:
                avg_weight = base_out_weight.get(target_node, 0.0) / base_deg
                weight = avg_weight * recycling_intensity * multiplier * price_factor
            else:
                weight = 100000 * recycling_intensity * multiplier * price_factor
        paths_with_weights.append({
            'target': target,
            'source': source,
            'sector': sector,
            'multiplier': multiplier,
            'target_node': target_node,
            'source_node': source_node,
            'weight': weight,
            'index': i,
        })

    paths_sorted = sorted(
        paths_with_weights,
        key=lambda x: x['weight'] if x['weight'] is not None else -1,
        reverse=True
    )

    for item in paths_sorted:
        if added >= edges_to_add:
            break  # ???????????

        attempted += 1

        target = item['target']
        source = item['source']
        sector = item['sector']
        multiplier = item['multiplier']
        target_node = item['target_node']
        source_node = item['source_node']

        # ????????
        if source_node is None:
            logger.log_failure(item['index'] + 1, target, source, f"??? {source} ???", sector)
            if verbose:
                print(f"  ? ?{item['index'] + 1}: ?????? {source} ????", flush=True)
            continue

        if target_node is None:
            logger.log_failure(item['index'] + 1, target, source, f"???? {target} ???", sector)
            if verbose:
                print(f"  ? ?{item['index'] + 1}: ??????? {target} ????", flush=True)
            continue

        recycling_weight = item['weight']
        if recycling_weight is None:
            base_deg = base_out_degree.get(target_node, 0)
            if base_deg > 0:
                avg_weight = base_out_weight.get(target_node, 0.0) / base_deg
                recycling_weight = avg_weight * recycling_intensity * multiplier * price_factor
            else:
                recycling_weight = 100000 * recycling_intensity * multiplier * price_factor

        # ?????
        G_recycling.add_edge(target_node, source_node, weight=recycling_weight)
        added += 1

        # ????
        logger.log_success(item['index'] + 1, target, source, target_node, source_node, recycling_weight, sector)

        if verbose:
            print(f"  ? ?{added}/{edges_to_add}: {target_node} ? {source_node}", flush=True)
            print(f"      ??: {sector}, ??: {recycling_weight:,.0f} JPY/year", flush=True)

        total_recycling_weight += recycling_weight
    if verbose:
        logger.print_summary()

    # 导出日志
    if export_log:
        if log_path is None:
            log_path = PathConfig().logs_dir
        log_path.mkdir(parents=True, exist_ok=True)

        df_success, df_failed = logger.export_to_dataframe()

        if not df_success.empty:
            success_file = log_path / 'recycling_edges_success.csv'
            df_success.to_csv(success_file, index=False, encoding='utf-8-sig')
            print(f"  成功边日志已导出: {success_file}", flush=True)

        if not df_failed.empty:
            failed_file = log_path / 'recycling_edges_failed.csv'
            df_failed.to_csv(failed_file, index=False, encoding='utf-8-sig')
            print(f"  失败边日志已导出: {failed_file}", flush=True)

    # 构建返回统计
    stats = {
        'num_added_edges': added,
        'num_attempted_edges': attempted,
        'num_failed_edges': len(logger.failed_edges),
        'success_rate': logger.get_summary()['success_rate'],
        'total_recycling_weight': total_recycling_weight,
        'recycling_edges': [(e['target_full_id'], e['source_full_id'], e['weight'])
                           for e in logger.success_edges],
        'failed_edges': logger.failed_edges,
        'logger': logger,
        'policy_metrics': {
            'retired_battery_price': retired_battery_price,
            'price_factor_applied': price_factor,
            'profit_allocation': profit_allocation
        }
    }

    return G_recycling, stats


if __name__ == '__main__':
    print("=" * 80)
    print("测试改进的回收政策模块")
    print("=" * 80)

    # 创建测试网络
    G_test = nx.DiGraph()
    # 使用完整节点ID格式
    G_test.add_edge('37111', '36901', weight=1000000)
    G_test.add_edge('36901', '28199_他無機化学製品製造', weight=500000)
    G_test.add_edge('28199_他無機化学製品製造', '33111_圧延を行う高炉製鉄', weight=200000)

    # 测试验证功能
    print("\n[测试1] 验证回收路径")
    test_paths = [
        ('37111', '36901', 'EV', 0.45),
        ('36901', '28199', 'DES', 0.49),
        ('28199', '99999', 'DR', 0.06),  # 不存在的节点
    ]
    df_verify = verify_recycling_paths(G_test, test_paths)

    # 测试添加边（verbose模式）
    print("\n[测试2] 添加回收边（详细模式）")
    G_result, stats = add_recycling_loops_strategy2_improved(
        G_test,
        num_loops=3,
        recycling_intensity=0.1,
        verbose=True,
        export_log=False
    )

    print(f"\n最终统计:")
    print(f"  成功添加: {stats['num_added_edges']} 条")
    print(f"  失败: {stats['num_failed_edges']} 条")
    print(f"  成功率: {stats['success_rate']*100:.1f}%")
    print(f"  总回收权重: {stats['total_recycling_weight']:,.0f}")

    print("\n" + "=" * 80)
    print("测试完成")
    print("=" * 80)
