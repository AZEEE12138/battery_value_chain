# -*- coding: utf-8 -*-
"""
双向权重守恒验证模块

功能：
验证网络重连（BED调整）过程中的双向权重守恒性：
1. Out_Weight守恒：所有节点的出边权重总和保持不变
2. In_Weight守恒：所有节点的入边权重总和保持不变
3. 全局权重守恒：整个网络的总权重保持不变

理论基础：
- Out_Weight守恒：节点的生产/供应能力不应被BED调整改变
- In_Weight守恒：节点的需求/消费能力不应被BED调整改变
- 全局守恒：网络的总经济流量应保持不变

警告阈值：
- 严格守恒：相对误差 < 0.1% （推荐）
- 可接受：相对误差 < 1.0%
- 警告：相对误差 < 10%
- 失败：相对误差 >= 10%

作者：Claude Code
日期：2025-12-15
版本：V1.0
"""

import pandas as pd
import numpy as np
from typing import Tuple, Dict, List
import warnings


class WeightConservationValidator:
    """双向权重守恒验证器"""

    def __init__(
        self,
        strict_tolerance: float = 0.001,  # 0.1%
        acceptable_tolerance: float = 0.01,  # 1%
        warning_tolerance: float = 0.10  # 10%
    ):
        """
        初始化验证器

        参数:
            strict_tolerance: 严格守恒容差（0.1%）
            acceptable_tolerance: 可接受容差（1%）
            warning_tolerance: 警告容差（10%）
        """
        self.strict_tolerance = strict_tolerance
        self.acceptable_tolerance = acceptable_tolerance
        self.warning_tolerance = warning_tolerance

    @staticmethod
    def _safe_print_node(node_id: str) -> str:
        """安全打印节点ID（处理特殊字符）"""
        try:
            # 尝试直接返回
            return node_id
        except UnicodeEncodeError:
            # 如果失败，使用ASCII编码
            return node_id.encode('ascii', errors='replace').decode('ascii')

    def calculate_node_weights(
        self,
        edges_df: pd.DataFrame
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        ???????In_Weight?Out_Weight?????Source_Code/Target_Code??
        """
        source_col = 'Source_Code' if 'Source_Code' in edges_df.columns else 'Source'
        target_col = 'Target_Code' if 'Target_Code' in edges_df.columns else 'Target'

        out_weight = edges_df.groupby(source_col)['Weight'].sum().reset_index()
        out_weight.columns = ['Node', 'Out_Weight']

        in_weight = edges_df.groupby(target_col)['Weight'].sum().reset_index()
        in_weight.columns = ['Node', 'In_Weight']

        return out_weight, in_weight

    def validate_bilateral_conservation(
        self,
        edges_original: pd.DataFrame,
        edges_adjusted: pd.DataFrame,
        verbose: bool = True
    ) -> Dict:
        """
        验证双向权重守恒性

        参数:
            edges_original: 原始边数据
            edges_adjusted: 调整后的边数据
            verbose: 是否打印详细信息

        返回:
            验证结果字典
        """
        if verbose:
            print(f"\n{'='*80}")
            print("双向权重守恒验证")
            print(f"{'='*80}")

        # 1. 计算原始网络的权重
        out_weight_orig, in_weight_orig = self.calculate_node_weights(edges_original)
        total_weight_orig = edges_original['Weight'].sum()

        # 2. 计算调整后网络的权重
        out_weight_adj, in_weight_adj = self.calculate_node_weights(edges_adjusted)
        total_weight_adj = edges_adjusted['Weight'].sum()

        # 3. 全局权重守恒验证
        global_error = abs(total_weight_adj - total_weight_orig)
        global_error_pct = (global_error / total_weight_orig * 100) if total_weight_orig > 0 else 0

        if verbose:
            print(f"\n[1. 全局权重守恒]")
            print(f"  原始网络总权重: {total_weight_orig:,.2f}")
            print(f"  调整后总权重: {total_weight_adj:,.2f}")
            print(f"  绝对误差: {global_error:,.2f}")
            print(f"  相对误差: {global_error_pct:.6f}%")
            self._print_conservation_status(global_error_pct)

        # 4. Out_Weight守恒验证（逐节点）
        out_weight_merged = pd.merge(
            out_weight_orig, out_weight_adj,
            on='Node', how='outer', suffixes=('_orig', '_adj')
        ).fillna(0)

        out_weight_merged['Absolute_Error'] = abs(
            out_weight_merged['Out_Weight_adj'] - out_weight_merged['Out_Weight_orig']
        )
        out_weight_merged['Relative_Error_Pct'] = (
            out_weight_merged['Absolute_Error'] / out_weight_merged['Out_Weight_orig'] * 100
        ).replace([np.inf, -np.inf], 0)

        # 识别Out_Weight变化最大的节点
        max_out_error_idx = out_weight_merged['Relative_Error_Pct'].idxmax()
        max_out_error_node = out_weight_merged.loc[max_out_error_idx]

        # 统计Out_Weight守恒性
        out_nodes_total = len(out_weight_merged)
        out_nodes_strict = (out_weight_merged['Relative_Error_Pct'] < self.strict_tolerance * 100).sum()
        out_nodes_acceptable = (out_weight_merged['Relative_Error_Pct'] < self.acceptable_tolerance * 100).sum()
        out_nodes_warning = (out_weight_merged['Relative_Error_Pct'] < self.warning_tolerance * 100).sum()

        if verbose:
            print(f"\n[2. Out_Weight守恒（逐节点）]")
            print(f"  总节点数: {out_nodes_total}")
            print(f"  严格守恒 (<0.1%): {out_nodes_strict} ({out_nodes_strict/out_nodes_total*100:.1f}%)")
            print(f"  可接受 (<1%): {out_nodes_acceptable} ({out_nodes_acceptable/out_nodes_total*100:.1f}%)")
            print(f"  警告范围 (<10%): {out_nodes_warning} ({out_nodes_warning/out_nodes_total*100:.1f}%)")
            node_name = str(max_out_error_node['Node']).encode('ascii', errors='replace').decode('ascii')
            print(f"\n  最大误差节点: {node_name}")
            print(f"    原始Out_Weight: {max_out_error_node['Out_Weight_orig']:,.2f}")
            print(f"    调整后Out_Weight: {max_out_error_node['Out_Weight_adj']:,.2f}")
            print(f"    相对误差: {max_out_error_node['Relative_Error_Pct']:.4f}%")

        # 5. In_Weight守恒验证（逐节点）⭐ 关键改进
        in_weight_merged = pd.merge(
            in_weight_orig, in_weight_adj,
            on='Node', how='outer', suffixes=('_orig', '_adj')
        ).fillna(0)

        in_weight_merged['Absolute_Error'] = abs(
            in_weight_merged['In_Weight_adj'] - in_weight_merged['In_Weight_orig']
        )
        in_weight_merged['Relative_Error_Pct'] = (
            in_weight_merged['Absolute_Error'] / in_weight_merged['In_Weight_orig'] * 100
        ).replace([np.inf, -np.inf], 0)

        # 识别In_Weight变化最大的节点
        max_in_error_idx = in_weight_merged['Relative_Error_Pct'].idxmax()
        max_in_error_node = in_weight_merged.loc[max_in_error_idx]

        # 统计In_Weight守恒性
        in_nodes_total = len(in_weight_merged)
        in_nodes_strict = (in_weight_merged['Relative_Error_Pct'] < self.strict_tolerance * 100).sum()
        in_nodes_acceptable = (in_weight_merged['Relative_Error_Pct'] < self.acceptable_tolerance * 100).sum()
        in_nodes_warning = (in_weight_merged['Relative_Error_Pct'] < self.warning_tolerance * 100).sum()

        if verbose:
            print(f"\n[3. In_Weight守恒（逐节点）] [KEY] 关键验证")
            print(f"  总节点数: {in_nodes_total}")
            print(f"  严格守恒 (<0.1%): {in_nodes_strict} ({in_nodes_strict/in_nodes_total*100:.1f}%)")
            print(f"  可接受 (<1%): {in_nodes_acceptable} ({in_nodes_acceptable/in_nodes_total*100:.1f}%)")
            print(f"  警告范围 (<10%): {in_nodes_warning} ({in_nodes_warning/in_nodes_total*100:.1f}%)")
            node_name = str(max_in_error_node['Node']).encode('ascii', errors='replace').decode('ascii')
            print(f"\n  最大误差节点: {node_name}")
            print(f"    原始In_Weight: {max_in_error_node['In_Weight_orig']:,.2f}")
            print(f"    调整后In_Weight: {max_in_error_node['In_Weight_adj']:,.2f}")
            print(f"    相对误差: {max_in_error_node['Relative_Error_Pct']:.4f}%")

        # 6. 识别In_Weight违反守恒的节点（相对误差 > 10%）
        in_weight_violations = in_weight_merged[
            in_weight_merged['Relative_Error_Pct'] >= self.warning_tolerance * 100
        ].copy()

        if len(in_weight_violations) > 0 and verbose:
            print(f"\n  [警告] 发现 {len(in_weight_violations)} 个节点In_Weight变化超过10%:")
            for idx, row in in_weight_violations.head(5).iterrows():
                node_name = str(row['Node']).encode('ascii', errors='replace').decode('ascii')
                print(f"    - {node_name}: {row['In_Weight_orig']:,.0f} -> {row['In_Weight_adj']:,.0f} "
                      f"({row['Relative_Error_Pct']:.2f}%)")
            if len(in_weight_violations) > 5:
                print(f"    ... (还有 {len(in_weight_violations) - 5} 个节点)")

        # 7. 综合评估
        if verbose:
            print(f"\n[4. 综合评估]")

        # 全局守恒性
        global_status = self._classify_conservation_status(global_error_pct)

        # Out_Weight守恒性
        out_conservation_rate = out_nodes_acceptable / out_nodes_total if out_nodes_total > 0 else 0
        out_status = 'PASS' if out_conservation_rate >= 0.95 else 'WARNING' if out_conservation_rate >= 0.90 else 'FAIL'

        # In_Weight守恒性
        in_conservation_rate = in_nodes_acceptable / in_nodes_total if in_nodes_total > 0 else 0
        in_status = 'PASS' if in_conservation_rate >= 0.95 else 'WARNING' if in_conservation_rate >= 0.90 else 'FAIL'

        if verbose:
            print(f"  全局权重守恒: {global_status}")
            print(f"  Out_Weight守恒: {out_status} ({out_conservation_rate*100:.1f}%节点可接受)")
            print(f"  In_Weight守恒: {in_status} ({in_conservation_rate*100:.1f}%节点可接受)")

            print(f"\n  最终评级: ", end='')
            if global_status == 'STRICT' and out_status == 'PASS' and in_status == 'PASS':
                print("[EXCELLENT] 优秀")
            elif global_status in ['STRICT', 'ACCEPTABLE'] and out_status != 'FAIL' and in_status != 'FAIL':
                print("[PASS] 通过")
            elif global_status == 'WARNING' or out_status == 'WARNING' or in_status == 'WARNING':
                print("[WARNING] 警告")
            else:
                print("[FAIL] 失败")

            print(f"{'='*80}\n")

        # 返回验证结果
        return {
            'global': {
                'total_weight_original': total_weight_orig,
                'total_weight_adjusted': total_weight_adj,
                'absolute_error': global_error,
                'relative_error_pct': global_error_pct,
                'status': global_status
            },
            'out_weight': {
                'nodes_total': out_nodes_total,
                'nodes_strict': out_nodes_strict,
                'nodes_acceptable': out_nodes_acceptable,
                'nodes_warning': out_nodes_warning,
                'conservation_rate': out_conservation_rate,
                'status': out_status,
                'max_error_node': max_out_error_node.to_dict(),
                'detail_table': out_weight_merged
            },
            'in_weight': {
                'nodes_total': in_nodes_total,
                'nodes_strict': in_nodes_strict,
                'nodes_acceptable': in_nodes_acceptable,
                'nodes_warning': in_nodes_warning,
                'conservation_rate': in_conservation_rate,
                'status': in_status,
                'max_error_node': max_in_error_node.to_dict(),
                'violations': in_weight_violations,
                'detail_table': in_weight_merged
            }
        }

    def _classify_conservation_status(self, error_pct: float) -> str:
        """分类守恒状态"""
        if error_pct < self.strict_tolerance * 100:
            return 'STRICT'
        elif error_pct < self.acceptable_tolerance * 100:
            return 'ACCEPTABLE'
        elif error_pct < self.warning_tolerance * 100:
            return 'WARNING'
        else:
            return 'FAIL'

    def _print_conservation_status(self, error_pct: float):
        """打印守恒状态"""
        status = self._classify_conservation_status(error_pct)
        if status == 'STRICT':
            print(f"  守恒性: [OK] 严格守恒 (<0.1%)")
        elif status == 'ACCEPTABLE':
            print(f"  守恒性: [OK] 可接受 (<1%)")
        elif status == 'WARNING':
            print(f"  守恒性: [WARNING] 警告 (<10%)")
        else:
            print(f"  守恒性: [FAIL] 失败 (>=10%)")

    def generate_conservation_report(
        self,
        validation_results: Dict,
        output_path: str = None
    ) -> pd.DataFrame:
        """
        生成守恒性分析报告

        参数:
            validation_results: validate_bilateral_conservation()的返回值
            output_path: 报告保存路径（可选）

        返回:
            报告DataFrame
        """
        # 提取In_Weight违反守恒的节点详情
        violations = validation_results['in_weight']['violations']

        if len(violations) > 0:
            # 按相对误差降序排列
            report_df = violations.sort_values('Relative_Error_Pct', ascending=False).copy()
            report_df = report_df[[
                'Node', 'In_Weight_orig', 'In_Weight_adj',
                'Absolute_Error', 'Relative_Error_Pct'
            ]]
            report_df.columns = [
                '节点ID', '原始In_Weight', '调整后In_Weight',
                '绝对误差', '相对误差(%)'
            ]

            if output_path:
                report_df.to_csv(output_path, index=False, encoding='utf-8-sig')
                print(f"守恒性报告已保存: {output_path}")

            return report_df
        else:
            print("所有节点In_Weight均满足守恒性要求（<10%），无需生成报告")
            return pd.DataFrame()


def validate_bed_adjustment_conservation(
    edges_original: pd.DataFrame,
    edges_adjusted: pd.DataFrame,
    verbose: bool = True
) -> Dict:
    """
    便捷函数：验证BED调整的双向权重守恒性

    参数:
        edges_original: 原始边数据
        edges_adjusted: BED调整后的边数据
        verbose: 是否打印详细信息

    返回:
        验证结果字典
    """
    validator = WeightConservationValidator()
    return validator.validate_bilateral_conservation(
        edges_original, edges_adjusted, verbose
    )


# 示例用法
if __name__ == '__main__':
    print("双向权重守恒验证模块")
    print("请使用 test_weight_conservation.py 运行测试")
