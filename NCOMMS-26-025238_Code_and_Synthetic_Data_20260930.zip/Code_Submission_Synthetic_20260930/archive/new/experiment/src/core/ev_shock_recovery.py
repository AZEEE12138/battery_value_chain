﻿# -*- coding: utf-8 -*-
"""
EV 需求冲击、级联失效与恢复仿真的工具函数。

主流程：
- 渐进式 EV 需求冲击（t=0..shock_steps）
- 基于破产阈值的级联失效
- 基于优先级/概率的恢复阶段
"""

import pandas as pd
import numpy as np
import networkx as nx
from typing import Tuple, Dict, List, Set, Optional
import random

# 关键节点ID
BATTERY_NODE = '36901'
EV_NODE = '37111'


def calculate_network_performance(G: nx.DiGraph) -> float:
    """
    计算网络性能 ES(t)，定义为当前图的边权重总和。
    """
    if G.number_of_edges() == 0:
        return 0.0

    total_weight = sum(data['weight'] for u, v, data in G.edges(data=True))
    return total_weight


def ev_demand_shock_gradual(
    G: nx.DiGraph,
    G_original: nx.DiGraph,
    ev_node: str = EV_NODE,
    shock_steps: int = 5,
    shock_intensity: float = 1.0,
    bankruptcy_threshold: float = 0.50,
    steepness: float = 10.0,
    max_cascade_rounds: int = 100,
    verbose: bool = True
) -> Tuple[nx.DiGraph, Dict]:
    """
    执行渐进式 EV 需求冲击，并可触发级联失效。
    返回 (G_after_shock, shock_stats)。
    """
    if verbose:
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")

    G_current = G.copy()
    performance_trajectory = []
    failed_nodes_by_step = []

    ES_0 = calculate_network_performance(G_current)
    performance_trajectory.append(ES_0)

    if verbose:
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")

    ev_suppliers = list(G_current.predecessors(ev_node)) if G_current.has_node(ev_node) else []

    if verbose:
        print("[info] message suppressed due to encoding cleanup")

    original_ev_in_edges = {}
    if G_original.has_node(ev_node):
        for u, v, data in G_original.in_edges(ev_node, data=True):
            original_ev_in_edges[(u, v)] = data['weight']

    total_failed_nodes = set()
    cascade_failed_by_round: List[List[str]] = []

    for step in range(1, shock_steps + 1):
        if verbose:
            print("[info] message suppressed due to encoding cleanup")
        step_failed_nodes = set()

        if G_current.has_node(ev_node):
            reduction_factor = (step / shock_steps) * shock_intensity

            if verbose:
                print("[info] message suppressed due to encoding cleanup")

            for u, v, data in list(G_current.in_edges(ev_node, data=True)):
                if (u, v) in original_ev_in_edges:
                    original_weight = original_ev_in_edges[(u, v)]
                    new_weight = original_weight * (1 - reduction_factor)
                    G_current[u][v]['weight'] = new_weight

            if step == shock_steps and shock_intensity >= 1.0:
                G_current.remove_node(ev_node)
                step_failed_nodes.add(ev_node)
                total_failed_nodes.add(ev_node)
                if verbose:
                    print("[info] message suppressed due to encoding cleanup")
            elif step == shock_steps and shock_intensity < 1.0:
                if verbose:
                    print("[info] message suppressed due to encoding cleanup")

        if step == shock_steps and shock_intensity > 0:
            if shock_intensity >= 1.0:
                initial_failed = {ev_node}
                if verbose:
                    print("[info] message suppressed due to encoding cleanup")
            else:
                initial_failed = {ev_node}
                if verbose:
                    print("[info] message suppressed due to encoding cleanup")

            _, cascade_stats = cascade_failure(
                G_current=G_current,
                G_original=G_original,
                failed_nodes=initial_failed,
                bankruptcy_threshold=bankruptcy_threshold,
                steepness=steepness,
                max_rounds=max_cascade_rounds,
                verbose=verbose
            )

            cascade_failed = cascade_stats.get('failed_nodes', [])
            cascade_failed_by_round = cascade_stats.get('failed_nodes_by_round', [])
            step_failed_nodes.update(cascade_failed)
            total_failed_nodes.update(cascade_failed)

            if verbose:
                print("[info] message suppressed due to encoding cleanup")
        else:
            if verbose:
                print("[info] message suppressed due to encoding cleanup")

        ES_t = calculate_network_performance(G_current)
        performance_trajectory.append(ES_t)

        failed_nodes_by_step.append(list(step_failed_nodes))

        if verbose:
            print("[info] message suppressed due to encoding cleanup")
            print("[info] message suppressed due to encoding cleanup")
            print("[info] message suppressed due to encoding cleanup")
            print("[info] message suppressed due to encoding cleanup")

    ER = min(performance_trajectory)
    er_time = performance_trajectory.index(ER)

    if verbose:
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")

    shock_stats = {
        'shock_type': 'EV_demand_gradual_disappearance',
        'shock_steps': shock_steps,
        'shock_intensity': shock_intensity,
        'ev_node': ev_node,
        'ev_suppliers': ev_suppliers,
        'num_ev_suppliers': len(ev_suppliers),
        'initial_performance': ES_0,
        'final_performance_shock': performance_trajectory[-1],
        'min_performance': ER,
        'min_performance_time': er_time,
        'robustness': ER / ES_0 if ES_0 > 0 else 0.0,
        'performance_trajectory_shock': performance_trajectory,
        'total_failed_nodes': list(total_failed_nodes),
        'num_failed_nodes': len(total_failed_nodes),
        'failed_nodes_by_step': failed_nodes_by_step,
        'cascade_failed_by_round': cascade_failed_by_round,
        'remaining_nodes': G_current.number_of_nodes(),
        'remaining_edges': G_current.number_of_edges()
    }

    return G_current, shock_stats


def cascade_failure(
    G_current: nx.DiGraph,
    G_original: nx.DiGraph,
    failed_nodes: Set[str],
    bankruptcy_threshold: float = 0.50,
    steepness: float = 10.0,
    max_rounds: int = 100,
    verbose: bool = False
) -> Tuple[nx.DiGraph, Dict]:
    """
    传播级联失效并返回失效节点与统计信息。
    """
    import numpy as np

    all_failed_nodes = []
    failed_nodes_by_round = []
    cascade_rounds = 0

    if verbose:
        import datetime
        from pathlib import Path
        log_file = Path(__file__).parent.parent.parent / "cascade_debug_log.txt"
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n{'='*80}\n")
            f.write(f"[{datetime.datetime.now()}] 级联失效调试（利润崩溃机制）\n")
            f.write(f"鍒濆澶辨晥鑺傜偣: {failed_nodes}\n")
            f.write(f"鐮翠骇闃堝€? {bankruptcy_threshold:.1%}, 闄″抄搴? {steepness}, 鏈€澶ц疆鏁? {max_rounds}\n")
            f.write(f"G_current鑺傜偣鏁? {G_current.number_of_nodes()}\n")
            f.write(f"G_original鑺傜偣鏁? {G_original.number_of_nodes()}\n")

        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")

    for round_num in range(1, max_rounds + 1):
        nodes_to_fail = []

        if verbose:
            print("[info] message suppressed due to encoding cleanup")

        for node in list(G_current.nodes()):
            if node in failed_nodes:
                continue

            if not G_original.has_node(node):
                continue

            MIN_FLOW_THRESHOLD = 1e-6

            original_outflow = sum(
                G_original[node][v]['weight']
                for v in G_original.successors(node)
            )
            current_outflow = sum(
                G_current[node][v]['weight']
                for v in G_current.successors(node)
                if G_current.has_node(v)
            )

            if original_outflow < MIN_FLOW_THRESHOLD:
                profit_loss = 0.0
            else:
                profit_loss = 1.0 - (current_outflow / original_outflow)
                profit_loss = max(0.0, min(1.0, profit_loss))

            bankruptcy_prob = 1.0 / (1.0 + np.exp(-steepness * (profit_loss - bankruptcy_threshold)))

            if np.random.random() < bankruptcy_prob:
                nodes_to_fail.append(node)

                if verbose:
                    print("[info] message suppressed due to encoding cleanup")
                    print("[info] message suppressed due to encoding cleanup")
                    print("[info] message suppressed due to encoding cleanup")
                    print("[info] message suppressed due to encoding cleanup")
                    print("[info] message suppressed due to encoding cleanup")

                    from pathlib import Path
                    log_file = Path(__file__).parent.parent.parent / "cascade_debug_log.txt"
                    with open(log_file, 'a', encoding='utf-8') as f:
                        f.write(f"  鉁?鑺傜偣 {node} 鐮翠骇:\n")
                        f.write(f"    鍘熷杈撳嚭: {original_outflow:.2f}, 褰撳墠杈撳嚭: {current_outflow:.2f}\n")
                        f.write(f"    杈撳嚭鎹熷け鐜? {profit_loss:.2%}, 鐮翠骇姒傜巼: {bankruptcy_prob:.2%}\n")
            else:
                if verbose and profit_loss > 0.2:
                    print("[info] message suppressed due to encoding cleanup")
                    print("[info] message suppressed due to encoding cleanup")
                    print("[info] message suppressed due to encoding cleanup")
                    print("[info] message suppressed due to encoding cleanup")

        if not nodes_to_fail:
            if verbose:
                print("[info] message suppressed due to encoding cleanup")
            break

        # 记录本轮失败节点
        failed_nodes_by_round.append(list(nodes_to_fail))

        for node in nodes_to_fail:
            G_current.remove_node(node)
            failed_nodes.add(node)
            all_failed_nodes.append(node)

        cascade_rounds += 1

        if verbose:
            print("[info] message suppressed due to encoding cleanup")

    cascade_stats = {
        'cascade_rounds': cascade_rounds,
        'failed_nodes': all_failed_nodes,
        'num_failed_nodes': len(all_failed_nodes),
        'failed_nodes_by_round': failed_nodes_by_round
    }

    return G_current, cascade_stats


def restore_ev_node(G_current: nx.DiGraph, G_original: nx.DiGraph, ev_node: str = EV_NODE):
    """
    将 EV 节点入边逐步恢复到原始权重。
    """
    if not G_current.has_node(ev_node) and G_original.has_node(ev_node):
        G_current.add_node(ev_node, **G_original.nodes[ev_node])

        for u, v, data in G_original.in_edges(ev_node, data=True):
            if G_current.has_node(u):
                G_current.add_edge(u, v, **data)

        for u, v, data in G_original.out_edges(ev_node, data=True):
            if G_current.has_node(v):
                G_current.add_edge(u, v, **data)


def restore_normal_node(G_current: nx.DiGraph, G_original: nx.DiGraph, node: str):
    """
    将非 EV 节点入边恢复到原始权重。
    """
    if not G_current.has_node(node) and G_original.has_node(node):
        G_current.add_node(node, **G_original.nodes[node])

        for u, v, data in G_original.in_edges(node, data=True):
            if G_current.has_node(u):
                G_current.add_edge(u, v, **data)

        for u, v, data in G_original.out_edges(node, data=True):
            if G_current.has_node(v):
                G_current.add_edge(u, v, **data)


def calculate_ev_max_recovery(shock_intensity: float) -> float:
    """
    根据冲击强度计算 EV 需求恢复上限。
    """
    max_recovery = 1.0 - 0.5 * shock_intensity
    return max(0.5, min(1.0, max_recovery))


def restore_normal_node_gradual(
    G_current: nx.DiGraph,
    G_original: nx.DiGraph,
    node: str,
    recovery_ratio: float
):
    """
    按恢复比例逐步恢复普通节点。
    """
    if not G_current.has_node(node):
        if G_original.has_node(node):
            G_current.add_node(node, **G_original.nodes[node])

    for u, v, data in G_original.in_edges(node, data=True):
        if G_current.has_node(u):
            original_weight = data.get('weight', 1.0)
            recovered_weight = original_weight * recovery_ratio

            if G_current.has_edge(u, v):
                G_current[u][v]['weight'] = recovered_weight
            else:
                edge_data = data.copy()
                edge_data['weight'] = recovered_weight
                G_current.add_edge(u, v, **edge_data)

    for u, v, data in G_original.out_edges(node, data=True):
        if G_current.has_node(v):
            original_weight = data.get('weight', 1.0)
            recovered_weight = original_weight * recovery_ratio

            if G_current.has_edge(u, v):
                G_current[u][v]['weight'] = recovered_weight
            else:
                edge_data = data.copy()
                edge_data['weight'] = recovered_weight
                G_current.add_edge(u, v, **edge_data)


def recovery_simulation_with_ev(
    G_current: nx.DiGraph,
    G_original: nx.DiGraph,
    failed_nodes: List[str],
    ev_node: str = EV_NODE,
    p_recover: float = 0.05,
    recovery_steps: int = 45,
    noise_level: float = 0.10,
    recovery_threshold: float = 0.9,
    recovery_increment: float = 0.25,
    shock_intensity: float = 1.0,
    limit_one_recovery_per_step: bool = True,
    verbose: bool = True
) -> Tuple[nx.DiGraph, Dict]:
    """
    运行带优先级/概率机制的恢复仿真，返回 (recovery_stats, G_recovered)。
    """
    if verbose:
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")

    G_recovery = G_current.copy()
    performance_trajectory = []

    failed_nodes_current = set(failed_nodes) - {ev_node}
    ev_node_is_failed = ev_node in failed_nodes

    node_recovery_progress = {}  # {node_id: recovery_ratio (0.0-1.0)}
    for node in failed_nodes_current:
        node_recovery_progress[node] = 0.0
    node_noise = {node: random.uniform(-noise_level, noise_level) for node in failed_nodes_current}

    ev_recovery_max_ratio = calculate_ev_max_recovery(shock_intensity)
    ev_current_recovery_ratio = 0.0
    ev_recovery_started_at = None

    ES_0 = calculate_network_performance(G_original)
    target_performance = recovery_threshold * ES_0

    if verbose:
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")

    recovery_time = None

    for step in range(1, recovery_steps + 1):
        nodes_fully_recovered = []

        # Collect candidates and recovery probabilities for this step
        candidates = []
        for node in list(node_recovery_progress.keys()):
            current_progress = node_recovery_progress[node]
            if current_progress >= 1.0:
                continue
            priority_score = None
            if limit_one_recovery_per_step:
                priority_score = calculate_node_recovery_priority(
                    node=node,
                    G_current=G_recovery,
                    G_original=G_original,
                    failed_nodes=failed_nodes_current
                )
            if node not in node_noise:
                node_noise[node] = random.uniform(-noise_level, noise_level)
            recovery_prob = calculate_node_recovery_probability(
                node=node,
                G_current=G_recovery,
                G_original=G_original,
                failed_nodes=failed_nodes_current,
                noise_level=noise_level,
                current_step=step,
                base_rate=p_recover,
                noise_override=node_noise.get(node)
            )
            candidates.append((node, recovery_prob, current_progress, priority_score))

        if candidates:
            if limit_one_recovery_per_step:
                node, recovery_prob, current_progress, _ = max(
                    candidates,
                    key=lambda x: (x[3] if x[3] is not None else -1.0, x[1])
                )
                new_progress = min(1.0, current_progress + recovery_increment)
                node_recovery_progress[node] = new_progress

                restore_normal_node_gradual(
                    G_recovery, G_original, node, new_progress
                )

                if new_progress >= 1.0:
                    nodes_fully_recovered.append(node)
                    if verbose and step <= 10:
                        print("[info] message suppressed due to encoding cleanup")
                elif verbose and step <= 10 and new_progress >= 0.5:
                    print("[info] message suppressed due to encoding cleanup")
            else:
                for node, recovery_prob, current_progress, _ in candidates:
                    if random.random() < recovery_prob:
                        new_progress = min(1.0, current_progress + recovery_increment)
                        node_recovery_progress[node] = new_progress

                        restore_normal_node_gradual(
                            G_recovery, G_original, node, new_progress
                        )

                        if new_progress >= 1.0:
                            nodes_fully_recovered.append(node)
                            if verbose and step <= 10:
                                print("[info] message suppressed due to encoding cleanup")
                        elif verbose and step <= 10 and new_progress >= 0.5:
                            print("[info] message suppressed due to encoding cleanup")

        for node in nodes_fully_recovered:
            failed_nodes_current.discard(node)
            del node_recovery_progress[node]

        if ev_node_is_failed:
            if step >= 1:
                if ev_recovery_started_at is None:
                    ev_recovery_started_at = step
                    if not G_recovery.has_node(ev_node):
                        G_recovery.add_node(ev_node, **G_original.nodes[ev_node])
                        for u, v, data in G_original.in_edges(ev_node, data=True):
                            if G_recovery.has_node(u):
                                G_recovery.add_edge(u, v, weight=0.0)
                        for u, v, data in G_original.out_edges(ev_node, data=True):
                            if G_recovery.has_node(v):
                                G_recovery.add_edge(u, v, **data)
                    if verbose:
                        print("[info] message suppressed due to encoding cleanup")

                if G_recovery.has_node(ev_node):
                    recovery_elapsed = step - ev_recovery_started_at
                    max_recovery_duration = recovery_steps - 1

                    import numpy as np
                    progress = recovery_elapsed / max_recovery_duration
                    steepness_ev = 3.0
                    sigmoid_progress = 1 / (1 + np.exp(-steepness_ev * (progress - 0.5)))

                    noise = np.random.uniform(-noise_level, noise_level)
                    noisy_max_ratio = max(0.5, min(1.0, ev_recovery_max_ratio * (1 + noise)))

                    ev_current_recovery_ratio = sigmoid_progress * noisy_max_ratio

                    for u, v, data in G_original.in_edges(ev_node, data=True):
                        if G_recovery.has_edge(u, v):
                            original_weight = data['weight']
                            recovered_weight = original_weight * ev_current_recovery_ratio
                            G_recovery[u][v]['weight'] = recovered_weight

                    if verbose and step % 10 == 0:
                        print("[info] message suppressed due to encoding cleanup")

        ES_t = calculate_network_performance(G_recovery)
        performance_trajectory.append(ES_t)

        if ES_t >= target_performance and recovery_time is None:
            recovery_time = step
            if verbose:
                print("[info] message suppressed due to encoding cleanup")

        if verbose and step % 10 == 0:
            print("[info] message suppressed due to encoding cleanup")

    if recovery_time is None:
        recovery_time = recovery_steps

    ES_final = performance_trajectory[-1]
    recovery_achieved = ES_final >= target_performance

    if verbose:
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")
        if ev_node_is_failed and ev_recovery_started_at is not None:
            print("[info] message suppressed due to encoding cleanup")
        else:
            print("[info] message suppressed due to encoding cleanup")
        print("[info] message suppressed due to encoding cleanup")

    recovery_stats = {
        'recovery_steps': recovery_steps,
        'recovery_time': recovery_time + 5,
        'recovery_time_in_phase': recovery_time,
        'final_performance': ES_final,
        'target_performance': target_performance,
        'recovery_achieved': recovery_achieved,
        'recovery_rate': ES_final / ES_0 if ES_0 > 0 else 0.0,
        'remaining_failed_nodes': len(failed_nodes_current),
        'performance_trajectory_recovery': performance_trajectory,
        'ev_recovered': ev_recovery_started_at is not None if ev_node_is_failed else True,
        'ev_recovered_at': (ev_recovery_started_at + 5) if ev_recovery_started_at is not None else None,
        'ev_final_recovery_ratio': ev_current_recovery_ratio if ev_node_is_failed else 1.0
    }

    return G_recovery, recovery_stats


def calculate_node_recovery_priority(
    node: str,
    G_current: nx.DiGraph,
    G_original: nx.DiGraph,
    failed_nodes: set
) -> float:
    """
    计算节点恢复优先级。
    """
    priority_score = 0.5

    suppliers = list(G_original.predecessors(node))
    if len(suppliers) > 0:
        active_suppliers = [s for s in suppliers if s not in failed_nodes]
        supplier_recovery_rate = len(active_suppliers) / len(suppliers)
        priority_score += 0.35 * supplier_recovery_rate
    else:
        priority_score += 0.20

    out_degree = G_original.out_degree(node)
    in_degree = G_original.in_degree(node)
    if out_degree > in_degree:
        priority_score += 0.25
    elif out_degree == in_degree and out_degree > 0:
        priority_score += 0.10

    node_name_jp = G_original.nodes[node].get('Industry_Name_JP', '')
    node_name_cn = G_original.nodes[node].get('Industry_Name_CN', '')
    if not node_name_cn:
        node_name_cn = G_original.nodes[node].get('Node_Name', '') or G_original.nodes[node].get('label', '')
    if not node_name_cn:
        node_name_cn = G_original.nodes[node].get('Node_Name', '') or G_original.nodes[node].get('label', '')
    MATERIAL_KEYWORDS_JP = ['\u91d1\u5c5e', '\u92f3\u935b', '\u88fd\u92fc', '\u30d7\u30ec\u30b9', '\u92f3\u9020', '\u5316\u5b66', '\u6a39\u8102', '\u70ad\u7d20']
    MATERIAL_KEYWORDS_CN = ['\u91d1\u5c5e', '\u94f8\u953b', '\u5236\u94a2', '\u51b2\u538b', '\u94f8\u9020', '\u5316\u5b66', '\u6811\u8102', '\u78b3\u7d20']
    is_material = (
        any(kw in node_name_jp for kw in MATERIAL_KEYWORDS_JP) or
        any(kw in node_name_cn for kw in MATERIAL_KEYWORDS_CN)
    )
    if is_material:
        priority_score += 0.20

    customers = list(G_original.successors(node))
    if len(customers) > 0:
        active_customers = [c for c in customers if c not in failed_nodes]
        customer_recovery_rate = len(active_customers) / len(customers)
        priority_score += 0.15 * customer_recovery_rate
    else:
        pass

    node_weight = G_original.nodes[node].get('Total_Weight', 0)
    if node_weight > 0:
        if not hasattr(calculate_node_recovery_priority, '_max_weight_cache'):
            max_weight = max(
                G_original.nodes[n].get('Total_Weight', 0)
                for n in G_original.nodes()
            )
            calculate_node_recovery_priority._max_weight_cache = max_weight
        else:
            max_weight = calculate_node_recovery_priority._max_weight_cache

        normalized_weight = node_weight / max_weight if max_weight > 0 else 0
        priority_score += 0.10 * normalized_weight

    return priority_score



def calculate_node_recovery_probability(
    node: str,
    G_current: nx.DiGraph,
    G_original: nx.DiGraph,
    failed_nodes: set,
    noise_level: float,
    current_step: int,
    base_rate: float,
    noise_override: Optional[float] = None
) -> float:
    """
    基于优先级与供需条件计算每步恢复概率。
    """
    priority_score = calculate_node_recovery_priority(
        node, G_current, G_original, failed_nodes
    )

    suppliers = list(G_original.predecessors(node))
    if suppliers:
        active_suppliers = [s for s in suppliers if s not in failed_nodes]
        supplier_recovery_rate = len(active_suppliers) / len(suppliers)
    else:
        supplier_recovery_rate = 1.0

    customers = list(G_original.successors(node))
    if customers:
        active_customers = [c for c in customers if c not in failed_nodes]
        customer_recovery_rate = len(active_customers) / len(customers)
    else:
        customer_recovery_rate = 1.0

    time_factor = min(1.0, 0.4 + 0.6 * (current_step / 50))
    noise = noise_override if noise_override is not None else random.uniform(-noise_level, noise_level)

    recovery_prob = base_rate * (
        0.45 * priority_score +
        0.25 * supplier_recovery_rate +
        0.20 * customer_recovery_rate +
        0.10 * time_factor
    )
    recovery_prob = max(0.0, min(1.0, recovery_prob + noise))
    return recovery_prob


def can_node_recover_logical(
    node: str,
    G_current: nx.DiGraph,
    G_original: nx.DiGraph,
    failed_nodes: set,
    noise_level: float = 0.10,
    current_step: int = 1
) -> bool:
    """
    依据优先级/概率逻辑判断节点是否可恢复。
    """
    recovery_prob = calculate_node_recovery_probability(
        node=node,
        G_current=G_current,
        G_original=G_original,
        failed_nodes=failed_nodes,
        noise_level=noise_level,
        current_step=current_step,
        base_rate=1.0
    )
    return random.random() < recovery_prob


def test_ev_demand_shock():
    """
    EV 需求冲击的小型测试入口。
    """
    import sys
    from pathlib import Path
    BASE_DIR = Path(__file__).resolve().parent.parent.parent
    sys.path.insert(0, str(BASE_DIR))

    from src.utils.path_config import PathConfig
    from src.core.cascade_failure import build_network_from_data

    print("="*80)
    print("[info] message suppressed due to encoding cleanup")
    print("="*80)

    paths = PathConfig()
    nodes_path = paths.get_input_file('battery_value_chain_nodes_recalculated.csv')
    edges_path = paths.get_input_file('battery_value_chain_edges.csv')

    print("[info] message suppressed due to encoding cleanup")
    nodes_df = pd.read_csv(nodes_path, encoding='utf-8-sig')
    edges_df = pd.read_csv(edges_path, encoding='utf-8-sig')

    G = build_network_from_data(nodes_df, edges_df)
    G_original = G.copy()

    print("[info] message suppressed due to encoding cleanup")
    print("[info] message suppressed due to encoding cleanup")

    G_after_shock, shock_stats = ev_demand_shock_gradual(
        G=G.copy(),
        G_original=G_original,
        ev_node=EV_NODE,
        shock_steps=5,
        cascade_threshold=0.80,
        verbose=True
    )

    G_recovered, recovery_stats = recovery_simulation_with_ev(
        G_current=G_after_shock,
        G_original=G_original,
        failed_nodes=shock_stats['total_failed_nodes'],
        ev_node=EV_NODE,
        p_recover=0.1,
        recovery_steps=45,
        noise_level=0.05,
        verbose=True
    )

    print("\n" + "="*80)
    print("[info] message suppressed due to encoding cleanup")
    print("="*80)


if __name__ == '__main__':
    np.random.seed(42)
    random.seed(42)

    test_ev_demand_shock()



