# -*- coding: utf-8 -*-
"""
级联失效模型 - 简化版（无竞争淘汰）

功能：
模拟供应链级联失效过程，不包含竞争淘汰机制
仅基于供应/需求中断率触发级联传播

参数：
- 级联阈值：80%（降低自96%）
- 最大级联轮数：3轮
- 冲击目标：蓄电池节点

作者：Claude Code
日期：2025-12-03
"""

import pandas as pd
import numpy as np
import networkx as nx
from typing import Set, Tuple, Dict, List
import re

# 蓄电池节点ID
BATTERY_NODE = '36901'


def _normalize_code(value: str) -> str:
    digits = "".join(re.findall(r"[0-9]+", str(value)))
    return digits if digits else str(value).strip()



def build_network_from_data(nodes_df: pd.DataFrame, edges_df: pd.DataFrame) -> nx.DiGraph:
    """
    ?????????NetworkX???????????????
    """
    G = nx.DiGraph()

    node_id_col = None
    for candidate in ['Industry_Code', 'Node_Code', 'Id', 'Node']:
        if candidate in nodes_df.columns:
            node_id_col = candidate
            break

    source_col = 'Source_Code' if 'Source_Code' in edges_df.columns else 'Source'
    target_col = 'Target_Code' if 'Target_Code' in edges_df.columns else 'Target'

    for _, node in nodes_df.iterrows():
        raw_id = str(node.get(node_id_col, '')).strip()
        node_id = _normalize_code(raw_id)
        if not node_id:
            continue
        G.add_node(
            node_id,
            label=node.get('Node_Name', node.get('Abbreviation', '')),
            industry_code=node.get('Industry_Code', ''),
            out_degree=node.get('Out_Degree', 0),
            in_degree=node.get('In_Degree', 0),
            total_weight=node.get('Total_Weight', 0)
        )

    for _, edge in edges_df.iterrows():
        src = _normalize_code(edge.get(source_col, ''))
        tgt = _normalize_code(edge.get(target_col, ''))
        if not src or not tgt:
            continue
        G.add_edge(
            src,
            tgt,
            weight=edge.get('Weight', 0),
            transactions=edge.get('Transactions', 0)
        )

    return G


def calculate_initial_performance(G: nx.DiGraph) -> float:
    """
    计算网络初始性能 ES(0)

    定义：ES = 所有边权重之和

    参数:
        G: NetworkX图对象

    返回:
        初始性能值
    """
    total_weight = sum(data['weight'] for _, _, data in G.edges(data=True))
    return total_weight


def apply_initial_shock(G: nx.DiGraph, target_node: str = BATTERY_NODE, shock_type: str = 'remove') -> Set[str]:
    """
    施加初始冲击到目标节点

    参数:
        G: NetworkX图对象
        target_node: 冲击目标节点
        shock_type: 冲击类型 ('remove'=移除节点, 'weaken'=削弱权重)

    返回:
        初始失效节点集合
    """
    failed_nodes = set()

    if shock_type == 'remove':
        # 移除节点
        if target_node in G.nodes():
            G.remove_node(target_node)
            failed_nodes.add(target_node)
    elif shock_type == 'weaken':
        # 削弱节点相关边权重（降低50%）
        if target_node in G.nodes():
            for u, v, data in G.edges(data=True):
                if u == target_node or v == target_node:
                    data['weight'] *= 0.5
            failed_nodes.add(target_node)

    return failed_nodes


def calculate_disruption_rates(G: nx.DiGraph, failed_nodes: Set[str]) -> Dict[str, Dict[str, float]]:
    """
    计算每个节点的供应中断率和需求中断率

    供应中断率 = (失效上游节点的入边权重总和) / (所有入边权重总和)
    需求中断率 = (失效下游节点的出边权重总和) / (所有出边权重总和)

    参数:
        G: NetworkX图对象
        failed_nodes: 已失效节点集合

    返回:
        {node_id: {'supply_disruption': float, 'demand_disruption': float}}
    """
    disruption_rates = {}

    for node in G.nodes():
        if node in failed_nodes:
            continue  # 已失效节点不计算

        # 计算供应中断率（上游）
        in_edges = G.in_edges(node, data=True)
        total_in_weight = sum(data['weight'] for _, _, data in in_edges)
        failed_in_weight = sum(
            data['weight'] for u, _, data in in_edges if u in failed_nodes
        )
        supply_disruption = (failed_in_weight / total_in_weight) if total_in_weight > 0 else 0.0

        # 计算需求中断率（下游）
        out_edges = G.out_edges(node, data=True)
        total_out_weight = sum(data['weight'] for _, _, data in out_edges)
        failed_out_weight = sum(
            data['weight'] for _, v, data in out_edges if v in failed_nodes
        )
        demand_disruption = (failed_out_weight / total_out_weight) if total_out_weight > 0 else 0.0

        disruption_rates[node] = {
            'supply_disruption': supply_disruption,
            'demand_disruption': demand_disruption
        }

    return disruption_rates


def cascade_round(
    G: nx.DiGraph,
    failed_nodes: Set[str],
    cascade_threshold: float = 0.80
) -> Tuple[Set[str], int]:
    """
    执行一轮级联失效

    失效条件：供应中断率 > threshold OR 需求中断率 > threshold

    参数:
        G: NetworkX图对象
        failed_nodes: 已失效节点集合
        cascade_threshold: 级联阈值（默认0.80）

    返回:
        (新增失效节点集合, 新增失效节点数量)
    """
    # 计算所有节点的中断率
    disruption_rates = calculate_disruption_rates(G, failed_nodes)

    # 判断哪些节点触发级联失效
    newly_failed = set()

    for node, rates in disruption_rates.items():
        supply_disruption = rates['supply_disruption']
        demand_disruption = rates['demand_disruption']

        # 失效条件：供应或需求中断率超过阈值
        if supply_disruption > cascade_threshold or demand_disruption > cascade_threshold:
            newly_failed.add(node)

    return newly_failed, len(newly_failed)


def cascade_failure_simulation(
    G: nx.DiGraph,
    shock_target: str = BATTERY_NODE,
    cascade_threshold: float = 0.80,
    max_rounds: int = 3,
    shock_type: str = 'remove',
    verbose: bool = True
) -> Dict:
    """
    完整的级联失效模拟（无竞争淘汰）

    步骤：
    1. 施加初始冲击到目标节点
    2. 执行最多max_rounds轮级联传播
    3. 每轮计算供应/需求中断率，判断新增失效节点
    4. 记录级联统计信息

    参数:
        G: NetworkX图对象（会被修改）
        shock_target: 冲击目标节点
        cascade_threshold: 级联阈值（默认0.80）
        max_rounds: 最大级联轮数（默认3，实验中覆盖为15）
        shock_type: 冲击类型 ('remove' or 'weaken')
        verbose: 是否打印详细信息

    返回:
        {
            'failed_nodes': Set[str],  # 所有失效节点
            'cascade_rounds': int,  # 实际级联轮数
            'initial_failed': int,  # 初始失效数量
            'cascade_failed': int,  # 级联失效数量
            'performance_after_shock': float,  # 冲击后性能
            'cascade_details': List[Dict]  # 每轮详情
        }
    """
    if verbose:
        print(f"\n{'='*80}")
        print(f"级联失效模拟")
        print(f"{'='*80}")
        print(f"  冲击目标: {shock_target}")
        print(f"  冲击类型: {shock_type}")
        print(f"  级联阈值: {cascade_threshold*100:.0f}%")
        print(f"  最大轮数: {max_rounds}")

    # 创建图副本避免修改原图
    G_sim = G.copy()

    # 步骤1: 施加初始冲击
    failed_nodes = apply_initial_shock(G_sim, shock_target, shock_type)
    initial_failed_count = len(failed_nodes)

    if verbose:
        print(f"\n[初始冲击] 失效节点数: {initial_failed_count}")

    # 计算冲击后性能
    performance_after_shock = calculate_initial_performance(G_sim)

    # 步骤2: 级联传播
    cascade_details = []
    actual_rounds = 0

    for round_num in range(1, max_rounds + 1):
        # 执行一轮级联
        newly_failed, newly_failed_count = cascade_round(
            G_sim, failed_nodes, cascade_threshold
        )

        # 记录本轮详情
        round_detail = {
            'round': round_num,
            'newly_failed_count': newly_failed_count,
            'total_failed_count': len(failed_nodes) + newly_failed_count
        }
        cascade_details.append(round_detail)

        if verbose:
            print(f"  [第{round_num}轮级联] 新增失效: {newly_failed_count}, 累计失效: {round_detail['total_failed_count']}")

        # 更新失效节点集合
        failed_nodes.update(newly_failed)

        # 从图中移除新增失效节点
        for node in newly_failed:
            if node in G_sim.nodes():
                G_sim.remove_node(node)

        actual_rounds = round_num

        # 终止条件：无新增失效
        if newly_failed_count == 0:
            if verbose:
                print(f"  [终止] 无新增失效节点")
            break

    # 计算级联失效数量
    cascade_failed_count = len(failed_nodes) - initial_failed_count

    # 计算最终性能
    final_performance = calculate_initial_performance(G_sim)

    if verbose:
        print(f"\n[级联结果]")
        print(f"  实际级联轮数: {actual_rounds}")
        print(f"  初始失效节点: {initial_failed_count}")
        print(f"  级联失效节点: {cascade_failed_count}")
        print(f"  总失效节点: {len(failed_nodes)}")
        print(f"  最终性能: {final_performance:,.0f}")
        print(f"{'='*80}\n")

    return {
        'failed_nodes': failed_nodes,
        'cascade_rounds': actual_rounds,
        'initial_failed': initial_failed_count,
        'cascade_failed': cascade_failed_count,
        'total_failed': len(failed_nodes),
        'performance_after_shock': performance_after_shock,
        'final_performance': final_performance,
        'cascade_details': cascade_details,
        'G_after_cascade': G_sim
    }


def test_cascade_model():
    """
    测试级联失效模型
    """
    import sys
    from pathlib import Path
    BASE_DIR = Path(__file__).resolve().parent.parent.parent
    sys.path.insert(0, str(BASE_DIR))

    from src.utils.path_config import PathConfig

    print("="*80)
    print("级联失效模型测试")
    print("="*80)

    # 使用PathConfig加载数据
    paths = PathConfig()
    nodes_path = paths.get_input_file('battery_value_chain_nodes_recalculated.csv')
    edges_path = paths.get_input_file('battery_value_chain_edges.csv')

    print(f"\n[数据加载]")
    nodes_df = pd.read_csv(nodes_path, encoding='utf-8-sig')
    edges_df = pd.read_csv(edges_path, encoding='utf-8-sig')

    print(f"  节点数: {len(nodes_df)}")
    print(f"  边数: {len(edges_df)}")

    # 构建网络
    print(f"\n[网络构建]")
    G = build_network_from_data(nodes_df, edges_df)
    print(f"  网络节点数: {G.number_of_nodes()}")
    print(f"  网络边数: {G.number_of_edges()}")

    # 计算初始性能
    ES_0 = calculate_initial_performance(G)
    print(f"  初始性能 ES(0): {ES_0:,.0f}")

    # 运行级联失效模拟
    result = cascade_failure_simulation(
        G,
        shock_target=BATTERY_NODE,
        cascade_threshold=0.80,
        max_rounds=3,
        shock_type='remove',
        verbose=True
    )

    # 计算稳健性
    ER = result['final_performance'] / ES_0 if ES_0 > 0 else 0
    print(f"\n[稳健性指标]")
    print(f"  能源稳健性 (ER): {ER:.4f}")
    print(f"  性能损失比例: {(1-ER)*100:.2f}%")

    return result


if __name__ == '__main__':
    # 运行测试
    test_cascade_model()
