# -*- coding: utf-8 -*-
"""
拓扑随机化空模型对照 —— 用于检验"BED临界阈值是否依赖这条供应链的真实拓扑结构"，
而不只是"任意同规模网络在同一套sigmoid级联算法下的通用行为"。

方法学依据：论文Methods 6.2.3已引用 Squartini, Mastrandrea & Garlaschelli (2015)
"Randomizing weighted directed networks while preserving node strengths"，SI第5节已引用
Maslov & Sneppen (2002) 的拓扑随机化方法——但两处引用都只用来说明"BED改线过程本身不破坏
拓扑守恒"，从未真正用来构造一个"随机化拓扑"的对照实验。本模块补上这个对照。

设计（保持蓄电池(BM)节点的角色与BED定义机制完全不动，只打乱"其余节点连给谁"）：
- 保留 BM 节点全部出边不变（这些边会被 rewire_network_to_target_BED 完全覆盖改写，
  随机化与否不影响后续BED改线结果）。
- 对其余边（source != BM）：保持每条边的 (Source, Weight) 完全不变，只把 Target 列
  在"非BM来源的边"范围内做随机排列（不放回抽样重新分配目标节点，拒绝自环）。
  这精确保持：
    (a) 每个非BM节点的出度(边数)与出强度(权重和)——因为Source/Weight原样保留；
    (b) 全网Target的边际分布(谁被指向的次数/权重总量在总体上不变，只是被谁指向被打乱)。
  代价：单个节点的精确入强度不再逐点保持(标准Maslov-Sneppen类方法的已知性质，非缺陷)。
"""
from typing import Tuple
import numpy as np
import pandas as pd


def _edge_code_cols(edges_df: pd.DataFrame) -> Tuple[str, str]:
    source_col = 'Source_Code' if 'Source_Code' in edges_df.columns else 'Source'
    target_col = 'Target_Code' if 'Target_Code' in edges_df.columns else 'Target'
    return source_col, target_col


def randomize_downstream_topology(
    edges_df: pd.DataFrame,
    battery_node: str,
    seed: int,
    n_swaps_factor: float = 10,
) -> pd.DataFrame:
    """
    Maslov-Sneppen式双边交换随机化："非BM来源"边集合上做大量双边交换(double-edge-swap)，
    每次交换前显式检查不产生自环、不产生与现有边重复的(Source,Target)对，确保交换后仍是
    合法的简单有向图——避免"独立置换Target导致(Source,Target)重复、被build_network_from_data
    合并成更少边"这一先前版本的实现缺陷(该缺陷会压低实际图出度/介数/PageRank，是伪造的结构差异，
    不是有意设计的随机化效果)。

    双边交换保持精确的出度序列与入度序列(而非仅DataFrame行数意义上的"每个Source边数不变")，
    是网络科学中Maslov & Sneppen (2002)一文提出的标准拓扑随机化方法(该文献已被SI引用)。

    参数:
        edges_df: 原始边表
        battery_node: 蓄电池节点ID(其出边不参与随机化，保持BED改线机制不变)
        seed: 随机种子(保证可复现)
        n_swaps_factor: 交换次数 = n_swaps_factor x 参与随机化的边数(标准做法，确保充分混合)

    返回:
        拓扑随机化后的边表副本(边数与每条边的Weight值集合严格不变，仅(Source,Target)配对被打乱)
    """
    rng = np.random.default_rng(seed)
    edges_out = edges_df.copy()
    source_col, target_col = _edge_code_cols(edges_out)

    src_series = edges_out[source_col].astype(str)
    is_bm_edge = src_series == str(battery_node)
    idx_to_shuffle = edges_out.index[~is_bm_edge].to_numpy()
    n = len(idx_to_shuffle)

    sources = edges_out.loc[idx_to_shuffle, source_col].astype(str).to_numpy(copy=True)
    targets = edges_out.loc[idx_to_shuffle, target_col].astype(str).to_numpy(copy=True)

    existing_pairs = set(zip(sources.tolist(), targets.tolist()))
    n_swaps = int(round(n_swaps_factor * n))
    n_success = 0

    for _ in range(n_swaps):
        i, j = rng.integers(0, n, size=2)
        if i == j:
            continue
        s1, t1 = sources[i], targets[i]
        s2, t2 = sources[j], targets[j]
        if s1 == s2 or t1 == t2:
            continue  # 同源或同目标，交换无意义(且易产生重复对)
        new_pair_1, new_pair_2 = (s1, t2), (s2, t1)
        if s1 == t2 or s2 == t1:
            continue  # 会产生自环
        if new_pair_1 in existing_pairs or new_pair_2 in existing_pairs:
            continue  # 会产生与现有边重复的(Source,Target)对
        # 执行交换：更新目标数组与合法(Source,Target)对集合
        existing_pairs.discard((s1, t1))
        existing_pairs.discard((s2, t2))
        existing_pairs.add(new_pair_1)
        existing_pairs.add(new_pair_2)
        targets[i], targets[j] = t2, t1
        n_success += 1

    # 写回前转换回原始dtype：targets在交换逻辑中被转成了str数组，若直接写入
    # 本是int64的Target列，pandas会把该列变成object混合类型(部分行int/部分行str)，
    # 导致同一节点ID(如整数36901与字符串'36901')被networkx当成两个不同节点，
    # 图节点数虚增、介数/聚类/PageRank等指标全部失真——这是纯粹的类型bug，不是随机化效应。
    original_dtype = edges_df[target_col].dtype
    edges_out.loc[idx_to_shuffle, target_col] = targets.astype(original_dtype)

    # 校验：交换后仍是简单图(无重复(Source,Target)对、无自环)
    all_pairs = list(zip(edges_out[source_col].astype(str), edges_out[target_col].astype(str)))
    assert len(all_pairs) == len(set(all_pairs)), "随机化后出现重复(Source,Target)对，需检查交换逻辑"
    assert all(s != t for s, t in all_pairs), "随机化后出现自环，需检查交换逻辑"

    return edges_out
