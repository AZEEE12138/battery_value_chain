# -*- coding: utf-8 -*-
"""
Run dynamic resilience simulations with four scenarios at a fixed shock level:
- baseline
- supply_stability (contract floor + early warning)
- inventory_buffer (buffer node + finance boost)
- combined (supply_stability + inventory_buffer)
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd

THIS_DIR = Path(__file__).resolve().parent
PROJECT_DIR = THIS_DIR.parent
sys.path.insert(0, str(PROJECT_DIR))

from src.utils.path_config import PathConfig
from src.core.supply_stability_policy import (
    SupplyStabilityConfig,
    load_key_upstream_material_codes,
    resolve_upstream_nodes,
)
from experiments.run_resilience_simulation_policy_core import run_single_simulation


def _bed_values(start: float, end: float, step: float) -> List[float]:
    return [round(x, 2) for x in np.arange(start, end + step / 2, step)]


def run_scenario(
    scenario_name: str,
    nodes_df: pd.DataFrame,
    edges_df: pd.DataFrame,
    bed_values: List[float],
    num_repeats: int,
    shock_intensity: float,
    policy_config: SupplyStabilityConfig | None,
    upstream_nodes: set[str],
) -> pd.DataFrame:
    results = []
    for bed_idx, bed in enumerate(bed_values, start=1):
        for repeat in range(1, num_repeats + 1):
            sim_id = (bed_idx - 1) * num_repeats + repeat
            result = run_single_simulation(
                nodes_df=nodes_df,
                edges_df=edges_df,
                target_BED=bed,
                simulation_id=sim_id,
                shock_intensity=shock_intensity,
                shock_steps=5,
                recovery_steps=45,
                bankruptcy_threshold=0.5,
                max_cascade_rounds=15,
                verbose=False,
                policy_config=policy_config,
                policy_upstream_nodes=upstream_nodes,
            )
            result["scenario"] = scenario_name
            results.append(result)
    return pd.DataFrame(results)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run policy scenarios for dynamic resilience (shock=60% by default)."
    )
    parser.add_argument("--bed-start", type=float, default=0.30)
    parser.add_argument("--bed-end", type=float, default=0.90)
    parser.add_argument("--bed-step", type=float, default=0.01)
    parser.add_argument("--num-repeats", type=int, default=200)
    parser.add_argument("--shock-intensity", type=float, default=0.6)
    parser.add_argument("--contract-beta", type=float, default=0.8)
    parser.add_argument("--warning-threshold", type=float, default=0.7)
    parser.add_argument("--warning-slowdown", type=float, default=0.4)
    parser.add_argument("--buffer-gamma", type=float, default=0.3)
    parser.add_argument("--finance-boost", type=float, default=0.05)
    parser.add_argument("--output-tag", type=str, default="")
    args = parser.parse_args()

    paths = PathConfig()
    nodes_path = paths.get_input_file("battery_value_chain_nodes_personalized.csv")
    edges_path = paths.get_input_file("battery_value_chain_edges_personalized.csv")
    nodes_df = pd.read_csv(nodes_path, encoding="utf-8-sig")
    edges_df = pd.read_csv(edges_path, encoding="utf-8-sig")

    key_csv = paths.get_input_file("key_upstream_materials.csv")
    upstream_codes = load_key_upstream_material_codes(key_csv)
    upstream_nodes = resolve_upstream_nodes(nodes_df, upstream_codes)

    bed_values = _bed_values(args.bed_start, args.bed_end, args.bed_step)

    scenarios: Dict[str, SupplyStabilityConfig | None] = {
        "baseline": None,
        "supply_stability": SupplyStabilityConfig(
            enable_contract_floor=True,
            contract_beta=args.contract_beta,
            enable_early_warning=True,
            warning_threshold=args.warning_threshold,
            warning_slowdown=args.warning_slowdown,
        ),
        "inventory_buffer": SupplyStabilityConfig(
            enable_buffer=True,
            buffer_gamma=args.buffer_gamma,
            enable_finance_boost=True,
            finance_boost=args.finance_boost,
        ),
        "combined": SupplyStabilityConfig(
            enable_contract_floor=True,
            contract_beta=args.contract_beta,
            enable_early_warning=True,
            warning_threshold=args.warning_threshold,
            warning_slowdown=args.warning_slowdown,
            enable_buffer=True,
            buffer_gamma=args.buffer_gamma,
            enable_finance_boost=True,
            finance_boost=args.finance_boost,
        ),
    }

    tag = f"_{args.output_tag}" if args.output_tag else ""
    for name, config in scenarios.items():
        df = run_scenario(
            scenario_name=name,
            nodes_df=nodes_df,
            edges_df=edges_df,
            bed_values=bed_values,
            num_repeats=args.num_repeats,
            shock_intensity=args.shock_intensity,
            policy_config=config,
            upstream_nodes=upstream_nodes,
        )
        out_file = paths.results_data_dir / f"policy_scenario_{name}_shock{int(args.shock_intensity*100)}{tag}.csv"
        df.to_csv(out_file, index=False, encoding="utf-8-sig")
        print(f"[saved] {out_file}")


if __name__ == "__main__":
    main()
