#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Reproducible closed-loop recycling num_loops experiment + plotting.

Design goals:
- Keep legacy scripts untouched.
- Provide a single file to run the experiment and regenerate the figure.
- X-axis uses fixed path coverage: 100% == all 87 closed-loop edges.
- Figure style, axes, and 5 scenarios match the existing Nature-style chart.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
import random
import sys

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from scipy import stats

# Ensure src is importable
EXP_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(EXP_DIR))

from src.utils.path_config import PathConfig
from src.core.network_rewiring import rewire_network_to_target_BED
from src.core.cascade_failure import build_network_from_data
from src.core.ev_shock_recovery import (
    ev_demand_shock_gradual,
    recovery_simulation_with_ev,
)
from src.core.recycling_policy_improved import add_recycling_loops_strategy2_improved


# ---------------------------
# Configuration
# ---------------------------

BATTERY_NODE_CODE = "36901"
EV_NODE_CODE = "37111"

DEFAULT_SHOCK_INTENSITY = 0.6
DEFAULT_REPEATS = 100
SHOCK_STEPS = 5
RECOVERY_STEPS = 45
TOTAL_STEPS = SHOCK_STEPS + RECOVERY_STEPS
MAX_PERFORMANCE_LOSS = TOTAL_STEPS + 1
MAX_RECOVERY_RATE = (1.0 / RECOVERY_STEPS) * 100

# Match prior "closed-loop core" allocation used in recent runs
PROFIT_ALLOCATION = {
    "second-life": 0.45,
    "material recycling": 0.49,
    "secondary material": 0.06,
    "second life": 0.45,
}

# Nature Communications style (match existing script)
matplotlib.rcParams["font.family"] = "Arial"
matplotlib.rcParams["font.size"] = 11
matplotlib.rcParams["axes.labelsize"] = 12
matplotlib.rcParams["axes.titlesize"] = 14
matplotlib.rcParams["xtick.labelsize"] = 10
matplotlib.rcParams["ytick.labelsize"] = 10
matplotlib.rcParams["legend.fontsize"] = 10
matplotlib.rcParams["figure.dpi"] = 300
matplotlib.rcParams["savefig.dpi"] = 300
matplotlib.rcParams["savefig.bbox"] = "tight"
matplotlib.rcParams["savefig.pad_inches"] = 0.1
matplotlib.rcParams["savefig.facecolor"] = "white"
matplotlib.rcParams["savefig.edgecolor"] = "none"
matplotlib.rcParams["axes.linewidth"] = 1.2
matplotlib.rcParams["lines.linewidth"] = 2.0
matplotlib.rcParams["grid.linewidth"] = 0.5
matplotlib.rcParams["legend.frameon"] = True
matplotlib.rcParams["legend.framealpha"] = 0.95
matplotlib.rcParams["legend.edgecolor"] = "#333333"
matplotlib.rcParams["legend.fancybox"] = False
matplotlib.rcParams["xtick.major.width"] = 1.2
matplotlib.rcParams["ytick.major.width"] = 1.2
matplotlib.rcParams["xtick.major.size"] = 5
matplotlib.rcParams["ytick.major.size"] = 5
matplotlib.rcParams["xtick.direction"] = "in"
matplotlib.rcParams["ytick.direction"] = "in"

SMOOTH_COLOR_2035C = "#a30543"  # deep red
SMOOTH_COLOR_2030C = "#f36f43"  # orange
SMOOTH_COLOR_2035O = "#fbda83"  # light yellow
SMOOTH_COLOR_2030O = "#80cba4"  # light green
SMOOTH_COLOR_2025 = "#4965b0"   # blue


@dataclass(frozen=True)
class Scenario:
    name: str
    tag: str
    bed: float
    color: str
    label: str


SCENARIOS: List[Scenario] = [
    Scenario("2025 Baseline", "2025_baseline_original", 0.636, SMOOTH_COLOR_2025, "2025 Baseline"),
    Scenario("2030 Conservative", "2030_conservative", 0.612, SMOOTH_COLOR_2030C, "2030 Conservative"),
    Scenario("2030 Optimistic", "2030_optimistic", 0.457, SMOOTH_COLOR_2030O, "2030 Optimistic"),
    Scenario("2035 Conservative", "2035_conservative", 0.581, SMOOTH_COLOR_2035C, "2035 Conservative"),
    Scenario("2035 Optimistic", "2035_optimistic", 0.440, SMOOTH_COLOR_2035O, "2035 Optimistic"),
]


# ---------------------------
# Data helpers
# ---------------------------

def _pick_first_existing(columns: Iterable[str], candidates: List[str]) -> Optional[str]:
    for name in candidates:
        if name in columns:
            return name
    return None


def build_name_to_code_map(nodes_df: pd.DataFrame) -> Dict[str, str]:
    name_cols = [
        "Industry_Name_EN",
        "Label",
        "Industry_Name_CN",
        "Industry_Name_JP",
        "Industry_Abbr",
    ]
    code_col = _pick_first_existing(nodes_df.columns, ["Industry_Code", "Node_Code", "Id", "Node"])
    if code_col is None:
        raise ValueError("Cannot find node code column in nodes file.")

    mapping: Dict[str, str] = {}
    for _, row in nodes_df.iterrows():
        code = str(row.get(code_col, "")).strip()
        if not code:
            continue
        for col in name_cols:
            val = str(row.get(col, "")).strip()
            if val:
                mapping[val.lower()] = code
    return mapping


def load_legacy_name_to_code_map(legacy_nodes_csv: Path) -> Dict[str, str]:
    if not legacy_nodes_csv.exists():
        return {}
    df = pd.read_csv(legacy_nodes_csv, encoding="utf-8-sig")
    if "Id" not in df.columns:
        return {}
    mapping: Dict[str, str] = {}
    for _, row in df.iterrows():
        code = str(row.get("Id", "")).strip()
        if not code:
            continue
        for col in ["Label", "Abbreviation"]:
            val = str(row.get(col, "")).strip()
            if val:
                mapping[val.lower()] = code
    return mapping


def load_closedloop_edges(
    csv_path: Path,
    name_to_code: Dict[str, str],
    profit_allocation: Dict[str, float],
) -> List[Tuple[str, str, str, float]]:
    df = pd.read_csv(csv_path, encoding="utf-8-sig")
    if df.shape[1] < 2:
        raise ValueError(f"Closed-loop edges file must have at least 2 columns: {csv_path}")

    source_col = df.columns[0]
    target_col = df.columns[1]
    type_col = df.columns[2] if df.shape[1] >= 3 else None

    paths: List[Tuple[str, str, str, float]] = []
    missing_names = set()

    for _, row in df.iterrows():
        source_raw = str(row[source_col]).strip()
        target_raw = str(row[target_col]).strip()
        edge_type = str(row[type_col]).strip() if type_col else "DR"

        source_code = name_to_code.get(source_raw.lower())
        target_code = name_to_code.get(target_raw.lower())

        if not source_code:
            missing_names.add(source_raw)
            source_code = source_raw
        if not target_code:
            missing_names.add(target_raw)
            target_code = target_raw

        key = edge_type.lower().strip()
        multiplier = profit_allocation.get(key, profit_allocation.get(edge_type, 1.0))

        paths.append((target_code, source_code, edge_type, multiplier))

    if missing_names:
        missing_preview = ", ".join(sorted(list(missing_names))[:10])
        raise ValueError(
            f"Unmapped node names in closed-loop edges file (showing up to 10): {missing_preview}"
        )

    return paths


# ---------------------------
# Simulation
# ---------------------------

def calculate_dynamic_resilience_metrics(
    performance_trajectory_shock: List[float],
    performance_trajectory_recovery: List[float],
) -> Dict[str, float]:
    complete_trajectory = performance_trajectory_shock + performance_trajectory_recovery
    ES_0 = complete_trajectory[0]
    ER = min(complete_trajectory)
    tr = complete_trajectory.index(ER)
    ES_te = complete_trajectory[-1]
    te = len(complete_trajectory) - 1
    ERR = (ES_te - ER) / (te - tr) if te > tr else 0.0

    EPL = 0.0
    for t in range(0, te + 1):
        loss_t = ES_0 - complete_trajectory[t]
        if loss_t > 0:
            EPL += loss_t

    return {
        "ER": ER,
        "ERR": ERR,
        "EPL": EPL,
        "tr": tr,
        "te": te,
        "ES_0": ES_0,
        "ES_te": ES_te,
        "complete_trajectory": complete_trajectory,
        "Robustness": ER / ES_0 if ES_0 > 0 else 0.0,
        "Recovery_Rate": ERR,
        "Performance_Loss": EPL,
    }


def run_single_simulation(
    nodes_df: pd.DataFrame,
    edges_df: pd.DataFrame,
    num_recycling_loops: int,
    simulation_id: int,
    target_BED: float,
    retired_battery_price: float,
    shock_intensity: float,
    custom_paths: List[Tuple[str, str, str, float]],
) -> Dict[str, float]:
    np.random.seed(42 + simulation_id)
    random.seed(42 + simulation_id)

    edges_adjusted, BED_achieved, _ = rewire_network_to_target_BED(
        nodes_df, edges_df, target_BED, verbose=False, validate_bilateral_conservation=False
    )

    G_base = build_network_from_data(nodes_df, edges_adjusted)

    G_with_recycling, recycling_stats = add_recycling_loops_strategy2_improved(
        G=G_base,
        num_loops=num_recycling_loops,
        recycling_intensity=1.0,
        battery_node=BATTERY_NODE_CODE,
        ev_node=EV_NODE_CODE,
        retired_battery_price=retired_battery_price,
        custom_paths=custom_paths,
        verbose=False,
        export_log=False,
    )

    G_after_shock, shock_stats = ev_demand_shock_gradual(
        G=G_with_recycling.copy(),
        G_original=G_with_recycling,
        ev_node=EV_NODE_CODE,
        shock_steps=SHOCK_STEPS,
        shock_intensity=shock_intensity,
        bankruptcy_threshold=0.5,
        steepness=10.0,
        max_cascade_rounds=15,
        verbose=False,
    )

    recovery_stats = recovery_simulation_with_ev(
        G_current=G_after_shock,
        G_original=G_with_recycling,
        failed_nodes=shock_stats["total_failed_nodes"],
        ev_node=EV_NODE_CODE,
        p_recover=0.05,
        recovery_steps=RECOVERY_STEPS,
        noise_level=0.10,
        recovery_threshold=0.9,
        verbose=False,
    )

    metrics = calculate_dynamic_resilience_metrics(
        performance_trajectory_shock=shock_stats["performance_trajectory_shock"],
        performance_trajectory_recovery=recovery_stats["performance_trajectory_recovery"],
    )

    return {
        "simulation_id": simulation_id,
        "BED_target": target_BED,
        "BED_achieved": BED_achieved,
        "num_recycling_loops": num_recycling_loops,
        "recycling_intensity": 1.0,
        "recycling_scale": recycling_stats["total_recycling_weight"],
        "shock_intensity": shock_intensity,
        "retired_battery_price": retired_battery_price,
        "strategy": "strategy2_num_loops",
        "Robustness": metrics["Robustness"],
        "Recovery_Rate": metrics["Recovery_Rate"],
        "Performance_Loss": metrics["Performance_Loss"],
        "tr": metrics["tr"],
        "ES_0": metrics["ES_0"],
        "ES_te": metrics["ES_te"],
        "num_failed_nodes": shock_stats["num_failed_nodes"],
        "num_recovered_nodes": recovery_stats["remaining_failed_nodes"],
        "ev_recovered": recovery_stats["ev_recovered"],
        "recovery_time": recovery_stats["recovery_time"],
    }


def run_scenario_experiment(
    scenario: Scenario,
    nodes_df: pd.DataFrame,
    edges_df: pd.DataFrame,
    custom_paths: List[Tuple[str, str, str, float]],
    num_loops_start: int,
    num_loops_end: int,
    shock_intensity: float,
    num_repeats: int,
    retired_battery_price: float,
    output_dir: Path,
) -> Tuple[Path, Path]:
    max_loops = len(custom_paths)
    if num_loops_end <= 0:
        num_loops_end = max_loops
    num_loops_end = min(num_loops_end, max_loops)
    if num_loops_end < num_loops_start:
        raise ValueError(f"Invalid num_loops range: {num_loops_start}-{num_loops_end}")

    num_loops_values = list(range(num_loops_start, num_loops_end + 1))
    total_simulations = len(num_loops_values) * num_repeats

    print("=" * 80)
    print("Recycling num_loops experiment (reproducible)")
    print("=" * 80)
    print(f"Scenario: {scenario.name} (BED={scenario.bed})")
    print(f"num_loops: {num_loops_start}-{num_loops_end}")
    print(f"shock_intensity: {shock_intensity}")
    print(f"repeats: {num_repeats}")
    print(f"total simulations: {total_simulations}")
    print("=" * 80)

    all_results: List[Dict[str, float]] = []
    current_sim = 0

    for i, num_loops in enumerate(num_loops_values, 1):
        print(f"\n  num_loops = {num_loops} ({i}/{len(num_loops_values)})")
        for repeat in range(1, num_repeats + 1):
            current_sim += 1
            sim_id = (i - 1) * num_repeats + repeat
            if current_sim % 10 == 0:
                pct = (current_sim / total_simulations) * 100
                print(f"    repeat {repeat}/{num_repeats} (progress {pct:.1f}%)")

            result = run_single_simulation(
                nodes_df=nodes_df,
                edges_df=edges_df,
                num_recycling_loops=num_loops,
                simulation_id=sim_id,
                target_BED=scenario.bed,
                retired_battery_price=retired_battery_price,
                shock_intensity=shock_intensity,
                custom_paths=custom_paths,
            )
            all_results.append(result)

    results_df = pd.DataFrame(all_results)
    summary_df = results_df.groupby(["num_recycling_loops", "shock_intensity"]).agg({
        "Robustness": ["mean", "std"],
        "Recovery_Rate": ["mean", "std"],
        "Performance_Loss": ["mean", "std"],
        "recovery_time": ["mean", "std"],
        "num_failed_nodes": ["mean", "std"],
    }).reset_index()

    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    full_file = output_dir / f"recycling_num_loops_experiment_v2_{scenario.tag}_{timestamp}.csv"
    summary_file = output_dir / f"recycling_num_loops_summary_v2_{scenario.tag}_{timestamp}.csv"

    results_df.to_csv(full_file, index=False, encoding="utf-8-sig")
    summary_df.to_csv(summary_file, index=False, encoding="utf-8-sig")

    print(f"\n[OK] Full results: {full_file}")
    print(f"[OK] Summary: {summary_file}")
    return full_file, summary_file


# ---------------------------
# Plotting
# ---------------------------

def transform_to_path_coverage(num_loops: np.ndarray, total_loops: int) -> np.ndarray:
    return (num_loops / total_loops) * 100


def aggregate_with_ci(df: pd.DataFrame, group_cols: List[str], value_col: str, alpha: float = 0.05) -> pd.DataFrame:
    grouped = df.groupby(group_cols)[value_col].agg(["mean", "std", "count"]).reset_index()
    grouped["ci"] = grouped.apply(
        lambda row: stats.t.ppf(1 - alpha / 2, row["count"] - 1) * row["std"] / np.sqrt(row["count"])
        if row["count"] > 1 else 0,
        axis=1,
    )
    grouped["ci_lower"] = grouped["mean"] - grouped["ci"]
    grouped["ci_upper"] = grouped["mean"] + grouped["ci"]
    return grouped


def resolve_scenario_files(
    results_dir: Path,
    scenario_list: List[Scenario],
    explicit: Dict[str, str],
) -> Dict[str, Path]:
    resolved: Dict[str, Path] = {}
    for scenario in scenario_list:
        if scenario.name in explicit:
            path = results_dir / explicit[scenario.name]
            if not path.exists():
                raise FileNotFoundError(f"Explicit file not found for {scenario.name}: {path}")
            resolved[scenario.name] = path
            continue

        pattern = f"recycling_num_loops_experiment_v2_{scenario.tag}_*.csv"
        candidates = sorted(results_dir.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
        if not candidates:
            raise FileNotFoundError(f"No result file found for {scenario.name} with pattern {pattern}")
        resolved[scenario.name] = candidates[0]
    return resolved


def plot_path_coverage_vs_resilience(
    results_dir: Path,
    figures_dir: Path,
    scenario_list: List[Scenario],
    total_loops: int,
    explicit_files: Dict[str, str],
    show_node_attrition: bool = False,
    one_row_layout: bool = True,
    output_base: str = "path_coverage_vs_resilience_BED0.8_nature_style",
) -> Path:
    scenario_files = resolve_scenario_files(results_dir, scenario_list, explicit_files)

    metrics_all = [
        ("num_failed_nodes", "Value Node Attrition", "D"),
        ("Robustness", "Value Sustenance Floor", "o"),
        ("Performance_Loss", "Cumulative Economic Cost", "^"),
        ("Recovery_Rate", "Economic Resilience Speed", "s"),
    ]
    metrics = metrics_all if show_node_attrition else metrics_all[1:]

    y_labels = {
        "num_failed_nodes": "Failed Nodes (%)",
        "Robustness": "Robustness (%)",
        "Performance_Loss": "Performance Loss (%)",
        "Recovery_Rate": "Recovery Rate (%)",
    }

    TOTAL_NODES = 100

    scenario_data = {}
    for scenario in scenario_list:
        file_path = scenario_files[scenario.name]
        df = pd.read_csv(file_path)
        ES_0_MEAN = df["ES_0"].mean() if "ES_0" in df.columns else 1.0

        metric_data = {}
        for col_name, _, _ in metrics:
            df_agg = aggregate_with_ci(df, group_cols=["num_recycling_loops"], value_col=col_name)

            if col_name == "num_failed_nodes":
                df_agg["mean"] = df_agg["mean"] / TOTAL_NODES * 100
                df_agg["ci_lower"] = df_agg["ci_lower"] / TOTAL_NODES * 100
                df_agg["ci_upper"] = df_agg["ci_upper"] / TOTAL_NODES * 100
            elif col_name == "Robustness":
                df_agg["mean"] = df_agg["mean"] * 100
                df_agg["ci_lower"] = df_agg["ci_lower"] * 100
                df_agg["ci_upper"] = df_agg["ci_upper"] * 100
            elif col_name == "Performance_Loss":
                df_agg["mean"] = (df_agg["mean"] / ES_0_MEAN / MAX_PERFORMANCE_LOSS) * 100
                df_agg["ci_lower"] = (df_agg["ci_lower"] / ES_0_MEAN / MAX_PERFORMANCE_LOSS) * 100
                df_agg["ci_upper"] = (df_agg["ci_upper"] / ES_0_MEAN / MAX_PERFORMANCE_LOSS) * 100
            elif col_name == "Recovery_Rate":
                df_agg["mean"] = (df_agg["mean"] / ES_0_MEAN / MAX_RECOVERY_RATE) * 10000
                df_agg["ci_lower"] = (df_agg["ci_lower"] / ES_0_MEAN / MAX_RECOVERY_RATE) * 10000
                df_agg["ci_upper"] = (df_agg["ci_upper"] / ES_0_MEAN / MAX_RECOVERY_RATE) * 10000

            x_raw = df_agg["num_recycling_loops"].values
            y = df_agg["mean"].values
            degree = 2 if len(np.unique(x_raw)) >= 3 else max(1, len(np.unique(x_raw)) - 1)
            coeffs = np.polyfit(x_raw, y, deg=degree)
            x_dense = np.linspace(x_raw.min(), x_raw.max(), 200)
            y_fit = np.polyval(coeffs, x_dense)

            metric_data[col_name] = {
                "df_agg": df_agg,
                "x_dense": x_dense,
                "y_fit": y_fit,
            }

        scenario_data[scenario.name] = metric_data

    if one_row_layout:
        fig, axes = plt.subplots(3, 1, figsize=(5.5, 9.5), dpi=300)
    else:
        fig, axes = plt.subplots(2, 2, figsize=(7.5, 5.5), dpi=300)
    axes_flat = axes.flatten() if hasattr(axes, "flatten") else [axes]

    for idx, (col_name, display_name, marker) in enumerate(metrics):
        ax = axes_flat[idx]
        for scenario in scenario_list:
            metric_data = scenario_data[scenario.name][col_name]
            df_plot = metric_data["df_agg"]

            x_plot = transform_to_path_coverage(metric_data["x_dense"], total_loops)
            ax.plot(
                x_plot,
                metric_data["y_fit"],
                color=scenario.color,
                linewidth=2.5,
                linestyle="-",
                zorder=3,
                label=scenario.label,
            )

        ax.set_ylabel(y_labels[col_name], fontsize=12, fontweight="bold")
        ax.set_xlabel("Path Coverage Rate (%)", fontsize=12, fontweight="bold")
        subplot_label = chr(97 + idx)
        ax.set_title(f"({subplot_label}) {display_name}", fontsize=14, fontweight="bold", loc="left")

        ax.grid(True, alpha=0.3, linestyle="--", linewidth=0.5, color="#BDBDBD", zorder=0)
        ax.set_axisbelow(True)
        for spine in ax.spines.values():
            spine.set_linewidth(1.2)

    handles, labels = axes_flat[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.08),
        ncol=1,
        frameon=True,
        framealpha=0.95,
        edgecolor="#333333",
        facecolor="white",
        fancybox=False,
        fontsize=10,
        shadow=False,
        columnspacing=1.5,
    )

    plt.tight_layout(rect=[0, 0.08, 1, 1])

    figures_dir.mkdir(parents=True, exist_ok=True)
    png_file = figures_dir / f"{output_base}.png"
    pdf_file = figures_dir / f"{output_base}.pdf"

    fig.savefig(png_file, dpi=300, bbox_inches="tight", pad_inches=0.1, facecolor="white", edgecolor="none")
    fig.savefig(pdf_file, format="pdf", bbox_inches="tight", pad_inches=0.1, facecolor="white", edgecolor="none")
    plt.close(fig)

    return png_file


# ---------------------------
# CLI
# ---------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Reproducible num_loops recycling experiment + plot")
    parser.add_argument("--run-experiment", action="store_true", help="Run simulations and write results CSVs")
    parser.add_argument("--plot", action="store_true", help="Generate figure from results CSVs")
    parser.add_argument("--scenarios", type=str, default="", help="Comma-separated scenario tags to run/plot")
    parser.add_argument("--num-loops-start", type=int, default=1)
    parser.add_argument("--num-loops-end", type=int, default=0, help="0 means auto (all closed-loop edges)")
    parser.add_argument("--shock", type=float, default=DEFAULT_SHOCK_INTENSITY)
    parser.add_argument("--repeats", type=int, default=DEFAULT_REPEATS)
    parser.add_argument("--retired-battery-price", type=float, default=138.0)
    parser.add_argument("--closedloop-csv", type=str, default="")
    parser.add_argument("--total-loops", type=int, default=0, help="Override total loops for path coverage")
    parser.add_argument("--with-node-attrition", action="store_true")
    parser.add_argument("--layout-2x2", action="store_true")
    parser.add_argument("--file-map", type=str, default="", help="Explicit files mapping: ScenarioName=filename,...")
    parser.add_argument("--output-base", type=str, default="path_coverage_vs_resilience_BED0.8_nature_style")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not args.run_experiment and not args.plot:
        args.plot = True

    paths = PathConfig()

    nodes_path = paths.get_input_file("battery_value_chain_nodes_recalculated.csv")
    edges_path = paths.get_input_file("battery_value_chain_edges_personalized.csv")
    results_dir = paths.results_data_dir
    figures_dir = paths.results_figures_dir

    nodes_df = pd.read_csv(nodes_path, encoding="utf-8-sig")
    edges_df = pd.read_csv(edges_path, encoding="utf-8-sig")

    name_to_code = build_name_to_code_map(nodes_df)
    legacy_nodes_csv = paths.base_dir / "data" / "input" / "legacy" / "original_data" / "nodes.csv"
    legacy_map = load_legacy_name_to_code_map(legacy_nodes_csv)
    for k, v in legacy_map.items():
        name_to_code.setdefault(k, v)

    if args.closedloop_csv:
        closedloop_csv = Path(args.closedloop_csv)
    else:
        # default: repo root (d:\Desktop\network\recycling_edges_core_closedloop.csv)
        closedloop_csv = paths.base_dir.parent / "recycling_edges_core_closedloop.csv"

    custom_paths = load_closedloop_edges(closedloop_csv, name_to_code, PROFIT_ALLOCATION)

    total_loops = args.total_loops if args.total_loops > 0 else len(custom_paths)

    selected = [s for s in SCENARIOS]
    if args.scenarios.strip():
        allow = {t.strip() for t in args.scenarios.split(",") if t.strip()}
        selected = [s for s in SCENARIOS if s.tag in allow]
        if not selected:
            raise ValueError(f"No scenarios matched tags: {args.scenarios}")

    if args.run_experiment:
        for scenario in selected:
            run_scenario_experiment(
                scenario=scenario,
                nodes_df=nodes_df,
                edges_df=edges_df,
                custom_paths=custom_paths,
                num_loops_start=args.num_loops_start,
                num_loops_end=args.num_loops_end,
                shock_intensity=args.shock,
                num_repeats=args.repeats,
                retired_battery_price=args.retired_battery_price,
                output_dir=results_dir,
            )

    if args.plot:
        explicit_files = {}
        if args.file_map.strip():
            for pair in args.file_map.split(","):
                if "=" not in pair:
                    continue
                name, file_name = pair.split("=", 1)
                explicit_files[name.strip()] = file_name.strip()

        png_file = plot_path_coverage_vs_resilience(
            results_dir=results_dir,
            figures_dir=figures_dir,
            scenario_list=selected,
            total_loops=total_loops,
            explicit_files=explicit_files,
            show_node_attrition=args.with_node_attrition,
            one_row_layout=not args.layout_2x2,
            output_base=args.output_base,
        )
        print(f"[OK] Figure saved: {png_file}")


if __name__ == "__main__":
    main()
