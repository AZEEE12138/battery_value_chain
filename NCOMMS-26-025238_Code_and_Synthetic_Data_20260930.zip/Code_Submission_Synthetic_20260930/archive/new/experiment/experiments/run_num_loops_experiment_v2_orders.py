# -*- coding: utf-8 -*-
"""
按给定回收边排序文件逐个运行资源循环实验（不修改原实验逻辑）。
使用 run_num_loops_experiment_v2.py 的 run_full_experiment，并在每次运行前
替换 CUSTOM_RECYCLING_PATHS 为指定排序文件加载的路径列表。
"""
from __future__ import annotations

from pathlib import Path
import importlib.util
import sys

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from src.utils.path_config import PathConfig
from src.core.recycling_policy_improved import load_recycling_edges_from_csv


def load_runner_module():
    module_path = Path(__file__).resolve().parent / "run_num_loops_experiment_v2.py"
    spec = importlib.util.spec_from_file_location("run_num_loops_experiment_v2", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载模块: {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_paths_from_csv(csv_path: Path):
    profit_allocation = {
        "second-life": 0.45,
        "material recycling": 0.49,
        "secondary material": 0.06,
        "second life": 0.45,
    }
    return load_recycling_edges_from_csv(
        csv_path,
        profit_allocation=profit_allocation,
        use_first_three_cols=True,
    )


def main():
    paths = PathConfig()
    outputs_dir = paths.data_outputs_dir

    order_files = [
        ("type", outputs_dir / "recycling_edges_sorted_type.csv"),
        ("hub", outputs_dir / "recycling_edges_sorted_hub.csv"),
        ("reverse_logistics", outputs_dir / "recycling_edges_sorted_reverse_logistics.csv"),
        ("balanced", outputs_dir / "recycling_edges_sorted_balanced.csv"),
        ("economic", outputs_dir / "recycling_edges_sorted_economic.csv"),
    ]

    for tag, fpath in order_files:
        if not fpath.exists():
            raise FileNotFoundError(f"排序文件不存在: {fpath}")

    runner = load_runner_module()

    scenarios = [
        ("2025_baseline", 0.636),
        ("2030_conservative", 0.612),
        ("2030_optimistic", 0.457),
        ("2035_conservative", 0.581),
        ("2035_optimistic", 0.440),
    ]

    for order_tag, order_file in order_files:
        print("\n" + "=" * 80)
        print(f"排序方案: {order_tag}")
        print(f"排序文件: {order_file}")
        print("=" * 80)

        custom_paths = load_paths_from_csv(order_file)
        runner.CUSTOM_RECYCLING_PATHS = custom_paths

        for scenario_tag, bed in scenarios:
            full_tag = f"{order_tag}_{scenario_tag}"
            print("\n" + "-" * 80)
            print(f"开始情景: {full_tag}, BED={bed}")
            print("-" * 80)
            runner.run_full_experiment(
                num_loops_range=(1, 0),
                shock_intensities=[0.6],
                num_repeats=100,
                target_BED=bed,
                retired_battery_price=138.0,
                scenario_tag=full_tag,
                verbose=False,
            )


if __name__ == "__main__":
    main()
