#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
2035年乐观情境实验 - BED=0.440
基于 run_num_loops_experiment_v2.py

情境说明：
- 乐观情境代表BED持续下降，供应链高度多元化，韧性大幅提升
- BED=0.440 (44.0%)，比2030年乐观(45.7%)下降1.7%，比2025年(63.6%)下降19.6%
- 来源: BED_timeseries_sci.png中的乐观情境2035年数据点

实验参数：
1. 固定BED=0.440（2035年乐观情境）
2. num_loops: 1-ALL（自动使用可用回收边）
3. 冲击强度: 0.6 (60%，固定值)
4. 每条边重复100次
5. 总模拟次数: num_loops × 1 × 100


日期: 2025-12-25
"""

import sys
import os
from pathlib import Path

# 设置项目根目录
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

# 导入主实验模块
from experiments.run_num_loops_experiment_v2 import run_full_experiment

def main():
    """运行2035年乐观情境实验"""

    print("\n" + "="*80)
    print("2035年乐观情境实验 (BED=0.440)")
    print("="*80)
    print("\n情境说明:")
    print("  - 乐观情境: BED持续下降，供应链高度多元化")
    print("  - BED: 0.440 (44.0%)")
    print("  - 相比2030年乐观(45.7%)下降: -1.7%")
    print("  - 相比2025年(63.6%)下降: -19.6%")
    print("  - 数据来源: BED_timeseries_sci.png乐观情境2035年值")
    print("\n实验配置:")
    print("  - 回收边数: 1-ALL (自动使用可用回收边)")
    print("  - 冲击强度: 60% (固定)")
    print("  - 重复次数: 100次/边")
    print("  - 总模拟: 7,000次")
    print("\n" + "="*80 + "\n")

    results_df = run_full_experiment(
        num_loops_range=(1, 0),
        shock_intensities=[0.6],
        num_repeats=100,
        target_BED=0.440,  # ⭐ 2035年乐观情境BED值 (来自BED_timeseries_sci.png)
        retired_battery_price=138.0,
        verbose=False
    )

    # 显示结果摘要
    print("\n结果预览:")
    print(results_df[['num_recycling_loops', 'shock_intensity', 'Robustness', 'Recovery_Rate', 'Performance_Loss']].head(10).to_string())

    print("\n统计摘要:")
    summary = results_df.groupby(['num_recycling_loops']).agg({
        'Robustness': ['mean', 'std'],
        'Recovery_Rate': ['mean', 'std'],
        'Performance_Loss': ['mean', 'std']
    }).head(10)
    print(summary.to_string())

    print("\n" + "="*80)
    print("2035年乐观情境实验完成！")
    print("="*80)

if __name__ == '__main__':
    main()
