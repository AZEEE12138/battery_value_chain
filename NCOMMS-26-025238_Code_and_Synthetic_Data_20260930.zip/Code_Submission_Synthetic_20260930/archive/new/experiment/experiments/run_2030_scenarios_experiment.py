#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
2030年6种场景动态韧性模拟实验

场景设计：
- 乐观情景 (Optimistic): BED=0.457 (45.7%)
- 保守情景 (Conservative): BED=0.612 (61.2%)
- 冲击强度: 40%, 60%, 80%
- 每种场景重复200次

总模拟次数: 6场景 × 200次 = 1200次


日期: 2026-02-03
"""

import sys
import os
from pathlib import Path
from datetime import datetime

# Windows 输出优化配置
if sys.platform == 'win32':
    os.environ.setdefault('PYTHONUNBUFFERED', '1')
    os.environ.setdefault('PYTHONIOENCODING', 'utf-8')
    if sys.stdout is not None and hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace', line_buffering=True)
    if sys.stderr is not None and hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8', errors='replace', line_buffering=True)

# 设置项目根目录
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

# 导入主实验模块
from experiments.run_resilience_simulation import run_full_experiment
from src.utils.path_config import PathConfig


def main():
    """运行2030年6种场景实验"""

    print("\n" + "="*80, flush=True)
    print("2030年6种场景动态韧性模拟实验", flush=True)
    print("="*80, flush=True)
    print(f"\n开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", flush=True)

    # 场景配置（基于zhanbi.csv 2030年数据）
    scenarios = [
        {
            "name": "optimistic",
            "bed": 0.457,  # 45.7%
            "description": "乐观情景：储能高增分流，EV依赖度降低"
        },
        {
            "name": "conservative",
            "bed": 0.612,  # 61.2%
            "description": "保守情景：EV部门非线性增长，依赖度仍较高"
        }
    ]

    shock_intensities = [0.4, 0.6, 0.8]  # 40%, 60%, 80%
    num_repeats = 200  # 每种场景200次重复

    print("\n实验配置:", flush=True)
    print(f"  场景数量: {len(scenarios)}", flush=True)
    print(f"  冲击强度: {[f'{int(s*100)}%' for s in shock_intensities]}", flush=True)
    print(f"  重复次数: {num_repeats}", flush=True)
    print(f"  总模拟次数: {len(scenarios) * len(shock_intensities) * num_repeats}", flush=True)
    print("="*80 + "\n", flush=True)

    paths = PathConfig()

    # 运行每个场景
    for scenario_idx, scenario in enumerate(scenarios, 1):
        print(f"\n{'='*80}", flush=True)
        print(f"场景 {scenario_idx}/{len(scenarios)}: {scenario['name'].upper()}", flush=True)
        print(f"{'='*80}", flush=True)
        print(f"  BED值: {scenario['bed']:.3f} ({scenario['bed']*100:.1f}%)", flush=True)
        print(f"  描述: {scenario['description']}", flush=True)
        print(f"{'='*80}\n", flush=True)

        for shock_idx, shock in enumerate(shock_intensities, 1):
            print(f"\n{'-'*80}", flush=True)
            print(f"  冲击强度 {shock_idx}/{len(shock_intensities)}: {int(shock*100)}%", flush=True)
            print(f"{'-'*80}", flush=True)

            start_time = datetime.now()
            print(f"  开始时间: {start_time.strftime('%H:%M:%S')}", flush=True)

            # 运行实验
            results_df = run_full_experiment(
                bed_start=scenario["bed"],
                bed_end=scenario["bed"],
                bed_step=0.01,  # 只运行单个BED值
                shock_intensities=[shock],
                num_repeats=num_repeats,
                max_cascade_rounds=15,
                bankruptcy_threshold=0.5,
                verbose=False
            )

            # 保存结果
            output_file = f"battery_chain_resilience_results_2030_{scenario['name']}_shock{int(shock*100)}.csv"
            output_path = paths.results_data_dir / output_file
            results_df.to_csv(output_path, index=False, encoding='utf-8-sig')

            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()

            print(f"  完成时间: {end_time.strftime('%H:%M:%S')}", flush=True)
            print(f"  耗时: {duration/60:.1f} 分钟", flush=True)
            print(f"  结果已保存: {output_file}", flush=True)
            print(f"  记录数: {len(results_df)}", flush=True)

            # 显示简要统计
            print(f"\n  统计摘要:", flush=True)
            print(f"    失效节点数 - 平均: {results_df['failed_nodes_shock'].mean():.1f}, "
                  f"中位数: {results_df['failed_nodes_shock'].median():.1f}", flush=True)
            print(f"    稳健性 - 平均: {results_df['Robustness'].mean():.4f}, "
                  f"中位数: {results_df['Robustness'].median():.4f}", flush=True)
            print(f"{'-'*80}\n", flush=True)

    print("\n" + "="*80, flush=True)
    print("所有实验完成！", flush=True)
    print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", flush=True)
    print("="*80 + "\n", flush=True)

    print("生成的文件:", flush=True)
    for scenario in scenarios:
        for shock in shock_intensities:
            output_file = f"battery_chain_resilience_results_2030_{scenario['name']}_shock{int(shock*100)}.csv"
            print(f"  - {output_file}", flush=True)


if __name__ == '__main__':
    main()
