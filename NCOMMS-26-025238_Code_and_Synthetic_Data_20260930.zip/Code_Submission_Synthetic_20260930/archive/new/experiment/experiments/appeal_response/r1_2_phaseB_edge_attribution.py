# -*- coding: utf-8 -*-
"""
R1.2 阶段B：把最终 739 条边按确定性选边规则归因，定位走廊三段边落在哪一层
================================================================================

方法：直接复用构网脚本 extract_battery_value_chain_semantic.py 里的确定性规则
should_include_edge()，对现有 739 条边逐条重跑，得到每条边的判定(确定保留 True /
待人工审核 REVIEW / 本应剔除 False)与原因。

关键产出：
1. 739 条边中"确定性保留"vs"人工审核残差(REVIEW)"的占比；
2. 走廊三段边 BM(36901)->IEEW(40621)->LRAM(33501)/ONRAM(33509) 各自属于哪一层——
   若全部落在确定性保留层，即可正面回应"走廊不是人工挑边挑出来的"。
"""
import sys
import importlib.util
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]  # new/experiment/
sys.path.insert(0, str(BASE_DIR))

import pandas as pd

# 动态导入构网脚本中的确定性规则(不改动原脚本)
EXTRACT_PATH = BASE_DIR / 'scripts' / 'data_processing' / 'edges' / 'extract_battery_value_chain_semantic.py'
spec = importlib.util.spec_from_file_location('extract_semantic', EXTRACT_PATH)
extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(extract)
should_include_edge = extract.should_include_edge

from src.utils.path_config import PathConfig  # noqa: E402

BM, IEEW, LRAM, ONRAM = '36901', '40621', '33501', '33509'
CORRIDOR_NODES = {BM: 'BM(蓄电池)', IEEW: 'IEEW(工业电气批发)',
                  LRAM: 'LRAM(铅再生合金)', ONRAM: 'ONRAM(其他再生合金)'}

OUT_DIR = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'


def main():
    paths = PathConfig()
    edges = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'),
                        encoding='utf-8-sig')
    print(f"[载入] 最终网络边数={len(edges)}", flush=True)

    rows = []
    for _, e in edges.iterrows():
        sc = int(e['Source_Code']); tc = int(e['Target_Code'])
        s, t = str(sc), str(tc)
        decision, reason = should_include_edge(s, t, sc, tc)
        if decision is True:
            tier = '确定性保留'
        elif decision == 'REVIEW':
            tier = '人工审核残差'
        else:
            tier = '规则本应剔除(异常)'
        rows.append({'Source_Code': sc, 'Target_Code': tc,
                     'Source_Name_EN': e.get('Source_Name_EN', ''),
                     'Target_Name_EN': e.get('Target_Name_EN', ''),
                     'Weight': e['Weight'], 'tier': tier, 'reason': reason})
    attr = pd.DataFrame(rows)
    attr.to_csv(OUT_DIR / 'edge_rule_attribution.csv', index=False, encoding='utf-8-sig')

    print("\n===== 739条边按规则层归因 =====", flush=True)
    tier_counts = attr['tier'].value_counts()
    for tier, n in tier_counts.items():
        print(f"  {tier}: {n} 条 ({n/len(attr)*100:.1f}%)", flush=True)

    print("\n===== 确定性保留边的原因分布 =====", flush=True)
    for reason, n in attr[attr['tier'] == '确定性保留']['reason'].value_counts().items():
        print(f"  [{reason}] {n} 条", flush=True)

    if (attr['tier'] == '人工审核残差').any():
        print("\n===== 人工审核残差(REVIEW)边的原因分布 =====", flush=True)
        for reason, n in attr[attr['tier'] == '人工审核残差']['reason'].value_counts().items():
            print(f"  [{reason}] {n} 条", flush=True)

    # 走廊定位：列出所有涉及走廊节点的边及其归属
    print("\n===== 走廊相关边定位(涉及 BM/IEEW/LRAM/ONRAM 的全部边) =====", flush=True)
    cn = set(CORRIDOR_NODES.keys())
    corridor_edges = attr[(attr['Source_Code'].astype(str).isin(cn)) |
                          (attr['Target_Code'].astype(str).isin(cn))]
    # 精确检查走廊三段
    segments = [(BM, IEEW), (IEEW, LRAM), (IEEW, ONRAM),
                (BM, LRAM), (BM, ONRAM)]  # 附带直连段以防走廊实为BM直连
    print("  -- 走廊关键段是否存在及归属 --", flush=True)
    for s, t in segments:
        m = attr[(attr['Source_Code'].astype(str) == s) & (attr['Target_Code'].astype(str) == t)]
        label = f"{CORRIDOR_NODES.get(s,s)}→{CORRIDOR_NODES.get(t,t)}"
        if len(m):
            r = m.iloc[0]
            print(f"    {label}: 存在  层={r['tier']}  原因=[{r['reason']}]", flush=True)
        else:
            # 检查反向
            mr = attr[(attr['Source_Code'].astype(str) == t) & (attr['Target_Code'].astype(str) == s)]
            if len(mr):
                r = mr.iloc[0]
                print(f"    {label}: 正向不存在，但反向 {CORRIDOR_NODES.get(t,t)}→{CORRIDOR_NODES.get(s,s)} 存在  层={r['tier']}  原因=[{r['reason']}]", flush=True)
            else:
                print(f"    {label}: 不存在(正反向均无)", flush=True)

    print("\n  -- 涉及走廊节点的全部边(含归属) --", flush=True)
    for _, r in corridor_edges.iterrows():
        sname = CORRIDOR_NODES.get(str(r['Source_Code']), str(r['Source_Code']))
        tname = CORRIDOR_NODES.get(str(r['Target_Code']), str(r['Target_Code']))
        print(f"    {sname}→{tname}  层={r['tier']}  原因=[{r['reason']}]", flush=True)

    print(f"\n[输出] 归因表: {OUT_DIR / 'edge_rule_attribution.csv'}", flush=True)


if __name__ == '__main__':
    main()
