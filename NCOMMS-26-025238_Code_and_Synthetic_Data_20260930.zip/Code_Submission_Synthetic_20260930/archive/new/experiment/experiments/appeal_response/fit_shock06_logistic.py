# -*- coding: utf-8 -*-
"""
对 shock=0.6（对应论文原句"BED above 0.70 is sufficient to breach the same safety floor"）
做与 shock=0.8 同样严格的逻辑回归拟合，验证论文这条第二头条数字是否同样经得起统计检验。
"""
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent  # new/experiment/
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'experiments'))

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from run_resilience_simulation import run_single_simulation
from src.utils.path_config import PathConfig

paths = PathConfig()
nodes_df = pd.read_csv(paths.get_input_file('battery_value_chain_nodes_personalized.csv'), encoding='utf-8-sig')
edges_df = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'), encoding='utf-8-sig')


def main():
    print("固定 tau=0.5, beta=10.0, shock=0.6", flush=True)
    BED_GRID = [round(x, 2) for x in np.arange(0.30, 0.901, 0.02)]
    N = 40
    records = []
    sim_counter = 600000
    total = len(BED_GRID) * N
    done = 0
    for BED in BED_GRID:
        for r in range(N):
            sim_counter += 1
            res = run_single_simulation(
                nodes_df=nodes_df, edges_df=edges_df, target_BED=BED, simulation_id=sim_counter,
                shock_intensity=0.6, shock_steps=5, recovery_steps=45,
                bankruptcy_threshold=0.5, steepness=10.0, max_cascade_rounds=15, verbose=False,
            )
            collapsed = 1 if (res['Robustness'] * 100.0) < 50.0 else 0
            records.append((BED, collapsed))
            done += 1
        print(f"进度: BED={BED:.2f} 完成 ({done}/{total})", flush=True)
    df = pd.DataFrame(records, columns=['BED', 'collapsed'])

    X = df['BED'].values
    y = df['collapsed'].values

    def neg_log_lik(params):
        a, b = params
        z = a * (X - b)
        p = 1.0 / (1.0 + np.exp(-z))
        p = np.clip(p, 1e-9, 1 - 1e-9)
        return -np.sum(y * np.log(p) + (1 - y) * np.log(1 - p))

    result = minimize(neg_log_lik, x0=[10.0, 0.7], method='Nelder-Mead')
    a_hat, b_hat = result.x
    print(f"RESULT 逻辑回归拟合: 斜率a={a_hat:.3f}  中点b(BED*)={b_hat:.4f}", flush=True)

    boot_mids = []
    rng = np.random.default_rng(42)
    n_total = len(df)
    for _ in range(50):
        idx = rng.integers(0, n_total, n_total)
        Xb, yb = X[idx], y[idx]
        def nll_b(params):
            a, b = params
            z = a * (Xb - b)
            p = 1.0 / (1.0 + np.exp(-z))
            p = np.clip(p, 1e-9, 1 - 1e-9)
            return -np.sum(yb * np.log(p) + (1 - yb) * np.log(1 - p))
        r = minimize(nll_b, x0=[a_hat, b_hat], method='Nelder-Mead')
        boot_mids.append(r.x[1])
    boot_mids = np.array(boot_mids)
    ci_lo, ci_hi = np.percentile(boot_mids, [2.5, 97.5])
    print(f"RESULT 中点位置 95% Bootstrap置信区间: [{ci_lo:.4f}, {ci_hi:.4f}] (宽度={ci_hi-ci_lo:.4f})", flush=True)
    print(f"RESULT 论文声称的 BED=0.70 是否落在置信区间内 = {ci_lo <= 0.70 <= ci_hi}", flush=True)

    z_lo = a_hat * ((b_hat - 0.1) - b_hat)
    z_hi = a_hat * ((b_hat + 0.1) - b_hat)
    p_lo = 1 / (1 + np.exp(-z_lo))
    p_hi = 1 / (1 + np.exp(-z_hi))
    print(f"RESULT 中点±0.1的BED范围内，P(崩溃)从{p_lo:.2f}升到{p_hi:.2f}", flush=True)

    out_dir = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'
    df.to_csv(out_dir / 'logistic_fit_raw_shock06.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame({'a_hat': [a_hat], 'b_hat': [b_hat], 'ci_lo': [ci_lo], 'ci_hi': [ci_hi],
                  'p_at_mid-0.1': [p_lo], 'p_at_mid+0.1': [p_hi]}).to_csv(
        out_dir / 'logistic_fit_summary_shock06.csv', index=False, encoding='utf-8-sig')
    print(f"RESULT [输出] 已保存至 {out_dir}", flush=True)


if __name__ == '__main__':
    main()
