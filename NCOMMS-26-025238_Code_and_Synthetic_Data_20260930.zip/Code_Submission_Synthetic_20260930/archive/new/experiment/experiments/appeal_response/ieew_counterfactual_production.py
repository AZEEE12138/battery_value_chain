# -*- coding: utf-8 -*-
"""
R1.2 IEEW批发节点反事实 —— 生产规模版本(在冒烟测试(单一BED/shock, n=20, 非配对)基础上扩大)。

审稿人质疑：BM -> IEEW(批发中间节点) -> LRAM/ONRAM 走廊是否是判别性的网络拓扑结果，还是
构网过程中"人工筛选"的产物；IEEW是批发中间节点而非直接材料加工节点，其主导地位并非供应链
物理上的自明结论。

冒烟测试(smoke_test_r1_2_ieew_counterfactual.py)已发现初步有利信号(删除IEEW关联边后，
LRAM/ONRAM进入failed_nodes/main_failure_path的频率基本不变)，但存在两个方法学缺陷需要
在生产规模版本中修正：
1. 基线与反事实用的是完全不同的种子区间(10000+/20000+)，不是配对设计——两组之间"哪些节点
   先失效"这类共同随机噪声没有被抵消，检验功效低；本版本改为相同simulation_id配对。
2. 只测了一个(BED=0.6, shock=0.6)设置——本版本扩到3个BED点x2个shock强度=6个设置，检验
   结论是否只是某个特定参数点的偶然结果。

统计口径：LRAM/ONRAM进入failed_nodes是二元结果(是/否)，配对设计下用McNemar检验(不是简单
频率百分比比较)，直接检验"删除IEEW前后，LRAM/ONRAM失效状态改变的次数"是否显著多于随机噪声
预期——这是比冒烟测试"频率看起来差不多"更严格的统计口径。
"""
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent  # new/experiment/
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'experiments'))

import numpy as np
import pandas as pd
from statsmodels.stats.contingency_tables import mcnemar

from run_resilience_simulation import run_single_simulation
from src.utils.path_config import PathConfig

BM = '36901'
IEEW = '40621'
LRAM = '33501'
ONRAM = '33509'

paths = PathConfig()
nodes_df = pd.read_csv(paths.get_input_file('battery_value_chain_nodes_personalized.csv'), encoding='utf-8-sig')
edges_df = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'), encoding='utf-8-sig')

mask_ieew = (edges_df['Source_Code'].astype(str) == IEEW) | (edges_df['Target_Code'].astype(str) == IEEW)
edges_df_no_ieew = edges_df[~mask_ieew].copy()
print(f"[网络] 基线边数={len(edges_df)}  删除IEEW关联边{mask_ieew.sum()}条后反事实边数={len(edges_df_no_ieew)}",
      flush=True)

BED_POINTS = [0.50, 0.60, 0.70]
SHOCK_POINTS = [0.6, 0.8]
NUM_REPEATS = 200
TAU, BETA = 0.50, 10.0

DATA_DIR = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'


def run_one(this_edges_df, BED, shock, sim_id):
    res = run_single_simulation(
        nodes_df=nodes_df, edges_df=this_edges_df, target_BED=BED, simulation_id=sim_id,
        shock_intensity=shock, shock_steps=5, recovery_steps=45,
        bankruptcy_threshold=TAU, steepness=BETA, max_cascade_rounds=15, verbose=False,
    )
    failed = set(str(x) for x in (res.get('failed_nodes') or []))
    path = [str(x) for x in (res.get('main_failure_path') or [])]
    return {
        'lram_failed': LRAM in failed, 'onram_failed': ONRAM in failed,
        'lram_path': LRAM in path, 'onram_path': ONRAM in path,
        'robustness_pct': res['Robustness'] * 100.0,
    }


def main():
    total = len(BED_POINTS) * len(SHOCK_POINTS) * NUM_REPEATS * 2
    print(f"[规模] {len(BED_POINTS)}个BED点 x {len(SHOCK_POINTS)}档shock x {NUM_REPEATS}次重复 x "
          f"(基线+反事实配对) = {total}次仿真", flush=True)

    rows = []
    done = 0
    for BED in BED_POINTS:
        for shock in SHOCK_POINTS:
            for r in range(NUM_REPEATS):
                sim_id = int(BED * 100) * 100000 + int(shock * 100) * 1000 + r
                base = run_one(edges_df, BED, shock, sim_id)
                cf = run_one(edges_df_no_ieew, BED, shock, sim_id)
                rows.append({'BED': BED, 'shock': shock, 'rep': r, 'sim_id': sim_id,
                             **{f'base_{k}': v for k, v in base.items()},
                             **{f'cf_{k}': v for k, v in cf.items()}})
                done += 2
            print(f"[进度] BED={BED:.2f} shock={shock:.2f} 完成  累计仿真={done}/{total}", flush=True)

    df = pd.DataFrame(rows)
    out_csv = DATA_DIR / 'ieew_counterfactual_production.csv'
    df.to_csv(out_csv, index=False, encoding='utf-8-sig')
    print(f"\n[输出] 已保存: {out_csv}", flush=True)

    print("\n===== 逐(BED,shock)设置：LRAM/ONRAM进入failed_nodes频率对比 + McNemar配对检验 =====",
          flush=True)
    summary_rows = []
    for BED in BED_POINTS:
        for shock in SHOCK_POINTS:
            sub = df[(df['BED'] == BED) & (df['shock'] == shock)]
            for target, col in [('LRAM', 'lram_failed'), ('ONRAM', 'onram_failed')]:
                base_col, cf_col = f'base_{col}', f'cf_{col}'
                base_rate = sub[base_col].mean()
                cf_rate = sub[cf_col].mean()
                # 2x2配对列联表: (基线, 反事实) 的四种组合计数
                n11 = ((sub[base_col]) & (sub[cf_col])).sum()
                n10 = ((sub[base_col]) & (~sub[cf_col])).sum()
                n01 = ((~sub[base_col]) & (sub[cf_col])).sum()
                n00 = ((~sub[base_col]) & (~sub[cf_col])).sum()
                table = [[n11, n10], [n01, n00]]
                try:
                    result = mcnemar(table, exact=True)
                    pval = result.pvalue
                except Exception:
                    pval = np.nan
                print(f"  BED={BED:.2f} shock={shock:.2f} {target}: 基线频率={base_rate:.3f}({int(sub[base_col].sum())}/{len(sub)})  "
                      f"反事实频率={cf_rate:.3f}({int(sub[cf_col].sum())}/{len(sub)})  "
                      f"不一致对数(基线失效但反事实未失效={n10}, 反之={n01})  McNemar精确p={pval:.4f}", flush=True)
                summary_rows.append({'BED': BED, 'shock': shock, 'target': target,
                                      'base_rate': base_rate, 'cf_rate': cf_rate,
                                      'n10': n10, 'n01': n01, 'mcnemar_p': pval})

    summary_df = pd.DataFrame(summary_rows)
    summary_csv = DATA_DIR / 'ieew_counterfactual_production_summary.csv'
    summary_df.to_csv(summary_csv, index=False, encoding='utf-8-sig')
    print(f"\n[输出] 已保存: {summary_csv}", flush=True)

    print("\n===== 附加：删除IEEW是否明显改变整体Robustness(次要检验，非主指标) =====", flush=True)
    for BED in BED_POINTS:
        for shock in SHOCK_POINTS:
            sub = df[(df['BED'] == BED) & (df['shock'] == shock)]
            diff = sub['base_robustness_pct'] - sub['cf_robustness_pct']
            print(f"  BED={BED:.2f} shock={shock:.2f}: 基线Robustness={sub['base_robustness_pct'].mean():.1f}%  "
                  f"反事实Robustness={sub['cf_robustness_pct'].mean():.1f}%  差分均值={diff.mean():+.2f}pp", flush=True)


if __name__ == '__main__':
    main()
