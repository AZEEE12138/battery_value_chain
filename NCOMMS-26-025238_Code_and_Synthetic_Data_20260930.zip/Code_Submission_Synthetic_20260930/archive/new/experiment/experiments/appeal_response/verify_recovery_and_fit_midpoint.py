# -*- coding: utf-8 -*-
"""
两项验证：
A) 恢复阶段参数(p_recover/recovery_threshold/noise_level)是否真的不影响Robustness指标
   (读代码判断"应该不影响"，这里用相同种子、只改恢复参数，实证验证)。
B) 用逻辑回归拟合 P(崩溃)~BED，估计"转变中点"的精确位置与置信区间——
   区分"能不能精确估计中点位置"和"转变本身是否陡峭"这两件不同的事。
"""
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent  # new/experiment/
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'experiments'))

import numpy as np
import pandas as pd

from run_resilience_simulation import run_single_simulation
from src.utils.path_config import PathConfig

paths = PathConfig()
nodes_df = pd.read_csv(paths.get_input_file('battery_value_chain_nodes_personalized.csv'), encoding='utf-8-sig')
edges_df = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'), encoding='utf-8-sig')


def part_a_recovery_independence():
    print("===== A) 恢复阶段参数是否影响 Robustness =====", flush=True)
    base_kwargs = dict(
        nodes_df=nodes_df, edges_df=edges_df, target_BED=0.6, simulation_id=999,
        shock_intensity=0.6, shock_steps=5, bankruptcy_threshold=0.5, steepness=10.0,
        max_cascade_rounds=15, verbose=False,
    )
    variants = [
        dict(recovery_steps=45, p_recover=0.05, recovery_threshold=0.9, noise_level=0.10),
        dict(recovery_steps=45, p_recover=0.50, recovery_threshold=0.9, noise_level=0.10),  # 恢复快10倍
        dict(recovery_steps=45, p_recover=0.05, recovery_threshold=0.5, noise_level=0.10),  # 更低恢复目标
        dict(recovery_steps=45, p_recover=0.05, recovery_threshold=0.9, noise_level=0.40),  # 更大噪声
        dict(recovery_steps=10, p_recover=0.05, recovery_threshold=0.9, noise_level=0.10),  # 更短恢复期
    ]
    robustness_values = []
    for i, v in enumerate(variants):
        res = run_single_simulation(**base_kwargs, **v)
        robustness_values.append(res['Robustness'])
        print(f"  变体{i}: {v}  ->  Robustness={res['Robustness']:.10f}  Recovery_Rate={res['Recovery_Rate']:.4f}", flush=True)
    all_same = len(set(round(r, 10) for r in robustness_values)) == 1
    print(f"  结论: 5种恢复参数设置下 Robustness 是否完全相同 = {all_same}", flush=True)
    print(f"  (Recovery_Rate 应该不同，因为它衡量恢复快慢；Robustness 衡量最低点，应该不受恢复参数影响)", flush=True)


def part_b_logistic_fit():
    print("\n===== B) 逻辑回归拟合 P(崩溃)~BED，估计转变中点及置信区间 =====", flush=True)
    print("固定 τ=0.5, β=10.0, shock=0.8（论文原句实际引用的冲击）", flush=True)

    # 用之前n=50的数据重新汇总成"每次独立仿真的0/1标签"用于逻辑回归(而不是每BED点先取均值)
    BED_GRID = [round(x, 2) for x in np.arange(0.30, 0.901, 0.02)]
    N = 40  # 每点重复次数(与之前n=50量级一致，控制总耗时)
    records = []
    sim_counter = 500000
    for BED in BED_GRID:
        for r in range(N):
            sim_counter += 1
            res = run_single_simulation(
                nodes_df=nodes_df, edges_df=edges_df, target_BED=BED, simulation_id=sim_counter,
                shock_intensity=0.8, shock_steps=5, recovery_steps=45,
                bankruptcy_threshold=0.5, steepness=10.0, max_cascade_rounds=15, verbose=False,
            )
            collapsed = 1 if (res['Robustness'] * 100.0) < 50.0 else 0
            records.append((BED, collapsed))
    df = pd.DataFrame(records, columns=['BED', 'collapsed'])

    # 手写简单逻辑回归(牛顿法/梯度下降二选一，用scipy.optimize更稳)
    from scipy.optimize import minimize

    X = df['BED'].values
    y = df['collapsed'].values

    def neg_log_lik(params):
        a, b = params  # P = 1/(1+exp(-(a*(X-b))))  a=斜率相关, b=中点
        z = a * (X - b)
        p = 1.0 / (1.0 + np.exp(-z))
        p = np.clip(p, 1e-9, 1 - 1e-9)
        return -np.sum(y * np.log(p) + (1 - y) * np.log(1 - p))

    result = minimize(neg_log_lik, x0=[10.0, 0.5], method='Nelder-Mead')
    a_hat, b_hat = result.x
    print(f"  逻辑回归拟合: 斜率a={a_hat:.3f}  中点b(BED*)={b_hat:.4f}", flush=True)

    # Bootstrap置信区间(重采样50次，控制耗时)
    boot_mids = []
    rng = np.random.default_rng(42)
    n_total = len(df)
    for _ in range(50):
        idx = rng.integers(0, n_total, n_total)
        Xb, yb = X[idx], y[idx]
        def nll_b(params):
            a, b = params
            z = a * (Xb - b)
            p = 1.0 / (1.0 + np.exp(-z))
            p = np.clip(p, 1e-9, 1 - 1e-9)
            return -np.sum(yb * np.log(p) + (1 - yb) * np.log(1 - p))
        r = minimize(nll_b, x0=[a_hat, b_hat], method='Nelder-Mead')
        boot_mids.append(r.x[1])
    boot_mids = np.array(boot_mids)
    ci_lo, ci_hi = np.percentile(boot_mids, [2.5, 97.5])
    print(f"  中点位置 95% Bootstrap置信区间: [{ci_lo:.4f}, {ci_hi:.4f}]  (宽度={ci_hi-ci_lo:.4f})", flush=True)
    print(f"  对比: 论文声称的 BED=0.50 是否落在置信区间内 = {ci_lo <= 0.50 <= ci_hi}", flush=True)

    # 同时报告：在中点±0.1范围内，P(崩溃)的跨度(衡量"转变本身多陡")
    z_lo = a_hat * ((b_hat - 0.1) - b_hat)
    z_hi = a_hat * ((b_hat + 0.1) - b_hat)
    p_lo = 1 / (1 + np.exp(-z_lo))
    p_hi = 1 / (1 + np.exp(-z_hi))
    print(f"  中点±0.1的BED范围内，P(崩溃)从{p_lo:.2f}升到{p_hi:.2f} (这才是'转变陡峭度'，与中点定位精度是两件事)", flush=True)

    out_dir = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'
    df.to_csv(out_dir / 'logistic_fit_raw_shock08.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame({'a_hat': [a_hat], 'b_hat': [b_hat], 'ci_lo': [ci_lo], 'ci_hi': [ci_hi],
                  'p_at_mid-0.1': [p_lo], 'p_at_mid+0.1': [p_hi]}).to_csv(
        out_dir / 'logistic_fit_summary_shock08.csv', index=False, encoding='utf-8-sig')
    print(f"\n[输出] 已保存至 {out_dir}", flush=True)


if __name__ == '__main__':
    part_a_recovery_independence()
    part_b_logistic_fit()
