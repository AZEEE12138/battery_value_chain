# -*- coding: utf-8 -*-
"""
(τ, β, shock) 三维生产规模相图 —— 检验"结论是否依赖于τ,β恰好等于0.50/10.0这个具体选择"。

背景：
此前 v1/v2 只在 shock=0.8 单一档位下测过(τ,β)，且从未正式计算过"BED与Robustness的单调性"这个
可复核统计量——SI原有的"we observe no ordering reversals"是纯叙述，无法被读者复现验证。本脚本补齐
两处缺口：
1. 覆盖论文全部三档冲击强度(0.40/0.60/0.80)，不只是头条数字所在的0.80。
2. 对每个(τ,β,shock)组合，计算 BED 与 Robustness% 的 Spearman 相关系数，把"单调性"从散文变成
   可复核的统计量；同时记录该组合在自适应BED窗口内是否存在真实的"跌破警戒线"交叉点。

排除 β=5.0：已诊断为病态区间(P_fail(损失=0)在τ=0.3~0.7时高达3%~18%，与BED无关的"背景噪声崩溃"，
非"阈值消失"证据，见 phase_diagram_tau_beta_shock08.py 的诊断说明)。

网格：τ∈{0.30,0.40,0.50,0.60,0.70} × β∈{10.0,15.0,20.0} × shock∈{0.40,0.60,0.80} = 45组合，
每组合13个自适应BED点 × 40次重复 = 45×13×40 = 23,400次仿真。
"""
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'experiments'))
sys.path.insert(0, str(BASE_DIR / 'scripts' / 'visualization' / 'resilience'))

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from run_resilience_simulation import run_single_simulation
from src.utils.path_config import PathConfig
from visualize_combined_resilience_analysis import _normalize_values, WARNING_THRESHOLDS

paths = PathConfig()
nodes_df = pd.read_csv(paths.get_input_file('battery_value_chain_nodes_personalized.csv'), encoding='utf-8-sig')
edges_df = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'), encoding='utf-8-sig')

TAU_GRID = [0.30, 0.40, 0.50, 0.60, 0.70]
BETA_GRID = [10.0, 15.0, 20.0]
SHOCK_GRID = [0.40, 0.60, 0.80]
NUM_REPEATS = 40
N_BED_POINTS = 13
WINDOW = 0.35

ROBUSTNESS_WARNING_PCT = WARNING_THRESHOLDS['robustness_pct']

OUT_DIR = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'
OUT_DIR.mkdir(parents=True, exist_ok=True)
OUT_CSV = OUT_DIR / 'phase_diagram_tau_beta_multishock_production.csv'
PROGRESS_LOG = OUT_DIR / 'phase_diagram_tau_beta_multishock_production_progress.csv'


def interp_crossing(x_vals, y_vals, target):
    """线性插值找 Robustness% 首次跌破 target 的 BED（假设 Robustness 随 BED 总体下降）。"""
    for i in range(len(x_vals) - 1):
        y0, y1 = y_vals[i], y_vals[i + 1]
        if y0 >= target >= y1 and y0 != y1:
            frac = (y0 - target) / (y0 - y1)
            return x_vals[i] + frac * (x_vals[i + 1] - x_vals[i])
    return None


def adaptive_bed_grid(tau, shock, window=WINDOW, n=N_BED_POINTS):
    """自适应BED窗口：以理论中心tau/shock为中心，裁剪到可行域[0.03,0.97]。

    当理论中心远超出可行域上界(如tau=0.6,shock=0.4时中心=1.5)，裸算的下界(center-window)
    本身也会超过0.97——必须对lo、hi分别独立裁剪，再在lo>hi时退化为单点窗口(全部落在越界的
    那一侧边界)，否则会产生>1.0的非法BED，参见2026-08-05首次生产跑批在tau=0.6处的崩溃记录。
    """
    center = tau / shock
    lo = min(max(0.03, center - window), 0.97)
    hi = min(max(0.03, center + window), 0.97)
    if lo > hi:
        lo, hi = hi, lo
    return [round(v, 4) for v in np.linspace(lo, hi, n)]


def run_bed_scan(tau, beta, shock, bed_grid, sim_base):
    raw_rob, raw_es0 = [], []
    for bi, BED in enumerate(bed_grid):
        robs, es0s = [], []
        for r in range(NUM_REPEATS):
            sim_id = sim_base + bi * 1000 + r
            res = run_single_simulation(
                nodes_df=nodes_df, edges_df=edges_df, target_BED=BED, simulation_id=sim_id,
                shock_intensity=shock, shock_steps=5, recovery_steps=45,
                bankruptcy_threshold=tau, steepness=beta, max_cascade_rounds=15, verbose=False,
            )
            robs.append(res['Robustness'])
            es0s.append(res['ES_0'])
        raw_rob.append(np.mean(robs))
        raw_es0.append(np.mean(es0s))
    es0_mean = float(np.mean(raw_es0))
    rob_pct = _normalize_values(np.array(raw_rob), 'Robustness', es0_mean)
    return rob_pct.tolist()


def classify_regime(bed_grid, rob_pct, warn_pct):
    """把一条曲线分类为: 全程崩溃 / 全程安全 / 真实过渡(存在交叉点)。"""
    if all(v < warn_pct for v in rob_pct):
        return '全程崩溃(与BED无关)'
    if all(v >= warn_pct for v in rob_pct):
        return '全程安全(与BED无关)'
    return '真实过渡区'


def main():
    combos = [(t, b, s) for t in TAU_GRID for b in BETA_GRID for s in SHOCK_GRID]
    total = len(combos)
    total_sims = total * N_BED_POINTS * NUM_REPEATS
    print(f"[规模] {total}个(tau,beta,shock)组合 x {N_BED_POINTS}个自适应BED点 x {NUM_REPEATS}次重复 "
          f"= {total_sims}次仿真，排除beta=5.0(病态区间)", flush=True)

    rows = []
    done_keys = set()
    if OUT_CSV.exists():
        import ast
        prev = pd.read_csv(OUT_CSV, encoding='utf-8-sig')
        for _, r in prev.iterrows():
            key = (round(float(r['tau']), 2), round(float(r['beta']), 1), round(float(r['shock']), 2))
            done_keys.add(key)
            row = r.to_dict()
            row['Robustness_pct_curve'] = ast.literal_eval(row['Robustness_pct_curve'])
            rows.append(row)
        print(f"[续跑] 检测到已有结果文件，跳过已完成的{len(done_keys)}个组合", flush=True)

    for idx, (tau, beta, shock) in enumerate(combos, 1):
        key = (round(tau, 2), round(beta, 1), round(shock, 2))
        if key in done_keys:
            continue
        bed_grid = adaptive_bed_grid(tau, shock)
        sim_base = (int(tau * 100) * 1_000_000 + int(beta * 10) * 10_000
                    + int(shock * 100) * 100 + 900_000_000)
        rob_pct = run_bed_scan(tau, beta, shock, bed_grid, sim_base)

        crit = interp_crossing(bed_grid, rob_pct, ROBUSTNESS_WARNING_PCT)
        theory = tau / shock
        regime = classify_regime(bed_grid, rob_pct, ROBUSTNESS_WARNING_PCT)
        rho, pval = spearmanr(bed_grid, rob_pct)

        rows.append({
            'tau': tau, 'beta': beta, 'shock': shock,
            'bed_grid_lo': bed_grid[0], 'bed_grid_hi': bed_grid[-1],
            'critical_BED_empirical': crit,
            'theory_BED_tau_over_shock': theory,
            'gap_theory_minus_empirical': (theory - crit) if crit is not None else None,
            'regime': regime,
            'spearman_rho_BED_vs_Robustness': rho,
            'spearman_pvalue': pval,
            'Robustness_pct_curve': [round(v, 1) for v in rob_pct],
        })
        crit_s = f"{crit:.3f}" if crit is not None else "无(该窗口内未穿越)"
        print(f"[{idx}/{total}] tau={tau:.2f} beta={beta:5.1f} shock={shock:.2f}  "
              f"网格=[{bed_grid[0]:.2f},{bed_grid[-1]:.2f}]  交叉BED={crit_s}  理论={theory:.3f}  "
              f"regime={regime}  rho={rho:+.4f}(p={pval:.4f})", flush=True)

        pd.DataFrame(rows).to_csv(OUT_CSV, index=False, encoding='utf-8-sig')
        pd.DataFrame([{
            'completed': idx, 'total': total,
            'pct': round(idx / total * 100, 1),
        }]).to_csv(PROGRESS_LOG, index=False, encoding='utf-8-sig')

    df = pd.DataFrame(rows)
    print(f"\n[输出] 已保存: {OUT_CSV}", flush=True)

    print(f"\n[汇总①单调性] 全部{len(df)}个组合的 Spearman(BED, Robustness%) 分布：", flush=True)
    print(f"  中位数rho={df['spearman_rho_BED_vs_Robustness'].median():+.4f}  "
          f"均值rho={df['spearman_rho_BED_vs_Robustness'].mean():+.4f}  "
          f"|rho|>0.9的组合数={int((df['spearman_rho_BED_vs_Robustness'].abs() > 0.9).sum())}/{len(df)}  "
          f"|rho|>0.7的组合数={int((df['spearman_rho_BED_vs_Robustness'].abs() > 0.7).sum())}/{len(df)}", flush=True)

    print(f"\n[汇总②regime分布] :", flush=True)
    print(df['regime'].value_counts().to_string(), flush=True)

    valid = df.dropna(subset=['critical_BED_empirical'])
    print(f"\n[汇总③真实过渡区组合的临界BED分布] {len(valid)}/{len(df)}个组合存在窗口内交叉点", flush=True)
    if len(valid) > 0:
        print(f"  临界BED范围=[{valid['critical_BED_empirical'].min():.3f}, "
              f"{valid['critical_BED_empirical'].max():.3f}]  "
              f"均值={valid['critical_BED_empirical'].mean():.3f}  "
              f"中位数={valid['critical_BED_empirical'].median():.3f}", flush=True)
        for shock in SHOCK_GRID:
            sub = valid[valid['shock'] == shock]
            if len(sub) > 0:
                print(f"    shock={shock:.2f}: n={len(sub)}  范围=[{sub['critical_BED_empirical'].min():.3f}, "
                      f"{sub['critical_BED_empirical'].max():.3f}]", flush=True)

    print("\n[完成]", flush=True)


if __name__ == '__main__':
    main()
