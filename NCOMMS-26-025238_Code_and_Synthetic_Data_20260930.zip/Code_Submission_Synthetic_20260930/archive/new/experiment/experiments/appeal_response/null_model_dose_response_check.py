# -*- coding: utf-8 -*-
"""
空模型机制核查·剂量-反应设计：不是只对比"完全随机化(n_swaps_factor=10)"与"完全不随机化
(真实网络)"这两个极端，而是让随机化强度(双边交换次数)从0连续升到10，逐档观察：
(a) 结构指标(聚类系数等)如何随随机化强度变化；
(b) Robustness如何随随机化强度变化；
两条曲线是否同步下降——如果同步，支持"结构指标(尤其聚类系数)是驱动Robustness下降的机制"；
如果Robustness在结构指标还没怎么变的早期剂量就已经大幅下降(或反之)，说明两者不是同一件事，
需要放弃"聚类系数"这个假说，另找机制。

前置结果(null_model_mechanism_check.py，横截面相关分析)：K=20个"完全随机化"网络之间，
聚类系数差异与Robustness差异不相关(r=-0.04, p=0.86)——但那20个网络的聚类系数本身高度同质
(0.50~0.59，远离真实网络的0.70)，可能只是变化范围太窄测不出来。本脚本用剂量梯度制造更大的
聚类系数变化范围(理论上从真实网络的0.70一路降到完全随机化的~0.55)，是更有效力的检验。
"""
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'experiments'))

import numpy as np
import pandas as pd
import networkx as nx
from run_resilience_simulation import run_single_simulation
from src.utils.path_config import PathConfig
from src.core.network_null_model import randomize_downstream_topology

BATTERY_NODE = '36901'
DOSE_FACTORS = [0.0, 0.15, 0.3, 0.6, 1.2, 2.5, 5.0, 10.0]
N_SEEDS_PER_DOSE = 5  # dose=0(真实网络)只有1个确定性实现，其余每档5个独立随机化实现
BED_POINTS = [0.50, 0.60]
TAU, BETA, SHOCK = 0.50, 10.0, 0.8
NUM_REPEATS = 20

paths = PathConfig()
edges_real = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'), encoding='utf-8-sig')
nodes_df = pd.read_csv(paths.get_input_file('battery_value_chain_nodes_personalized.csv'), encoding='utf-8-sig')

DATA_DIR = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'


def edge_cols(df):
    s = 'Source_Code' if 'Source_Code' in df.columns else 'Source'
    t = 'Target_Code' if 'Target_Code' in df.columns else 'Target'
    return s, t


def structural_metrics(edges_df):
    s_col, t_col = edge_cols(edges_df)
    G = nx.from_pandas_edgelist(edges_df, source=s_col, target=t_col,
                                 edge_attr='Weight' if 'Weight' in edges_df.columns else None,
                                 create_using=nx.DiGraph())
    Gu = G.to_undirected()
    clus = np.mean(list(nx.clustering(Gu).values()))
    btw = np.mean(list(nx.betweenness_centrality(G).values()))
    pr = np.mean(list(nx.pagerank(G).values()))
    return {'clustering': clus, 'betweenness': btw, 'pagerank': pr}


def run_one(edges_df, BED, sim_id):
    res = run_single_simulation(
        nodes_df=nodes_df, edges_df=edges_df, target_BED=BED, simulation_id=sim_id,
        shock_intensity=SHOCK, shock_steps=5, recovery_steps=45,
        bankruptcy_threshold=TAU, steepness=BETA, max_cascade_rounds=15, verbose=False,
    )
    return res['Robustness'] * 100.0


def main():
    # ---- 生成各剂量下的网络实现 + 结构指标 ----
    networks = []  # list of dict: dose, seed_idx, edges, metrics
    for di, dose in enumerate(DOSE_FACTORS):
        n_realizations = 1 if dose == 0.0 else N_SEEDS_PER_DOSE
        for si in range(n_realizations):
            seed = 8000 + di * 100 + si
            edges = randomize_downstream_topology(edges_real, battery_node=BATTERY_NODE,
                                                    seed=seed, n_swaps_factor=dose)
            m = structural_metrics(edges)
            networks.append({'dose': dose, 'seed_idx': si, 'edges': edges, **m})
            print(f"[结构] dose={dose:5.2f} seed_idx={si} 聚类={m['clustering']:.4f} "
                  f"介数={m['betweenness']:.4f} PageRank={m['pagerank']:.5f}", flush=True)

    total_sims = len(networks) * len(BED_POINTS) * NUM_REPEATS
    print(f"\n[规模] {len(networks)}个网络实现(含1个dose=0即真实网络) x {len(BED_POINTS)}个BED点 x "
          f"{NUM_REPEATS}次重复 = {total_sims}次仿真", flush=True)

    rows = []
    done = 0
    for net in networks:
        for BED in BED_POINTS:
            for r in range(NUM_REPEATS):
                sim_id = int(BED * 1000) * 100 + r
                rob = run_one(net['edges'], BED, sim_id)
                rows.append({'dose': net['dose'], 'seed_idx': net['seed_idx'], 'BED': BED, 'rep': r,
                             'robustness_pct': rob, 'clustering': net['clustering'],
                             'betweenness': net['betweenness'], 'pagerank': net['pagerank']})
                done += 1
        print(f"[进度] dose={net['dose']:5.2f} seed_idx={net['seed_idx']} 完成  "
              f"累计仿真={done}/{total_sims}", flush=True)

    df = pd.DataFrame(rows)
    out_csv = DATA_DIR / 'null_model_dose_response.csv'
    df.to_csv(out_csv, index=False, encoding='utf-8-sig')
    print(f"\n[输出] 已保存: {out_csv}", flush=True)

    print("\n===== 汇总：各剂量下 平均Robustness 与 平均聚类系数(按BED分列) =====", flush=True)
    for BED in BED_POINTS:
        sub_bed = df[df['BED'] == BED]
        print(f"\n--- BED={BED:.2f} ---", flush=True)
        agg = sub_bed.groupby('dose').agg(
            mean_robustness=('robustness_pct', 'mean'),
            mean_clustering=('clustering', 'mean'),
        ).reset_index()
        for _, row in agg.iterrows():
            print(f"  dose={row['dose']:5.2f}  平均聚类={row['mean_clustering']:.4f}  "
                  f"平均Robustness={row['mean_robustness']:.2f}%", flush=True)

    print("\n===== 相关性：36个网络实现的(聚类系数, 平均Robustness)——剂量梯度制造的宽范围检验 =====",
          flush=True)
    from scipy import stats
    per_net = df.groupby(['dose', 'seed_idx']).agg(
        mean_robustness=('robustness_pct', 'mean'),
        clustering=('clustering', 'first'),
        betweenness=('betweenness', 'first'),
        pagerank=('pagerank', 'first'),
    ).reset_index()
    for metric in ['clustering', 'betweenness', 'pagerank']:
        r, p = stats.pearsonr(per_net[metric], per_net['mean_robustness'])
        rho, ps = stats.spearmanr(per_net[metric], per_net['mean_robustness'])
        print(f"  {metric:12s}: Pearson r={r:+.3f}(p={p:.5f})  Spearman rho={rho:+.3f}(p={ps:.5f})  "
              f"n={len(per_net)}", flush=True)


if __name__ == '__main__':
    main()
