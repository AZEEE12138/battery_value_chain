# -*- coding: utf-8 -*-
"""
对 shock=0.4（论文原文只说"both pathways keep value output above the safety line"，
未给出具体BED阈值数字）做同样严格的逻辑回归拟合，凑齐Fig.3a三条冲击线的完整证据链。
预期：40%冲击下P(崩溃)应普遍偏低，可能在测试的BED范围内不会明显穿越50%——这与论文
"未给出具体阈值、只说保持在安全线以上"的表述应当一致。
"""
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent  # new/experiment/
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'experiments'))

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from run_resilience_simulation import run_single_simulation
from src.utils.path_config import PathConfig

paths = PathConfig()
nodes_df = pd.read_csv(paths.get_input_file('battery_value_chain_nodes_personalized.csv'), encoding='utf-8-sig')
edges_df = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'), encoding='utf-8-sig')


def main():
    print("固定 tau=0.5, beta=10.0, shock=0.4", flush=True)
    BED_GRID = [round(x, 2) for x in np.arange(0.30, 0.901, 0.02)]
    N = 40
    records = []
    sim_counter = 700000
    total = len(BED_GRID) * N
    done = 0
    for BED in BED_GRID:
        robs = []
        for r in range(N):
            sim_counter += 1
            res = run_single_simulation(
                nodes_df=nodes_df, edges_df=edges_df, target_BED=BED, simulation_id=sim_counter,
                shock_intensity=0.4, shock_steps=5, recovery_steps=45,
                bankruptcy_threshold=0.5, steepness=10.0, max_cascade_rounds=15, verbose=False,
            )
            collapsed = 1 if (res['Robustness'] * 100.0) < 50.0 else 0
            records.append((BED, collapsed))
            robs.append(res['Robustness'] * 100.0)
            done += 1
        print(f"进度: BED={BED:.2f} 完成 ({done}/{total})  均值Rob%={np.mean(robs):.1f}", flush=True)
    df = pd.DataFrame(records, columns=['BED', 'collapsed'])

    X = df['BED'].values
    y = df['collapsed'].values
    p_collapse_overall = y.mean()
    print(f"RESULT 整体崩溃比例(不分BED): {p_collapse_overall:.3f}", flush=True)

    def neg_log_lik(params):
        a, b = params
        z = a * (X - b)
        p = 1.0 / (1.0 + np.exp(-z))
        p = np.clip(p, 1e-9, 1 - 1e-9)
        return -np.sum(y * np.log(p) + (1 - y) * np.log(1 - p))

    # 若整体崩溃比例很低/很高，逻辑回归中点可能落在测试范围之外或不收敛，做容错处理
    try:
        result = minimize(neg_log_lik, x0=[10.0, 0.9], method='Nelder-Mead',
                           options={'maxiter': 5000, 'xatol': 1e-6, 'fatol': 1e-8})
        a_hat, b_hat = result.x
        print(f"RESULT 逻辑回归拟合: 斜率a={a_hat:.3f}  中点b(BED*)={b_hat:.4f}", flush=True)

        boot_mids = []
        rng = np.random.default_rng(42)
        n_total = len(df)
        for _ in range(50):
            idx = rng.integers(0, n_total, n_total)
            Xb, yb = X[idx], y[idx]
            def nll_b(params):
                a, b = params
                z = a * (Xb - b)
                p = 1.0 / (1.0 + np.exp(-z))
                p = np.clip(p, 1e-9, 1 - 1e-9)
                return -np.sum(yb * np.log(p) + (1 - yb) * np.log(1 - p))
            r = minimize(nll_b, x0=[a_hat, b_hat], method='Nelder-Mead')
            boot_mids.append(r.x[1])
        boot_mids = np.array(boot_mids)
        ci_lo, ci_hi = np.percentile(boot_mids, [2.5, 97.5])
        print(f"RESULT 中点位置 95% Bootstrap置信区间: [{ci_lo:.4f}, {ci_hi:.4f}] (宽度={ci_hi-ci_lo:.4f})", flush=True)
        in_range = 0.30 <= b_hat <= 0.90
        print(f"RESULT 中点是否落在测试的BED范围[0.30,0.90]内 = {in_range}", flush=True)
    except Exception as e:
        print(f"RESULT 逻辑回归拟合失败或不收敛: {e}", flush=True)
        a_hat, b_hat, ci_lo, ci_hi = None, None, None, None

    out_dir = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'
    df.to_csv(out_dir / 'logistic_fit_raw_shock04.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame({'a_hat': [a_hat], 'b_hat': [b_hat], 'ci_lo': [ci_lo], 'ci_hi': [ci_hi],
                  'overall_p_collapse': [p_collapse_overall]}).to_csv(
        out_dir / 'logistic_fit_summary_shock04.csv', index=False, encoding='utf-8-sig')
    print(f"RESULT [输出] 已保存至 {out_dir}", flush=True)


if __name__ == '__main__':
    main()
