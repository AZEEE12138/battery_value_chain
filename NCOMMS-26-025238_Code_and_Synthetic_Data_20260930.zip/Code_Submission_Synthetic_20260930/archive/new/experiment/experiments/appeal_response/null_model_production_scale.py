# -*- coding: utf-8 -*-
"""
拓扑随机化空模型对照 —— 生产规模版本(在冒烟测试(K=10,N=15,3个BED点)基础上扩大)。

前置诊断已确认：
1. 双边交换混合充分——真实网络vs随机化网络的边重合度(~0.28-0.30)与随机化网络彼此之间的重合度
   (~0.28-0.33)基本相同，说明n_swaps_factor=10已经把网络"打匀"，不是混合不足导致的假象。
2. 度序列/权重集合/边数逐项校验完全正确(见network_null_model.py)。

本版本扩大规模以获得确定性结论：
- K=20个独立随机化拓扑(冒烟测试用10个)
- BED网格7点[0.35,0.40,0.45,0.50,0.55,0.60,0.65]，覆盖真实网络在shock=0.8下的实测转变区间
  (逻辑回归中点0.508)左右更宽范围(冒烟测试只测了3点)
- N=30次重复/点(冒烟测试用15次)，配对种子设计(真实网络与全部20个随机化网络在同一simulation_id
  下运行，抵消"哪个节点先失效"的共同随机噪声)
- 总计 7 x 30 x (1+20) = 4410 次仿真
"""
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'experiments'))

import numpy as np
import pandas as pd

from run_resilience_simulation import run_single_simulation
from src.utils.path_config import PathConfig
from src.core.network_null_model import randomize_downstream_topology

BATTERY_NODE = '36901'

paths = PathConfig()
nodes_df = pd.read_csv(paths.get_input_file('battery_value_chain_nodes_personalized.csv'), encoding='utf-8-sig')
edges_df_real = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'), encoding='utf-8-sig')

BED_POINTS = [0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65]
TAU, BETA, SHOCK = 0.50, 10.0, 0.8
NUM_REPEATS = 30
K_RANDOM = 20

OUT_DIR = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'
OUT_DIR.mkdir(parents=True, exist_ok=True)


def run_one(edges_df, BED, sim_id):
    res = run_single_simulation(
        nodes_df=nodes_df, edges_df=edges_df, target_BED=BED, simulation_id=sim_id,
        shock_intensity=SHOCK, shock_steps=5, recovery_steps=45,
        bankruptcy_threshold=TAU, steepness=BETA, max_cascade_rounds=15, verbose=False,
    )
    return res['Robustness'] * 100.0


def main():
    total = len(BED_POINTS) * NUM_REPEATS * (1 + K_RANDOM)
    print(f"[规模] {len(BED_POINTS)}个BED点 x {NUM_REPEATS}重复 x (1真实+{K_RANDOM}随机化) = {total}次仿真",
          flush=True)

    print(f"[准备] 生成{K_RANDOM}个随机化拓扑...", flush=True)
    rand_networks = [randomize_downstream_topology(edges_df_real, battery_node=BATTERY_NODE, seed=6000 + k)
                     for k in range(K_RANDOM)]
    print(f"[准备] 完成", flush=True)

    rows = []
    for bi, BED in enumerate(BED_POINTS):
        for r in range(NUM_REPEATS):
            sim_id = int(BED * 1000) * 100 + r
            real_rob = run_one(edges_df_real, BED, sim_id)
            rand_robs = [run_one(rand_networks[k], BED, sim_id) for k in range(K_RANDOM)]
            for k, rr in enumerate(rand_robs):
                rows.append({'BED': BED, 'rep': r, 'sim_id': sim_id, 'k': k,
                             'real_robustness_pct': real_rob, 'random_robustness_pct': rr,
                             'paired_diff': real_rob - rr})
        done_sims = (bi + 1) * NUM_REPEATS * (1 + K_RANDOM)
        print(f"[{bi+1}/{len(BED_POINTS)}] BED={BED:.2f} 完成  累计仿真={done_sims}/{total}", flush=True)
        pd.DataFrame(rows).to_csv(OUT_DIR / 'null_model_production_v3.csv', index=False, encoding='utf-8-sig')

    df = pd.DataFrame(rows)
    out_csv = OUT_DIR / 'null_model_production_v3.csv'
    df.to_csv(out_csv, index=False, encoding='utf-8-sig')
    print(f"\n[输出] 已保存: {out_csv}", flush=True)

    print(f"\n[汇总] 配对差分(真实-随机)统计，每个BED点基于 {NUM_REPEATS} x {K_RANDOM} 个配对差值", flush=True)
    for BED in BED_POINTS:
        sub = df[df['BED'] == BED]
        diffs = sub['paired_diff'].values
        mean_diff = diffs.mean()
        se_diff = diffs.std(ddof=1) / np.sqrt(len(diffs))
        t_stat = mean_diff / se_diff if se_diff > 0 else np.nan
        real_vals_unique = sub.groupby('rep')['real_robustness_pct'].first()
        rand_mean = sub['random_robustness_pct'].mean()
        rand_std_across_k = sub.groupby('k')['random_robustness_pct'].mean().std(ddof=1)
        print(f"  BED={BED:.2f}: 真实={real_vals_unique.mean():.1f}%(n={len(real_vals_unique)})  "
              f"随机化{K_RANDOM}个均值={rand_mean:.1f}%(跨随机化std={rand_std_across_k:.2f})  "
              f"配对差分均值={mean_diff:+.2f}pp  SE={se_diff:.2f}  t={t_stat:+.2f}", flush=True)


if __name__ == '__main__':
    main()
