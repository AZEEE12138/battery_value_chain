# -*- coding: utf-8 -*-
"""
R1.1 补充对照：独立改变【警戒线定义】(40%/50%/60%)，检验临界 BED 对警戒线选择的敏感度
================================================================================

审稿人 R1.1 明确要求："a demonstration that the threshold remains near 0.5 when the
warning line and shock intensity are independently varied"。此前已做"改冲击强度"
(shock=0.4/0.6/0.8)与"(τ,β)相图"，唯独缺"独立改警戒线定义"这一组——本脚本补上。

方法(与此前逻辑回归口径完全一致)：
- 固定论文基线 τ=0.50、β=10.0；
- 对每档冲击强度(0.4/0.6/0.8)扫描 BED 网格，每点重复 N 次，记录每次仿真的 Robustness%；
- **同一批 Robustness 值**同时用于三条警戒线 W∈{40%,50%,60%}(零额外仿真)：对每条警戒线
  定义二元结果 collapsed = 1[Robustness% < W]，用最大似然逻辑回归拟合 P(collapsed)~BED，
  得转变中点 BED* 与 95% Bootstrap 置信区间；
- 报告三条警戒线下临界 BED 的移动范围，诚实回答"0.5 对警戒线定义有多敏感"。

预期机制(供解读)：警戒线越高(60%，更严的安全底线)越容易被击穿→临界 BED 越低；
警戒线越低(40%)越难击穿→临界 BED 越高。因此临界 BED 会随警戒线单调移动，关键看**移动幅度**
是否温和、是否保持"BED 越高越脆弱"的单调定性结论。
"""
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent  # new/experiment/
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'experiments'))

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from run_resilience_simulation import run_single_simulation
from src.utils.path_config import PathConfig

paths = PathConfig()
nodes_df = pd.read_csv(paths.get_input_file('battery_value_chain_nodes_personalized.csv'), encoding='utf-8-sig')
edges_df = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'), encoding='utf-8-sig')

TAU, BETA = 0.50, 10.0
SHOCKS = [0.4, 0.6, 0.8]
WARNING_LINES = [40.0, 50.0, 60.0]
BED_GRID = [round(x, 2) for x in np.arange(0.30, 0.981, 0.02)]
N = 40

OUT_DIR = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'


def fit_logistic_midpoint(X, y, x0_b):
    """最大似然逻辑回归，返回(斜率a, 中点b)。y为二元崩溃标签。"""
    def nll(params):
        a, b = params
        z = a * (X - b)
        p = np.clip(1.0 / (1.0 + np.exp(-z)), 1e-9, 1 - 1e-9)
        return -np.sum(y * np.log(p) + (1 - y) * np.log(1 - p))
    res = minimize(nll, x0=[10.0, x0_b], method='Nelder-Mead')
    return res.x[0], res.x[1]


def bootstrap_ci(X, y, a_hat, b_hat, n_boot=50, seed=42):
    """对中点做 Bootstrap 95% 置信区间。"""
    rng = np.random.default_rng(seed)
    n = len(X)
    mids = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        Xb, yb = X[idx], y[idx]
        if yb.sum() == 0 or yb.sum() == n:  # 全同类，无法拟合中点
            continue
        def nll_b(params):
            a, b = params
            z = a * (Xb - b)
            p = np.clip(1.0 / (1.0 + np.exp(-z)), 1e-9, 1 - 1e-9)
            return -np.sum(yb * np.log(p) + (1 - yb) * np.log(1 - p))
        r = minimize(nll_b, x0=[a_hat, b_hat], method='Nelder-Mead')
        mids.append(r.x[1])
    if len(mids) < 5:
        return np.nan, np.nan
    return float(np.percentile(mids, 2.5)), float(np.percentile(mids, 97.5))


def main():
    print(f"[配置] 基线 tau={TAU}, beta={BETA}; 冲击={SHOCKS}; 警戒线={WARNING_LINES}%", flush=True)
    total = len(SHOCKS) * len(BED_GRID) * N
    print(f"[规模] {len(SHOCKS)}冲击 x {len(BED_GRID)}个BED点 x {N}重复 = {total}次仿真", flush=True)

    raw_rows = []   # 每次仿真的 Robustness%
    done = 0
    for shock in SHOCKS:
        sim_counter = int(shock * 100) * 1_000_000 + 700_000
        for BED in BED_GRID:
            for r in range(N):
                sim_counter += 1
                res = run_single_simulation(
                    nodes_df=nodes_df, edges_df=edges_df, target_BED=BED, simulation_id=sim_counter,
                    shock_intensity=shock, shock_steps=5, recovery_steps=45,
                    bankruptcy_threshold=TAU, steepness=BETA, max_cascade_rounds=15, verbose=False,
                )
                raw_rows.append({'shock': shock, 'BED': BED, 'rep': r,
                                 'robustness_pct': res['Robustness'] * 100.0})
                done += 1
            if len(BED_GRID) <= 40 and BED in (0.30, 0.50, 0.70, 0.90):
                print(f"  [进度] shock={shock:.1f} BED={BED:.2f}  累计={done}/{total}", flush=True)
    raw = pd.DataFrame(raw_rows)
    raw.to_csv(OUT_DIR / 'warning_line_robustness_raw.csv', index=False, encoding='utf-8-sig')
    print(f"[输出] 原始数据: {OUT_DIR / 'warning_line_robustness_raw.csv'}", flush=True)

    # 对每个(冲击, 警戒线)组合，用同一批 Robustness 值拟合逻辑回归中点
    print("\n===== 临界BED随警戒线的移动(逻辑回归中点 + 95%CI) =====", flush=True)
    summary = []
    for shock in SHOCKS:
        sub = raw[raw['shock'] == shock]
        X = sub['BED'].values
        rob = sub['robustness_pct'].values
        for W in WARNING_LINES:
            y = (rob < W).astype(float)
            frac = y.mean()
            if y.sum() == 0 or y.sum() == len(y):
                # 在测试范围内从不崩溃或全崩溃：无有限中点
                print(f"  shock={shock:.1f} 警戒线={W:.0f}%: 崩溃比例={frac:.2f} "
                      f"(范围内无穿越，中点在可行域外)", flush=True)
                summary.append({'shock': shock, 'warning_line_pct': W, 'collapse_fraction': frac,
                                'BED_star': np.nan, 'ci_lo': np.nan, 'ci_hi': np.nan})
                continue
            a_hat, b_hat = fit_logistic_midpoint(X, y, x0_b=0.5)
            ci_lo, ci_hi = bootstrap_ci(X, y, a_hat, b_hat)
            print(f"  shock={shock:.1f} 警戒线={W:.0f}%: 崩溃比例={frac:.2f}  "
                  f"临界BED*={b_hat:.3f}  95%CI=[{ci_lo:.3f}, {ci_hi:.3f}]", flush=True)
            summary.append({'shock': shock, 'warning_line_pct': W, 'collapse_fraction': frac,
                            'BED_star': round(b_hat, 4), 'ci_lo': round(ci_lo, 4), 'ci_hi': round(ci_hi, 4)})

    sdf = pd.DataFrame(summary)
    sdf.to_csv(OUT_DIR / 'warning_line_robustness_summary.csv', index=False, encoding='utf-8-sig')
    print(f"\n[输出] 汇总: {OUT_DIR / 'warning_line_robustness_summary.csv'}", flush=True)

    # 移动幅度诚实报告：同一冲击下，临界BED随警戒线40->60%的移动范围
    print("\n===== 移动幅度(同一冲击下,警戒线40%->60%临界BED的跨度) =====", flush=True)
    for shock in SHOCKS:
        vals = sdf[(sdf['shock'] == shock)]['BED_star'].dropna().values
        if len(vals) >= 2:
            print(f"  shock={shock:.1f}: 临界BED跨度=[{vals.min():.3f}, {vals.max():.3f}] "
                  f"极差={vals.max()-vals.min():.3f}", flush=True)
        else:
            print(f"  shock={shock:.1f}: 有限中点不足2个(多落在可行域外)", flush=True)


if __name__ == '__main__':
    main()
