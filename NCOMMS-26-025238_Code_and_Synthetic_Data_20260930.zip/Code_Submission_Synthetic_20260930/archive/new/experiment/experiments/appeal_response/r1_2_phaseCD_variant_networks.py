# -*- coding: utf-8 -*-
"""
R1.2 阶段C+D：替代边保留规则 与 批发层移除/降权 下的走廊存活检验
================================================================================

对准 Reviewer 1 第②条剩余要求："alternative deterministic edge-retention rules" 与
"whether corridor persists when wholesale-tier intermediates are removed or downweighted"。

阶段B已证明 739 边 100% 由确定性规则保留、走廊三段边全为确定性保留（故原计划阶段E"确定性骨干
=完整网络"平凡满足，不再单列）。本脚本检验走廊在**替代规则**下的稳健性：

- 阶段C（重要性阈值分级"更严"网络）：按 Final_Importance_Score 剔除低分边，保留 top 90/75/60/50%，
  始终保护 电池→EV 边(top0.8%，不受影响)。
- 阶段D（批发层）：D_IEEW 删 IEEW 单点；D_all_wholesale 删全部批发白名单节点关联边；
  D_dw* 对批发层边分级降权 ×0.75/0.5/0.25/0.1。

每个变体三层判据：
1. 结构层：走廊三段边是否仍存在于变体网络（确定性，无需仿真）；
2. 动力学层：LRAM/ONRAM 进入失效集合的频率 vs 基线，McNemar 精确检验（配对种子）；
3. 走廊通道：IEEW 进入失效集合/主失效路径的频率。
另记整体 Robustness 基线 vs 变体差分。
"""
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]  # new/experiment/
sys.path.insert(0, str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR / 'experiments'))

import numpy as np
import pandas as pd
from statsmodels.stats.contingency_tables import mcnemar

from run_resilience_simulation import run_single_simulation
from src.utils.path_config import PathConfig

BM, EV, IEEW, LRAM, ONRAM = '36901', '37111', '40621', '33501', '33509'
# 批发白名单(与构网脚本 BATTERY_WHOLESALE 一致)
WHOLESALE = {'40111', '40199', '40219', '40241', '40611', '40621', '40852'}
CORRIDOR_SEGMENTS = [(BM, IEEW), (IEEW, LRAM), (IEEW, ONRAM)]

TAU, BETA = 0.50, 10.0
BED_POINTS = [0.50, 0.60]
SHOCK = 0.8
N = 150

paths = PathConfig()
nodes_df = pd.read_csv(paths.get_input_file('battery_value_chain_nodes_personalized.csv'), encoding='utf-8-sig')
edges_full = pd.read_csv(paths.get_input_file('battery_value_chain_edges_personalized.csv'), encoding='utf-8-sig')
OUT_DIR = BASE_DIR.parent / 'rusult' / 'report' / 'appeal_smoke_tests'


def scol(df):
    return df['Source_Code'].astype(str), df['Target_Code'].astype(str)


def make_importance_variant(edges, keep_top_frac):
    """保留 Final_Importance_Score 最高的 keep_top_frac 比例边；始终保护 电池→EV 边。"""
    e = edges.copy()
    q = e['Final_Importance_Score'].quantile(1.0 - keep_top_frac)
    s, t = scol(e)
    protect = (s == BM) & (t == EV)
    keep = (e['Final_Importance_Score'] >= q) | protect
    return e[keep].copy()


def make_remove_nodes_variant(edges, nodes_to_remove):
    """删除涉及指定节点(集合)的全部关联边。"""
    e = edges.copy()
    s, t = scol(e)
    mask = s.isin(nodes_to_remove) | t.isin(nodes_to_remove)
    return e[~mask].copy()


def make_downweight_wholesale_variant(edges, factor):
    """对批发层节点的出/入边权重乘以 factor(降权而非删除)。"""
    e = edges.copy()
    s, t = scol(e)
    mask = s.isin(WHOLESALE) | t.isin(WHOLESALE)
    e.loc[mask, 'Weight'] = e.loc[mask, 'Weight'] * factor
    return e


def corridor_structural(edges):
    """返回走廊三段边在该变体网络中的存活情况(dict)。"""
    s, t = scol(edges)
    out = {}
    for a, b in CORRIDOR_SEGMENTS:
        out[f'{a}->{b}'] = bool(((s == a) & (t == b)).any())
    return out


def run_one(edges, BED, sim_id):
    res = run_single_simulation(
        nodes_df=nodes_df, edges_df=edges, target_BED=BED, simulation_id=sim_id,
        shock_intensity=SHOCK, shock_steps=5, recovery_steps=45,
        bankruptcy_threshold=TAU, steepness=BETA, max_cascade_rounds=15, verbose=False,
    )
    failed = set(str(x) for x in (res.get('failed_nodes') or []))
    path = set(str(x) for x in (res.get('main_failure_path') or []))
    return {
        'lram': LRAM in failed, 'onram': ONRAM in failed, 'ieew_failed': IEEW in failed,
        'ieew_path': IEEW in path, 'rob': res['Robustness'] * 100.0,
    }


def mcnemar_p(base_flags, var_flags):
    b = np.array(base_flags); v = np.array(var_flags)
    n11 = int(((b) & (v)).sum()); n10 = int(((b) & (~v)).sum())
    n01 = int(((~b) & (v)).sum()); n00 = int(((~b) & (~v)).sum())
    try:
        return mcnemar([[n11, n10], [n01, n00]], exact=True).pvalue, n10, n01
    except Exception:
        return np.nan, n10, n01


def main():
    variants = [
        ('C_top90', make_importance_variant(edges_full, 0.90)),
        ('C_top75', make_importance_variant(edges_full, 0.75)),
        ('C_top60', make_importance_variant(edges_full, 0.60)),
        ('C_top50', make_importance_variant(edges_full, 0.50)),
        ('D_remove_IEEW', make_remove_nodes_variant(edges_full, {IEEW})),
        ('D_remove_all_wholesale', make_remove_nodes_variant(edges_full, WHOLESALE)),
        ('D_downweight_0.75', make_downweight_wholesale_variant(edges_full, 0.75)),
        ('D_downweight_0.50', make_downweight_wholesale_variant(edges_full, 0.50)),
        ('D_downweight_0.25', make_downweight_wholesale_variant(edges_full, 0.25)),
        ('D_downweight_0.10', make_downweight_wholesale_variant(edges_full, 0.10)),
    ]
    total = len(BED_POINTS) * N * (1 + len(variants))
    print(f"[规模] {len(BED_POINTS)}个BED点 x {N}重复 x (1基线+{len(variants)}变体) = {total}次仿真 (shock={SHOCK})",
          flush=True)

    # 结构层(无需仿真)
    print("\n===== 结构层：走廊三段边在各变体中的存活 =====", flush=True)
    struct_rows = []
    print(f"  {'变体':<24} {'边数':>5}  BM→IEEW IEEW→LRAM IEEW→ONRAM", flush=True)
    print(f"  {'baseline':<24} {len(edges_full):>5}  " + "   ".join(['是']*3), flush=True)
    for name, ev in variants:
        cs = corridor_structural(ev)
        struct_rows.append({'variant': name, 'n_edges': len(ev),
                            **{f'seg_{a}_{b}': cs[f'{a}->{b}'] for a, b in CORRIDOR_SEGMENTS}})
        flags = ['是' if cs[f'{a}->{b}'] else '否' for a, b in CORRIDOR_SEGMENTS]
        print(f"  {name:<24} {len(ev):>5}  {flags[0]:>6} {flags[1]:>8} {flags[2]:>9}", flush=True)
    pd.DataFrame(struct_rows).to_csv(OUT_DIR / 'r1_2_phaseCD_structural.csv', index=False, encoding='utf-8-sig')

    # 动力学层
    summary = []
    done = 0
    for BED in BED_POINTS:
        # 基线：缓存每个 rep 的结果
        base = []
        for r in range(N):
            sim_id = int(BED * 100) * 100000 + r
            base.append(run_one(edges_full, BED, sim_id))
            done += 1
        base_lram = [x['lram'] for x in base]; base_onram = [x['onram'] for x in base]
        base_rob = np.mean([x['rob'] for x in base])
        print(f"\n[基线] BED={BED:.2f} shock={SHOCK}: LRAM失效率={np.mean(base_lram):.3f} "
              f"ONRAM失效率={np.mean(base_onram):.3f} Robustness={base_rob:.1f}%  累计={done}/{total}", flush=True)

        for name, ev in variants:
            var = []
            for r in range(N):
                sim_id = int(BED * 100) * 100000 + r
                var.append(run_one(ev, BED, sim_id))
                done += 1
            v_lram = [x['lram'] for x in var]; v_onram = [x['onram'] for x in var]
            p_lram, l10, l01 = mcnemar_p(base_lram, v_lram)
            p_onram, o10, o01 = mcnemar_p(base_onram, v_onram)
            row = {
                'BED': BED, 'variant': name,
                'base_lram_rate': np.mean(base_lram), 'var_lram_rate': np.mean(v_lram), 'mcnemar_p_lram': p_lram,
                'base_onram_rate': np.mean(base_onram), 'var_onram_rate': np.mean(v_onram), 'mcnemar_p_onram': p_onram,
                'var_ieew_failed_rate': np.mean([x['ieew_failed'] for x in var]),
                'var_ieew_path_rate': np.mean([x['ieew_path'] for x in var]),
                'base_rob': base_rob, 'var_rob': np.mean([x['rob'] for x in var]),
            }
            summary.append(row)
            print(f"  [{name:<22}] LRAM {np.mean(base_lram):.2f}->{np.mean(v_lram):.2f}(p={p_lram:.3f})  "
                  f"ONRAM {np.mean(base_onram):.2f}->{np.mean(v_onram):.2f}(p={p_onram:.3f})  "
                  f"Rob {base_rob:.0f}->{np.mean([x['rob'] for x in var]):.0f}%  累计={done}/{total}", flush=True)

    pd.DataFrame(summary).to_csv(OUT_DIR / 'r1_2_phaseCD_dynamic_summary.csv', index=False, encoding='utf-8-sig')
    print(f"\n[输出] 结构层: r1_2_phaseCD_structural.csv  动力学层: r1_2_phaseCD_dynamic_summary.csv", flush=True)


if __name__ == '__main__':
    main()
