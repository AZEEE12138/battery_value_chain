# -*- coding: utf-8 -*-
"""
蓄电池价值链网络动态韧性模拟器 - 主程序（修订版）

功能：
基于蓄电池价值链网络，模拟不同BED值下的网络对EV需求消失冲击的动态韧性
BED = 蓄电池→EV的边权重 / 蓄电池总出度权重

实验设计原则（修订）：
- BED仅作为网络结构特征（独立变量）
- EV需求消失是统一冲击机制（处理变量），与BED值无关
- 所有BED网络受到相同的冲击
- 观察不同BED网络对同一冲击的响应差异

时间轴设计（50步）：
- t=0: 准备阶段（记录初始状态）
- t=1-5: 吸收阶段（EV需求渐进式消失，5步内完成）
- t=6-50: 恢复-适应阶段（节点随机恢复，包括EV节点，45步）

韧性指标：
1. ER (Robustness) = min{ES(t)} - 最低性能点
2. ERR (Recovery Rate) = [ES(50) - ER] / (50 - tr) - 单位时间恢复速率
3. EPL (Performance Loss) = Σ[ES(0) - ES(t)] for t∈[tr, 50] - 累计性能损失

作者：Claude Code
日期：2025-12-03（修订版）
"""

import pandas as pd
import numpy as np
import networkx as nx
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set
import sys
from datetime import datetime
import random
import re

# 设置项目根目录
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

# 导入自定义模块
from src.core.network_rewiring import rewire_network_to_target_BED, calculate_current_BED
from src.core.cascade_failure import build_network_from_data
from src.core.ev_shock_recovery_policy import (
    ev_demand_shock_gradual,
    recovery_simulation_with_ev,
    calculate_network_performance
)
from src.core.supply_stability_policy import SupplyStabilityConfig

# 全局参数
BATTERY_NODE = '36901'
EV_NODE = '37111'
LIMIT_ONE_RECOVERY_PER_STEP = True


def extract_digits(value: str) -> str:
    return "".join(re.findall(r"[0-9]+", value))


def normalize_node_id(value: str) -> str:
    digits = extract_digits(str(value))
    return digits if digits else str(value).strip()


def _edge_code_cols(edges_df: pd.DataFrame) -> Tuple[str, str]:
    source_col = "Source_Code" if "Source_Code" in edges_df.columns else "Source"
    target_col = "Target_Code" if "Target_Code" in edges_df.columns else "Target"
    return source_col, target_col


def build_failure_steps_from_rounds(failed_nodes_by_round: List[List[str]]) -> Dict[str, int]:
    failure_step: Dict[str, int] = {}
    for round_idx, nodes in enumerate(failed_nodes_by_round, start=1):
        for node in nodes:
            node_id = normalize_node_id(node)
            if node_id and node_id not in failure_step:
                failure_step[node_id] = round_idx
    return failure_step


def build_failure_steps_from_steps(failed_nodes_by_step: List[List[str]]) -> Dict[str, int]:
    failure_step: Dict[str, int] = {}
    for step_idx, nodes in enumerate(failed_nodes_by_step, start=1):
        for node in nodes:
            node_id = normalize_node_id(node)
            if node_id and node_id not in failure_step:
                failure_step[node_id] = step_idx
    return failure_step


def compute_main_path(edges_df: pd.DataFrame, failure_step: Dict[str, int]) -> List[str]:
    failed_nodes = set(failure_step.keys())
    if not failed_nodes:
        return []

    in_edges: Dict[str, List[Tuple[str, float]]] = {n: [] for n in failed_nodes}
    out_edges: Dict[str, List[Tuple[str, float]]] = {n: [] for n in failed_nodes}
    source_col, target_col = _edge_code_cols(edges_df)
    for _, row in edges_df.iterrows():
        u = normalize_node_id(row[source_col])
        v = normalize_node_id(row[target_col])
        if u not in failed_nodes or v not in failed_nodes:
            continue
        w = float(row["Weight"])
        out_edges[u].append((v, w))
        in_edges[v].append((u, w))

    # Prefer earliest failure node as anchor; tie-break by max incident weight.
    earliest_step = min(failure_step.values()) if failure_step else 1
    earliest_nodes = [n for n, s in failure_step.items() if s == earliest_step]

    def incident_weight(node_id: str) -> float:
        return sum(w for _, w in in_edges.get(node_id, [])) + sum(
            w for _, w in out_edges.get(node_id, [])
        )

    anchor = None
    if earliest_nodes:
        anchor = max(earliest_nodes, key=incident_weight)
    if anchor is None:
        anchor = BATTERY_NODE if BATTERY_NODE in failed_nodes else None
    if anchor is None:
        anchor = max(failed_nodes, key=incident_weight)

    visited = {anchor}

    # Upstream
    upstream: List[str] = []
    current = anchor
    while True:
        candidates = [(u, w) for u, w in in_edges.get(current, []) if u not in visited]
        if not candidates:
            break
        next_u, _ = min(
            candidates,
            key=lambda x: (failure_step.get(x[0], 1_000_000), -x[1])
        )
        upstream.append(next_u)
        visited.add(next_u)
        current = next_u

    # Downstream
    downstream: List[str] = []
    current = anchor
    while True:
        candidates = [(v, w) for v, w in out_edges.get(current, []) if v not in visited]
        if not candidates:
            break
        next_v, _ = min(
            candidates,
            key=lambda x: (failure_step.get(x[0], 1_000_000), -x[1])
        )
        downstream.append(next_v)
        visited.add(next_v)
        current = next_v

    return list(reversed(upstream)) + [anchor] + downstream


def calculate_dynamic_resilience_metrics(
    performance_trajectory_shock: List[float],
    performance_trajectory_recovery: List[float],
    shock_steps: int = 5,
    recovery_steps: int = 45
) -> Dict[str, float]:
    """
    计算动态韧性三个指标

    完整轨迹：
    - 准备阶段: ES(0) - 初始状态
    - 吸收阶段: ES(1) - ES(5) - EV需求消失
    - 恢复-适应阶段: ES(6) - ES(50) - 节点恢复

    指标定义：
    1. ER (Robustness) = min{ES(t)} - 系统吸收冲击后的最低性能
    2. ERR (Recovery Rate) = [ES(te) – ER] / (te – tr) - 单位时间性能回升速率
    3. EPL (Performance Loss) = Σ[ES(0) – ES(t)] for t∈[tr, te] - 累计性能损失

    参数：
        performance_trajectory_shock: 吸收阶段轨迹（6个点: t=0到t=5）
        performance_trajectory_recovery: 恢复阶段轨迹（45个点: t=6到t=50）
        shock_steps: 吸收阶段步数（5步）
        recovery_steps: 恢复阶段步数（45步）

    返回：
        {
            'ER': float,  # 稳健性（最低性能点）
            'ERR': float,  # 恢复率
            'EPL': float,  # 性能损失
            'tr': int,  # 最低点时刻
            'te': int,  # 最终时刻
            'ES_0': float,  # 初始性能
            'ES_te': float,  # 最终性能
            'complete_trajectory': List[float]  # 完整轨迹
        }
    """
    # 合并完整轨迹
    complete_trajectory = performance_trajectory_shock + performance_trajectory_recovery
    T_total = len(complete_trajectory)  # 应该是51个点（0-50步）

    ES_0 = complete_trajectory[0]  # 初始性能

    # 1. 计算ER：最低性能点
    ER = min(complete_trajectory)
    tr = complete_trajectory.index(ER)  # 最低点时刻

    # 2. 计算ERR：恢复率
    ES_te = complete_trajectory[-1]  # 最终性能（第50步）
    te = T_total - 1  # 最终时刻索引

    if te > tr:
        ERR = (ES_te - ER) / (te - tr)  # 单位时间性能回升速率
    else:
        ERR = 0.0  # 未恢复

    # 3. 计算EPL：累计性能损失（从冲击开始到恢复完成，包含下降和恢复阶段）
    # 修正：根据参考图，EPL应包含整个性能损失区域（红色阴影区域）
    # 从t=0到te，包含吸收阶段和恢复阶段的所有损失
    EPL = 0.0
    for t in range(0, te + 1):
        performance_loss_t = ES_0 - complete_trajectory[t]
        if performance_loss_t > 0:  # 仅计算性能低于初始值的损失
            EPL += performance_loss_t

    return {
        'ER': ER,
        'ERR': ERR,
        'EPL': EPL,
        'tr': tr,
        'te': te,
        'ES_0': ES_0,
        'ES_te': ES_te,
        'complete_trajectory': complete_trajectory,
        'Robustness': ER / ES_0 if ES_0 > 0 else 0.0,  # 归一化稳健性
        'Recovery_Rate': ERR,
        'Performance_Loss': EPL
    }


def run_single_simulation(
    nodes_df: pd.DataFrame,
    edges_df: pd.DataFrame,
    target_BED: float,
    simulation_id: int,
    shock_intensity: float = 1.0,        # ⭐ 新增: 冲击强度参数
    shock_steps: int = 5,
    recovery_steps: int = 45,
    bankruptcy_threshold: float = 0.50,  # ⭐ 破产阈值: 0.50（统一值，与核心代码修改后一致）
    steepness: float = 10.0,             # ⭐ 提高到10.0
    max_cascade_rounds: int = 100,       # ⭐ 级联轮数默认100 (实验中覆盖为15)
    p_recover: float = 0.05,
    recovery_threshold: float = 0.9,
    noise_level: float = 0.10,
    verbose: bool = False,
    policy_config: Optional[SupplyStabilityConfig] = None,
    policy_upstream_nodes: Optional[Set[str]] = None
) -> Dict:
    """
    运行单次完整模拟（50步时间轴）- 支持可配置冲击强度

    时间轴：
    - t=0: 准备阶段
    - t=1-5: 吸收阶段（EV需求渐进式消失）
    - t=6-50: 恢复-适应阶段（节点恢复）

    步骤：
    1. 重连网络达到目标BED（网络结构特征）
    2. [t=0] 准备阶段：记录初始状态
    3. [t=1-5] 吸收阶段：EV需求消失冲击（可配置强度）
    4. [t=6-50] 恢复-适应阶段：节点恢复（包括EV）
    5. 计算动态韧性指标（ER, ERR, EPL）

    参数：
        nodes_df: 节点数据
        edges_df: 边数据
        target_BED: 目标BED值
        simulation_id: 模拟ID（用于随机种子）
        shock_intensity: 冲击强度（0.6=60%, 0.8=80%, 1.0=100%）
        shock_steps: 吸收阶段步数（默认5步）
        recovery_steps: 恢复阶段步数（默认45步）
        bankruptcy_threshold: 破产阈值（默认0.50）
        steepness: Sigmoid陡峭度（默认10.0）
        max_cascade_rounds: 最大级联轮数（默认100，实验中覆盖为15）
        [其他参数见各模块]

    返回：
        包含所有指标的字典
    """
    # 设置随机种子（确保可复现）
    np.random.seed(42 + simulation_id)
    random.seed(42 + simulation_id)

    if verbose:
        print(f"\n{'='*80}")
        print(f"模拟 #{simulation_id}: BED = {target_BED:.2f}, 冲击强度 = {shock_intensity*100:.0f}%")
        print(f"{'='*80}")

    # 步骤1: 网络重连到目标BED
    if verbose:
        print(f"\n[步骤1] 网络重连到BED = {target_BED:.2f}...")

    edges_adjusted, BED_achieved, rewire_stats = rewire_network_to_target_BED(
        nodes_df, edges_df, target_BED, verbose=False
    )

    # 构建NetworkX图
    G_original = build_network_from_data(nodes_df, edges_adjusted)

    if verbose:
        print(f"  BED达成值: {BED_achieved:.4f}")
        print(f"  网络节点数: {G_original.number_of_nodes()}")
        print(f"  网络边数: {G_original.number_of_edges()}")

    # 步骤2-3: [t=0-5] 准备+吸收阶段 - EV需求渐进式消失
    if verbose:
        print(f"\n[步骤2-3] 吸收阶段: EV需求渐进式消失（t=0-5, 冲击强度={shock_intensity*100:.0f}%）...")

    G_after_shock, shock_stats = ev_demand_shock_gradual(
        G=G_original.copy(),
        G_original=G_original,
        ev_node=EV_NODE,
        shock_steps=shock_steps,
        shock_intensity=shock_intensity,  # ⭐ 传递冲击强度参数
        bankruptcy_threshold=bankruptcy_threshold,
        steepness=steepness,
        max_cascade_rounds=max_cascade_rounds,
        verbose=False,
        policy_config=policy_config,
        policy_upstream_nodes=policy_upstream_nodes
    )

    # 提取吸收阶段性能轨迹（6个点：t=0到t=5）
    performance_trajectory_shock = shock_stats['performance_trajectory_shock']

    if verbose:
        print(f"  初始性能 ES(0): {performance_trajectory_shock[0]:.2e}")
        print(f"  最低性能 ER: {shock_stats['min_performance']:.2e} (t={shock_stats['min_performance_time']})")
        print(f"  稳健性: {shock_stats['robustness']:.4f}")
        print(f"  失效节点数: {shock_stats['num_failed_nodes']}")

    # 步骤4: [t=6-50] 恢复-适应阶段
    if verbose:
        print(f"\n[步骤4] 恢复-适应阶段: 节点恢复（t=6-50）...")

    G_recovered, recovery_stats = recovery_simulation_with_ev(
        G_current=G_after_shock,
        G_original=G_original,
        failed_nodes=shock_stats['total_failed_nodes'],
        ev_node=EV_NODE,
        p_recover=p_recover,
        recovery_steps=recovery_steps,
        noise_level=noise_level,
        recovery_threshold=recovery_threshold,
        recovery_increment=0.25,  # ⭐ 新增：每步恢复25%（加快恢复速度）
        shock_intensity=shock_intensity,  # ⭐ 新增：传递冲击强度用于EV恢复
        limit_one_recovery_per_step=LIMIT_ONE_RECOVERY_PER_STEP,
        verbose=False
    )

    # 提取恢复阶段性能轨迹（45个点：t=6到t=50）
    performance_trajectory_recovery = recovery_stats['performance_trajectory_recovery']

    if verbose:
        print(f"  恢复时间: t={recovery_stats['recovery_time']}")
        print(f"  最终性能: {recovery_stats['final_performance']:.2e}")
        print(f"  恢复达成: {recovery_stats['recovery_achieved']}")
        print(f"  EV节点恢复: {recovery_stats['ev_recovered']}")

    # 步骤5: 计算动态韧性指标
    if verbose:
        print(f"\n[步骤5] 计算动态韧性指标...")

    metrics = calculate_dynamic_resilience_metrics(
        performance_trajectory_shock=performance_trajectory_shock,
        performance_trajectory_recovery=performance_trajectory_recovery,
        shock_steps=shock_steps,
        recovery_steps=recovery_steps
    )

    if verbose:
        print(f"  ER (Robustness): {metrics['Robustness']:.4f}")
        print(f"  ERR (Recovery Rate): {metrics['ERR']:.2e}")
        print(f"  EPL (Performance Loss): {metrics['EPL']:.2e}")

    # 整合结果
    # 生成主失效路径（使用本次仿真的 edges_adjusted + 级联轮次）
    failed_by_round = shock_stats.get('cascade_failed_by_round', []) or []
    failed_by_step = shock_stats.get('failed_nodes_by_step', []) or []
    failure_step_source = ""
    failure_step = {}
    if any(failed_by_round):
        failure_step = build_failure_steps_from_rounds(failed_by_round)
        failure_step_source = "cascade_failed_by_round"
    elif any(failed_by_step):
        failure_step = build_failure_steps_from_steps(failed_by_step)
        failure_step_source = "failed_nodes_by_step"

    main_failure_path = compute_main_path(edges_adjusted, failure_step) if failure_step else []
    path_method = f"sim_edges_{failure_step_source}" if failure_step_source else ""

    result = {
        'BED_target': target_BED,
        'BED_achieved': BED_achieved,
        'simulation_id': simulation_id,
        'shock_intensity': shock_intensity,  # ⭐ 新增: 记录冲击强度
        'ES_0': metrics['ES_0'],
        'ES_min': metrics['ER'],
        'ES_final': metrics['ES_te'],
        'Robustness': metrics['Robustness'],
        'Recovery_Rate': metrics['ERR'],
        'Performance_Loss': metrics['EPL'],
        'tr': metrics['tr'],
        'te': metrics['te'],
        'recovery_time': recovery_stats['recovery_time'],
        'recovery_achieved': recovery_stats['recovery_achieved'],
        'failed_nodes_shock': shock_stats['num_failed_nodes'],
        'failed_nodes': shock_stats['total_failed_nodes'],
        'failed_nodes_by_step': failed_by_step,
        'cascade_failed_by_round': failed_by_round,
        'main_failure_path': main_failure_path,
        'path_method': path_method,
        'failure_step_source': failure_step_source,
        'remaining_failed_nodes': recovery_stats['remaining_failed_nodes'],
        'ev_recovered': recovery_stats['ev_recovered'],
        'ev_recovered_at': recovery_stats['ev_recovered_at'] if recovery_stats['ev_recovered'] else None,
        'shock_robustness': shock_stats['robustness'],
        'complete_trajectory': metrics['complete_trajectory']  # 添加完整轨迹
    }

    if verbose:
        print(f"{'='*80}\n")

    return result


def run_full_experiment(
    bed_start: float = 0.30,
    bed_end: float = 0.90,
    bed_step: float = 0.01,
    shock_intensities: list = None,  # ⭐ 新增: 冲击强度列表
    num_repeats: int = 200,  # ⭐ 默认200次重复（更高统计精度）
    bankruptcy_threshold: float = 0.5,  # ⭐ 破产阈值（更新为0.5，更严格的破产条件）
    max_cascade_rounds: int = 15,  # ⭐ 级联轮数（更新为15轮）
    verbose: bool = False
) -> pd.DataFrame:
    """
    运行完整实验（三层循环）- 支持多种冲击强度敏感性分析

    循环结构：
    外循环：遍历所有BED值（生成不同BED的网络）
    中循环：遍历所有冲击强度（40%, 60%, 80%）⭐ 新增
    内循环：每个BED×冲击强度重复num_repeats次（相同冲击，不同随机种子）

    参数：
        bed_start: BED起始值 (默认0.30)
        bed_end: BED结束值 (默认0.90)
        bed_step: BED步长 (默认0.01)
        shock_intensities: 冲击强度列表（默认[0.4, 0.6, 0.8]）
        num_repeats: 每个BED×冲击强度重复次数 (默认100)
        bankruptcy_threshold: 破产阈值 (默认0.5)
        max_cascade_rounds: 最大级联轮数 (默认15)
        verbose: 是否打印详细信息

    返回：
        结果DataFrame（包含shock_intensity列）
    """
    # 默认冲击强度
    if shock_intensities is None:
        shock_intensities = [0.4, 0.6, 0.8]  # 40%, 60%, 80%冲击（移除100%）
    # 使用PathConfig获取路径
    from src.utils.path_config import PathConfig
    paths = PathConfig()

    nodes_path = paths.get_input_file('battery_value_chain_nodes_personalized.csv')
    edges_path = paths.get_input_file('battery_value_chain_edges_personalized.csv')
    output_dir = paths.results_data_dir

    # 生成BED值序列
    BED_values = [round(x, 2) for x in np.arange(bed_start, bed_end + bed_step/2, bed_step)]

    print("="*80)
    print("蓄电池价值链网络动态韧性模拟实验 - 敏感性分析")
    print("="*80)
    print(f"实验设计:")
    print(f"  - BED作为网络结构特征（独立变量）")
    print(f"  - 冲击强度: {[f'{int(s*100)}%' for s in shock_intensities]}")
    print(f"  - 50步时间轴: 准备(0) + 吸收(1-5) + 恢复(6-50)")
    print(f"\n开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"BED值数量: {len(BED_values)}")
    print(f"冲击强度数量: {len(shock_intensities)}")
    print(f"每个BED×冲击强度重复次数: {num_repeats}")
    print(f"总模拟次数: {len(BED_values) * len(shock_intensities) * num_repeats}")
    print("="*80)

    # 加载数据
    print(f"\n[1/4] 加载数据...")
    nodes_df = pd.read_csv(nodes_path, encoding='utf-8-sig')
    edges_df = pd.read_csv(edges_path, encoding='utf-8-sig')
    print(f"  节点数: {len(nodes_df)}")
    print(f"  边数: {len(edges_df)}")

    # 存储结果
    all_results = []

    # 三层循环：BED × 冲击强度 × 重复次数
    total_simulations = len(BED_values) * len(shock_intensities) * num_repeats
    current_sim = 0

    print(f"\n[2/4] 运行模拟...")

    for i, BED in enumerate(BED_values, 1):
        print(f"\n  BED = {BED:.2f} ({i}/{len(BED_values)})")

        # 中层循环：遍历冲击强度 ⭐ 新增
        for shock_intensity in shock_intensities:
            print(f"    冲击强度 = {shock_intensity*100:.0f}%")

            # 内循环：重复模拟
            for repeat in range(1, num_repeats + 1):
                current_sim += 1
                sim_id = (i - 1) * len(shock_intensities) * num_repeats + \
                         shock_intensities.index(shock_intensity) * num_repeats + repeat

                if verbose or current_sim % 10 == 0:
                    print(f"      重复 {repeat}/{num_repeats} (总进度: {current_sim}/{total_simulations}, {current_sim/total_simulations*100:.1f}%)")

                try:
                    # 运行单次模拟（传递shock_intensity参数）⭐
                    result = run_single_simulation(
                        nodes_df=nodes_df,
                        edges_df=edges_df,
                        target_BED=BED,
                        simulation_id=sim_id,
                        shock_intensity=shock_intensity,  # ⭐ 传递冲击强度
                        shock_steps=5,
                        recovery_steps=45,
                        bankruptcy_threshold=bankruptcy_threshold,  # ⭐ 传递破产阈值
                        max_cascade_rounds=max_cascade_rounds,  # ⭐ 传递级联轮数
                        verbose=False
                    )

                    all_results.append(result)

                except Exception as e:
                    print(f"      警告 模拟失败: {str(e)}")
                    continue

    # 转换为DataFrame
    results_df = pd.DataFrame(all_results)

    # 计算统计摘要（按BED和冲击强度分组）⭐
    print(f"\n[3/4] 计算统计摘要...")
    summary_df = results_df.groupby(['BED_target', 'shock_intensity']).agg({
        'Robustness': ['mean', 'std'],
        'Recovery_Rate': ['mean', 'std'],
        'Performance_Loss': ['mean', 'std'],
        'recovery_time': ['mean', 'std'],
        'failed_nodes_shock': ['mean', 'std']
    }).reset_index()

    # 保存结果
    print(f"\n[4/4] 保存结果...")
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # 保存完整结果（包含冲击强度列）⭐
    full_results_file = output_path / 'battery_chain_resilience_results_sensitivity.csv'
    results_df.to_csv(full_results_file, index=False, encoding='utf-8-sig')
    print(f"  完整结果: {full_results_file}")

    # 保存统计摘要
    summary_file = output_path / 'battery_chain_resilience_summary_sensitivity.csv'
    summary_df.to_csv(summary_file, index=False, encoding='utf-8-sig')
    print(f"  统计摘要: {summary_file}")

    print(f"\n{'='*80}")
    print(f"实验完成!")
    print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"总模拟次数: {len(results_df)}")
    print(f"{'='*80}\n")

    return results_df


def main():
    """主函数"""

    # BED值序列（0.30-0.90，步长0.01，共61个点）
    BED_values = [round(x, 2) for x in np.arange(0.30, 0.91, 0.01)]

    # 运行实验
    results_df = run_full_experiment(
        bed_start=0.30,
        bed_end=0.90,
        bed_step=0.01,
        shock_intensities=[0.4, 0.6, 0.8],
        num_repeats=200,  # ⭐ 200次重复（更高统计精度）
        verbose=False
    )

    # 显示前几行结果
    print("\n结果预览:")
    print(results_df[['BED_target', 'Robustness', 'Recovery_Rate', 'Performance_Loss', 'recovery_time']].head(10).to_string())

    # 显示统计摘要
    print("\n统计摘要（前5个BED值）:")
    summary = results_df.groupby('BED_target').agg({
        'Robustness': ['mean', 'std'],
        'Recovery_Rate': ['mean', 'std'],
        'Performance_Loss': ['mean', 'std']
    }).head()
    print(summary.to_string())


if __name__ == '__main__':
    main()
