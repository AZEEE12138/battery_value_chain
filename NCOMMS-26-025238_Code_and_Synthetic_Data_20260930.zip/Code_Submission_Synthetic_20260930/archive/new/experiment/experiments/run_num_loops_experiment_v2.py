# -*- coding: utf-8 -*-
"""
资源循环强度(recycling_intensity)与蓄电池价值链韧性实验 - V3版本（2025基准线）
基于正确的韧性计算代码 (run_resilience_simulation.py)

目标：
- 探究资源循环强度(recycling_intensity)如何影响蓄电池价值链网络的韧性
- 从开始就连接所有87条回收边，通过改变recycling_intensity控制权重
- 使用2025年BED基准线（0.636）进行实验
- 使用与combined实验一致的韧性指标计算方式

设计（修改版）：
1. 固定BED=0.636（2025年基准线，来自BED_timeseries_sci.png）
2. 固定num_loops=None（添加所有87条回收边）
3. recycling_intensity: 0.0-1.0（20个采样点）
4. 冲击强度: 0.6 (60%，固定值)
5. 每个配置重复100次
6. 总模拟次数: 20 × 1 × 100 = 2000次

作者: Claude Code
日期: 2025-12-25
修改日期: 2026-01-23（修改为recycling_intensity版本）
"""

import pandas as pd
import numpy as np
import networkx as nx
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import sys
from datetime import datetime
import random

# 设置项目根目录
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

# 导入核心模块
from src.core.network_rewiring import rewire_network_to_target_BED, calculate_current_BED
from src.core.cascade_failure import build_network_from_data
from src.core.ev_shock_recovery import (
    ev_demand_shock_gradual,
    recovery_simulation_with_ev,
    calculate_network_performance
)
from src.core.recycling_policy_improved import add_recycling_loops_strategy2_improved
from src.utils.path_config import PathConfig

# 全局参数
BATTERY_NODE_CODE = '36901'
EV_NODE_CODE = '37111'

# 加载回收路径（全局变量）
CUSTOM_RECYCLING_PATHS = None


def load_custom_recycling_paths():
    """加载回收路径或核心闭环回收边文件"""
    global CUSTOM_RECYCLING_PATHS
    if CUSTOM_RECYCLING_PATHS is None:
        base_dir = PathConfig().base_dir
        # 优先使用核心闭环回收边文件（用户放在项目根目录）
        core_edges_file = base_dir.parent / 'recycling_edges_core_closedloop.csv'
        if not core_edges_file.exists():
            core_edges_file = base_dir / 'data' / 'recycling_paths' / 'recycling_edges_core_closedloop.csv'
        if core_edges_file.exists():
            from src.core.recycling_policy_improved import load_recycling_edges_from_csv
            profit_allocation = {
                'second-life': 0.45,
                'material recycling': 0.49,
                'secondary material': 0.06,
                'second life': 0.45
            }
            CUSTOM_RECYCLING_PATHS = load_recycling_edges_from_csv(
                core_edges_file,
                profit_allocation=profit_allocation,
                use_first_three_cols=True
            )
            print(f"  [OK] 加载核心闭环回收边: {len(CUSTOM_RECYCLING_PATHS)}条")
        else:
            CUSTOM_RECYCLING_PATHS = None
            print("  [WARN] recycling_edges_core_closedloop.csv not found; using default paths")
    return CUSTOM_RECYCLING_PATHS



def _coalesce_column(df: pd.DataFrame, target: str, candidates: List[str]) -> Optional[str]:
    """Ensure `target` exists by copying from the first matching candidate column."""
    if target in df.columns:
        return target
    for col in candidates:
        if col in df.columns:
            df[target] = df[col]
            return col
    return None


def _normalize_input_columns(nodes_df: pd.DataFrame, edges_df: pd.DataFrame) -> None:
    """Normalize node/edge columns to match core loaders."""
    node_id_src = _coalesce_column(nodes_df, 'Id', [
        'Id', 'Node_ID', 'NodeId', 'Node', 'Industry_Code', 'Node_Code'
    ])
    if node_id_src is None:
        raise ValueError("nodes_df missing node id column (Id/Node/Industry_Code/etc.)")

    name_src = _coalesce_column(nodes_df, 'Node_Name', [
        'Node_Name', 'Node_Name_CN', 'Node_Name_EN', 'Label', 'Name'
    ])
    if name_src is None and 'Node_Name' not in nodes_df.columns:
        nodes_df['Node_Name'] = ''

    abbr_src = _coalesce_column(nodes_df, 'Abbreviation', [
        'Abbreviation', 'Node_Abbr', 'Abbr'
    ])
    if abbr_src is None and 'Abbreviation' not in nodes_df.columns:
        nodes_df['Abbreviation'] = ''

    weight_src = _coalesce_column(nodes_df, 'Total_Weight', [
        'Total_Weight', 'TotalWeight', 'Weight', 'Total_weight'
    ])
    if weight_src is None and 'Total_Weight' not in nodes_df.columns:
        nodes_df['Total_Weight'] = 0.0

    source_src = _coalesce_column(edges_df, 'Source', [
        'Source', 'Source_Code', 'From', 'Start', 'Src'
    ])
    target_src = _coalesce_column(edges_df, 'Target', [
        'Target', 'Target_Code', 'To', 'End', 'Dst'
    ])
    if source_src is None or target_src is None:
        raise ValueError("edges_df missing Source/Target columns")

    weight_edge_src = _coalesce_column(edges_df, 'Weight', [
        'Weight', 'weight', 'Value', 'Amount'
    ])
    if weight_edge_src is None and 'Weight' not in edges_df.columns:
        edges_df['Weight'] = 0.0

    nodes_df['Total_Weight'] = pd.to_numeric(nodes_df['Total_Weight'], errors='coerce').fillna(0.0)
    edges_df['Weight'] = pd.to_numeric(edges_df['Weight'], errors='coerce').fillna(0.0)
def calculate_dynamic_resilience_metrics(
    performance_trajectory_shock: List[float],
    performance_trajectory_recovery: List[float],
    shock_steps: int = 5,
    recovery_steps: int = 45
) -> Dict[str, float]:
    """
    计算动态韧性三个指标（与run_resilience_simulation.py完全一致）

    完整轨迹：
    - 准备阶段: ES(0) - 初始状态
    - 吸收阶段: ES(1) - ES(5) - EV需求消失
    - 恢复-适应阶段: ES(6) - ES(50) - 节点恢复

    指标定义：
    1. ER (Robustness) = min{ES(t)} - 系统吸收冲击后的最低性能
    2. ERR (Recovery Rate) = [ES(te) – ER] / (te – tr) - 单位时间性能回升速率
    3. EPL (Performance Loss) = Σ[ES(0) – ES(t)] for t∈[tr, te] - 累计性能损失

    参数：
        performance_trajectory_shock: 吸收阶段轨迹（6个点: t=0到t=5）
        performance_trajectory_recovery: 恢复阶段轨迹（45个点: t=6到t=50）
        shock_steps: 吸收阶段步数（5步）
        recovery_steps: 恢复阶段步数（45步）

    返回：
        {
            'ER': float,  # 稳健性（最低性能点）
            'ERR': float,  # 恢复率
            'EPL': float,  # 性能损失
            'tr': int,  # 最低点时刻
            'te': int,  # 最终时刻
            'ES_0': float,  # 初始性能
            'ES_te': float,  # 最终性能
            'complete_trajectory': List[float],  # 完整轨迹
            'Robustness': float,  # 归一化稳健性 (0-1)
            'Recovery_Rate': float,  # 恢复率
            'Performance_Loss': float  # 性能损失
        }
    """
    # 合并完整轨迹
    complete_trajectory = performance_trajectory_shock + performance_trajectory_recovery
    T_total = len(complete_trajectory)  # 应该是51个点（0-50步）

    ES_0 = complete_trajectory[0]  # 初始性能

    # 1. 计算ER：最低性能点
    ER = min(complete_trajectory)
    tr = complete_trajectory.index(ER)  # 最低点时刻

    # 2. 计算ERR：恢复率
    ES_te = complete_trajectory[-1]  # 最终性能（第50步）
    te = T_total - 1  # 最终时刻索引

    if te > tr:
        ERR = (ES_te - ER) / (te - tr)  # 单位时间性能回升速率
    else:
        ERR = 0.0  # 未恢复

    # 3. 计算EPL：累计性能损失（从冲击开始到恢复完成，包含下降和恢复阶段）
    # 修正：根据参考图，EPL应包含整个性能损失区域（红色阴影区域）
    # 从t=0到te，包含吸收阶段和恢复阶段的所有损失
    EPL = 0.0
    for t in range(0, te + 1):
        performance_loss_t = ES_0 - complete_trajectory[t]
        if performance_loss_t > 0:  # 仅计算性能低于初始值的损失
            EPL += performance_loss_t

    return {
        'ER': ER,
        'ERR': ERR,
        'EPL': EPL,
        'tr': tr,
        'te': te,
        'ES_0': ES_0,
        'ES_te': ES_te,
        'complete_trajectory': complete_trajectory,
        'Robustness': ER / ES_0 if ES_0 > 0 else 0.0,  # ⭐ 归一化稳健性 (0-1范围, 与combined一致)
        'Recovery_Rate': ERR,
        'Performance_Loss': EPL
    }


def run_single_simulation(
    nodes_df: pd.DataFrame,
    edges_df: pd.DataFrame,
    num_recycling_loops: int,
    simulation_id: int,
    shock_intensity: float = 0.6,
    retired_battery_price: float = 138.0,
    target_BED: float = 0.8,
    recycling_intensity: float = 1.0,
    shock_steps: int = 5,
    recovery_steps: int = 45,
    bankruptcy_threshold: float = 0.5,  # ✅ 修改为与combined一致: 0.5（原0.35）
    steepness: float = 10.0,
    max_cascade_rounds: int = 15,  # ✅ 修改为与combined一致: 15（原100）
    p_recover: float = 0.05,
    recovery_threshold: float = 0.9,
    noise_level: float = 0.10,
    custom_paths: List = None,
    verbose: bool = False
) -> Dict:
    """
    运行单次完整模拟（50步时间轴）- 支持资源循环强度变化

    时间轴：
    - t=0: 准备阶段
    - t=1-5: 吸收阶段（EV需求渐进式消失）
    - t=6-50: 恢复-适应阶段（节点恢复）

    步骤：
    1. 重连网络达到目标BED=0.8（高依赖度场景）
    2. 添加所有87条回收边（权重由recycling_intensity控制）
    3. [t=0-5] 吸收阶段：EV需求消失冲击
    4. [t=6-50] 恢复-适应阶段：节点恢复（包括EV）
    5. 计算动态韧性指标（ER, ERR, EPL）

    参数：
        nodes_df: 节点数据
        edges_df: 边数据
        num_recycling_loops: 资源循环边数（None=全部87条）
        simulation_id: 模拟ID（用于随机种子）
        shock_intensity: 冲击强度（0.4=40%, 0.6=60%, 0.8=80%）
        retired_battery_price: 退役电池价格（JPY/kg）
        target_BED: 目标BED值（默认0.8）
        recycling_intensity: 资源循环强度（0.0-1.0）← 核心变量
        [其他参数见各模块]

    返回：
        包含所有指标的字典
    """
    # 设置随机种子（确保可复现）
    np.random.seed(42 + simulation_id)
    random.seed(42 + simulation_id)

    if verbose:
        print(f"\n{'='*80}")
        print(f"模拟 #{simulation_id}: num_loops = {num_recycling_loops}, 冲击强度 = {shock_intensity*100:.0f}%")
        print(f"{'='*80}")

    # 步骤1: 网络重连到目标BED
    if verbose:
        print(f"\n[步骤1] 网络重连到BED = {target_BED:.2f}...")

    edges_adjusted, BED_achieved, rewire_stats = rewire_network_to_target_BED(
        nodes_df, edges_df, target_BED, verbose=False, validate_bilateral_conservation=False
    )

    # 构建NetworkX图
    G_base = build_network_from_data(nodes_df, edges_adjusted)

    if verbose:
        print(f"  BED达成值: {BED_achieved:.4f}")
        print(f"  网络节点数: {G_base.number_of_nodes()}")
        print(f"  网络边数: {G_base.number_of_edges()}")

    # 步骤2: 添加回收边 ⭐ 使用改进的函数和自定义路径
    if verbose:
        print(f"\n[步骤2] 添加回收循环: 所有87条边（强度={recycling_intensity:.2f}）...")

    G_with_recycling, recycling_stats = add_recycling_loops_strategy2_improved(
        G=G_base,
        num_loops=num_recycling_loops,  # ⭐ None = 添加所有87条边
        recycling_intensity=recycling_intensity,  # ⭐ 核心变量（0.0-1.0）
        battery_node=BATTERY_NODE_CODE,
        ev_node=EV_NODE_CODE,
        retired_battery_price=retired_battery_price,
        custom_paths=custom_paths,  # ⭐ 使用自定义回收路径
        verbose=False,
        export_log=False
    )

    recycling_scale = recycling_stats['total_recycling_weight']
    if verbose:
        print(f"  添加回收边数: {recycling_stats['num_added_edges']}")
        print(f"  回收边总权重: {recycling_scale:,.2f} JPY/year")
        print(f"  资源循环强度: {recycling_intensity:.4f}")

    # 步骤3-4: [t=0-5] 准备+吸收阶段 - EV需求渐进式消失
    if verbose:
        print(f"\n[步骤3-4] 吸收阶段: EV需求渐进式消失（t=0-5, 冲击强度={shock_intensity*100:.0f}%）...")

    G_after_shock, shock_stats = ev_demand_shock_gradual(
        G=G_with_recycling.copy(),
        G_original=G_with_recycling,
        ev_node=EV_NODE_CODE,
        shock_steps=shock_steps,
        shock_intensity=shock_intensity,  # ⭐ 传递冲击强度参数
        bankruptcy_threshold=bankruptcy_threshold,
        steepness=steepness,
        max_cascade_rounds=max_cascade_rounds,
        verbose=False
    )

    # 提取吸收阶段性能轨迹（6个点：t=0到t=5）
    performance_trajectory_shock = shock_stats['performance_trajectory_shock']

    if verbose:
        print(f"  初始性能 ES(0): {performance_trajectory_shock[0]:.2e}")
        print(f"  最低性能 ER: {shock_stats['min_performance']:.2e} (t={shock_stats['min_performance_time']})")
        print(f"  稳健性: {shock_stats['robustness']:.4f}")
        print(f"  失效节点数: {shock_stats['num_failed_nodes']}")

    # 步骤5: [t=6-50] 恢复-适应阶段
    if verbose:
        print(f"\n[步骤5] 恢复-适应阶段: 节点恢复（t=6-50）...")

    G_recovered, recovery_stats = recovery_simulation_with_ev(
        G_current=G_after_shock,
        G_original=G_with_recycling,
        failed_nodes=shock_stats['total_failed_nodes'],
        ev_node=EV_NODE_CODE,
        p_recover=p_recover,
        recovery_steps=recovery_steps,
        noise_level=noise_level,
        recovery_threshold=recovery_threshold,
        verbose=False
    )

    # 提取恢复阶段性能轨迹（45个点：t=6到t=50）
    performance_trajectory_recovery = recovery_stats['performance_trajectory_recovery']

    if verbose:
        print(f"  恢复时间: t={recovery_stats['recovery_time']}")
        print(f"  最终性能: {recovery_stats['final_performance']:.2e}")
        print(f"  恢复达成: {recovery_stats['recovery_achieved']}")
        print(f"  EV节点恢复: {recovery_stats['ev_recovered']}")

    # 步骤6: 计算动态韧性指标
    if verbose:
        print(f"\n[步骤6] 计算动态韧性指标...")

    metrics = calculate_dynamic_resilience_metrics(
        performance_trajectory_shock=performance_trajectory_shock,
        performance_trajectory_recovery=performance_trajectory_recovery,
        shock_steps=shock_steps,
        recovery_steps=recovery_steps
    )

    if verbose:
        print(f"  Robustness: {metrics['Robustness']:.4f}")
        print(f"  Recovery_Rate: {metrics['ERR']:.2e}")
        print(f"  Performance_Loss: {metrics['EPL']:.2e}")

    # 整合结果
    result = {
        'simulation_id': simulation_id,
        'BED_target': target_BED,
        'BED_achieved': BED_achieved,
        'num_recycling_loops': num_recycling_loops,
        'recycling_intensity': recycling_intensity,
        'recycling_scale': recycling_scale,
        'shock_intensity': shock_intensity,
        'retired_battery_price': retired_battery_price,
        'strategy': 'strategy2_num_loops',
        'Robustness': metrics['Robustness'],  # ⭐ 归一化值 (0-1)
        'Recovery_Rate': metrics['Recovery_Rate'],
        'Performance_Loss': metrics['Performance_Loss'],
        'tr': metrics['tr'],
        'ES_0': metrics['ES_0'],
        'ES_te': metrics['ES_te'],
        'num_failed_nodes': shock_stats['num_failed_nodes'],
        'num_recovered_nodes': recovery_stats['remaining_failed_nodes'],
        'ev_recovered': recovery_stats['ev_recovered'],
        'recovery_time': recovery_stats['recovery_time']
    }

    if verbose:
        print(f"{'='*80}\n")

    return result


def run_full_experiment(
    num_loops_range: Tuple[int, int] = (1, 0),
    shock_intensities: List[float] = None,
    num_repeats: int = 100,
    target_BED: float = 0.8,
    retired_battery_price: float = 138.0,
    bankruptcy_threshold: float = 0.5,  # ✅ 修改为与combined一致: 0.5（原0.35）
    max_cascade_rounds: int = 15,  # ✅ 修改为与combined一致: 15（原100）
    scenario_tag: Optional[str] = None,
    verbose: bool = False
) -> pd.DataFrame:
    """
    运行完整实验（三层循环）

    循环结构：
    外循环：遍历资源循环强度 (0.0, 0.05, 0.10, ..., 1.0)
    中循环：遍历冲击强度 (40%, 60%, 80%)
    内循环：每个配置重复100次

    参数：
        num_loops_range: num_loops range (start, end; end<=0 auto max)
        shock_intensities: 冲击强度列表（默认[0.6]）
        num_repeats: 每个配置重复次数
        target_BED: 目标BED值（固定为0.8）
        retired_battery_price: 退役电池价格
        verbose: 是否打印详细信息

    返回：
        结果DataFrame
    """
    # 默认冲击强度
    if shock_intensities is None:
        shock_intensities = [0.4, 0.6, 0.8]  # 40%, 60%, 80%冲击

    # 使用PathConfig获取路径
    from src.utils.path_config import PathConfig
    paths = PathConfig()

    nodes_path = paths.data_outputs_dir / 'Network_nodes.csv'
    edges_path = paths.data_outputs_dir / 'Network_edges.csv'
    if not nodes_path.exists():
        raise FileNotFoundError(f"nodes file not found: {nodes_path}")
    if not edges_path.exists():
        raise FileNotFoundError(f"edges file not found: {edges_path}")
    output_dir = paths.results_data_dir

    num_loops_start = num_loops_range[0]

    # 加载数据
    print(f"\n[1/5] 加载数据...")
    nodes_df = pd.read_csv(nodes_path, encoding='utf-8-sig')
    edges_df = pd.read_csv(edges_path, encoding='utf-8-sig')
    _normalize_input_columns(nodes_df, edges_df)
    print(f"  节点数: {len(nodes_df)}")
    print(f"  边数: {len(edges_df)}")

    # 加载自定义回收路径
    print(f"\n[2/5] 加载自定义回收路径...")
    custom_paths = load_custom_recycling_paths()
    max_loops = num_loops_range[1]
    if max_loops <= 0:
        max_loops = len(custom_paths) if custom_paths else 70
    if custom_paths is not None and len(custom_paths) > 0:
        max_loops = min(max_loops, len(custom_paths))
    if max_loops < num_loops_start:
        raise ValueError(f"num_loops_range无效: start={num_loops_start}, end={max_loops}")

    # 生成num_loops序列
    num_loops_values = list(range(num_loops_start, max_loops + 1))

    print("="*80)
    print("资源循环次数(num_loops)与蓄电池价值链韧性实验 - V2版本")
    print("="*80)
    print(f"实验设计:")
    print(f"  - 固定BED = {target_BED} (高依赖度场景)")
    print(f"  - num_loops: {num_loops_start}-{max_loops} (资源循环次数)")
    print(f"  - 冲击强度: {[f'{int(s*100)}%' for s in shock_intensities]}")
    print(f"  - 50步时间轴: 准备(0) + 吸收(1-5) + 恢复(6-50)")
    print(f"\n开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"num_loops数量: {len(num_loops_values)}")
    print(f"冲击强度数量: {len(shock_intensities)}")
    print(f"每个配置重复次数: {num_repeats}")
    print(f"总模拟次数: {len(num_loops_values) * len(shock_intensities) * num_repeats}")
    print("="*80)

    # 存储结果
    all_results = []

    # 三层循环：num_loops × 冲击强度 × 重复次数
    total_simulations = len(num_loops_values) * len(shock_intensities) * num_repeats
    current_sim = 0

    print(f"\n[3/5] 运行模拟...")

    for i, num_loops in enumerate(num_loops_values, 1):
        print(f"\n  num_loops = {num_loops} ({i}/{len(num_loops_values)})")

        # 中层循环：遍历冲击强度
        for shock_intensity in shock_intensities:
            print(f"    冲击强度 = {shock_intensity*100:.0f}%")

            # 内循环：重复模拟
            for repeat in range(1, num_repeats + 1):
                current_sim += 1
                sim_id = (i - 1) * len(shock_intensities) * num_repeats + \
                         shock_intensities.index(shock_intensity) * num_repeats + repeat

                if verbose or current_sim % 10 == 0:
                    print(f"      重复 {repeat}/{num_repeats} (总进度: {current_sim}/{total_simulations}, {current_sim/total_simulations*100:.1f}%)")

                try:
                    # 运行单次模拟
                    result = run_single_simulation(
                        nodes_df=nodes_df,
                        edges_df=edges_df,
                        num_recycling_loops=num_loops,
                        simulation_id=sim_id,
                        shock_intensity=shock_intensity,
                        retired_battery_price=retired_battery_price,
                        target_BED=target_BED,
                        shock_steps=5,
                        recovery_steps=45,
                        bankruptcy_threshold=bankruptcy_threshold,
                        max_cascade_rounds=max_cascade_rounds,
                        custom_paths=custom_paths,
                        verbose=False
                    )

                    all_results.append(result)

                except Exception as e:
                    print(f"      警告 模拟失败: {str(e)}")
                    continue

    # 转换为DataFrame
    results_df = pd.DataFrame(all_results)

    # 计算统计摘要（按num_loops和冲击强度分组）
    print(f"\n[4/5] 计算统计摘要...")
    summary_df = results_df.groupby(['num_recycling_loops', 'shock_intensity']).agg({
        'Robustness': ['mean', 'std'],
        'Recovery_Rate': ['mean', 'std'],
        'Performance_Loss': ['mean', 'std'],
        'recovery_time': ['mean', 'std'],
        'num_failed_nodes': ['mean', 'std']
    }).reset_index()

    # 保存结果
    print(f"\n[5/5] 保存结果...")
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    tag = f"{scenario_tag}_" if scenario_tag else ""

    # 保存完整结果
    full_results_file = output_path / f'recycling_num_loops_experiment_v2_{tag}{timestamp}.csv'
    results_df.to_csv(full_results_file, index=False, encoding='utf-8-sig')
    print(f"  完整结果: {full_results_file}")

    # 保存统计摘要
    summary_file = output_path / f'recycling_num_loops_summary_v2_{tag}{timestamp}.csv'
    summary_df.to_csv(summary_file, index=False, encoding='utf-8-sig')
    print(f"  统计摘要: {summary_file}")

    print(f"\n{'='*80}")
    print(f"实验完成!")
    print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"总模拟次数: {len(results_df)}")
    print(f"{'='*80}\n")

    return results_df


def main():
    """主函数"""

    scenarios = [
        ('2025_baseline', 0.636),
        ('2030_conservative', 0.612),
        ('2030_optimistic', 0.457),
        ('2035_conservative', 0.581),
        ('2035_optimistic', 0.440),
    ]

    for scenario_tag, bed in scenarios:
        print("\n" + "="*80)
        print(f"开始情景: {scenario_tag}, BED={bed}")
        print("="*80)

        results_df = run_full_experiment(
            num_loops_range=(1, 0),
            shock_intensities=[0.6],
            num_repeats=100,
            target_BED=bed,
            retired_battery_price=138.0,
            scenario_tag=scenario_tag,
            verbose=False
        )

        print("\n结果预览:")
        print(results_df[['num_recycling_loops', 'shock_intensity', 'Robustness', 'Recovery_Rate', 'Performance_Loss']].head(5).to_string())


if __name__ == '__main__':
    main()
