﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Bar charts for top-3 recycling edge contributions (2025 baseline).
Layout: 1x3, panels (d)-(f), nature-style.
"""
from pathlib import Path
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import sys

# add project root to path
BASE_DIR = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(BASE_DIR))

from src.utils.path_config import PathConfig
from src.core.recycling_policy_improved import get_default_recycling_paths, load_recycling_edges_from_csv

# Nature-style config (match main figure)
matplotlib.rcParams['font.family'] = 'Arial'
matplotlib.rcParams['font.size'] = 11
matplotlib.rcParams['axes.labelsize'] = 12
matplotlib.rcParams['axes.titlesize'] = 14
matplotlib.rcParams['xtick.labelsize'] = 10
matplotlib.rcParams['ytick.labelsize'] = 10
matplotlib.rcParams['legend.fontsize'] = 9
matplotlib.rcParams['figure.dpi'] = 300
matplotlib.rcParams['savefig.dpi'] = 300
matplotlib.rcParams['savefig.bbox'] = 'tight'
matplotlib.rcParams['savefig.pad_inches'] = 0.1
matplotlib.rcParams['savefig.facecolor'] = 'white'
matplotlib.rcParams['savefig.edgecolor'] = 'none'
matplotlib.rcParams['axes.linewidth'] = 1.2
matplotlib.rcParams['lines.linewidth'] = 1.8
matplotlib.rcParams['grid.linewidth'] = 0.5
matplotlib.rcParams['legend.frameon'] = True
matplotlib.rcParams['legend.framealpha'] = 0.95
matplotlib.rcParams['legend.edgecolor'] = '#333333'
matplotlib.rcParams['legend.fancybox'] = False
matplotlib.rcParams['xtick.major.width'] = 1.2
matplotlib.rcParams['ytick.major.width'] = 1.2
matplotlib.rcParams['xtick.major.size'] = 5
matplotlib.rcParams['ytick.major.size'] = 5
matplotlib.rcParams['xtick.direction'] = 'in'
matplotlib.rcParams['ytick.direction'] = 'in'

# Colors (standard palette)
TOP1_COLOR = '#a30543'
TOP2_COLOR = '#f36f43'
TOP3_COLOR = '#4965b0'

TOTAL_STEPS = 50
RECOVERY_STEPS = 45
MAX_PERFORMANCE_LOSS = TOTAL_STEPS + 1
MAX_RECOVERY_RATE = (1.0 / RECOVERY_STEPS) * 100


def find_latest_baseline_file(results_dir: Path) -> Path:
    pattern = 'recycling_num_loops_experiment_v2_2025_baseline_*.csv'
    files = sorted(results_dir.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    if files:
        return files[0]
    # fallback: any file with BED_target=0.636
    for f in sorted(results_dir.glob('recycling_num_loops_experiment_v2_*.csv'), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            df_check = pd.read_csv(f, nrows=1)
            if 'BED_target' in df_check.columns and abs(df_check['BED_target'].iloc[0] - 0.636) < 0.001:
                return f
        except Exception:
            continue
    raise FileNotFoundError('Baseline results file not found')


def compute_metric_series(df: pd.DataFrame) -> Dict[int, Dict[str, float]]:
    df = df[df['shock_intensity'] == 0.6].copy()
    ES_0_mean = df['ES_0'].mean() if 'ES_0' in df.columns else 1.0

    grouped = df.groupby('num_recycling_loops').agg({
        'Robustness': 'mean',
        'Recovery_Rate': 'mean',
        'Performance_Loss': 'mean',
    }).reset_index()

    series = {}
    for _, row in grouped.iterrows():
        k = int(row['num_recycling_loops'])
        series[k] = {
            # Convert to the same units used in the main figure
            'Robustness': row['Robustness'] * 100,
            'Recovery_Rate': (row['Recovery_Rate'] / ES_0_mean / MAX_RECOVERY_RATE) * 10000,
            'Performance_Loss': (row['Performance_Loss'] / ES_0_mean / MAX_PERFORMANCE_LOSS) * 100,
        }
    return series


def build_edge_list() -> List[Tuple[str, str, str, float]]:
    profit_allocation = {
        'second-life': 0.45,
        'material recycling': 0.49,
        'secondary material': 0.06,
        'second life': 0.45
    }
    base_dir = PathConfig().base_dir
    core_edges_file = base_dir.parent / 'recycling_edges_core_closedloop.csv'
    if not core_edges_file.exists():
        core_edges_file = base_dir / 'data' / 'recycling_paths' / 'recycling_edges_core_closedloop.csv'
    if core_edges_file.exists():
        return load_recycling_edges_from_csv(
            core_edges_file,
            profit_allocation=profit_allocation,
            use_first_three_cols=True
        )
    fallback_allocation = {'EV': 0.45, 'DES': 0.49, 'DR': 0.06}
    paths = get_default_recycling_paths('37111', '36901', fallback_allocation)
    return paths[:70]


def compute_edge_contributions(series: Dict[int, Dict[str, float]], max_loops: int) -> Dict[int, Dict[str, float]]:
    contributions = {}
    for k in range(2, max_loops + 1):
        if k not in series or (k - 1) not in series:
            continue
        delta_rob = series[k]['Robustness'] - series[k - 1]['Robustness']
        delta_rec = series[k]['Recovery_Rate'] - series[k - 1]['Recovery_Rate']
        delta_pl = series[k]['Performance_Loss'] - series[k - 1]['Performance_Loss']
        contributions[k] = {
            'Robustness': delta_rob,
            'Recovery_Rate': delta_rec,
            'Performance_Loss': -delta_pl,  # loss reduction as positive
        }
    return contributions


def select_top3_by_bin(contributions: Dict[int, Dict[str, float]], edges: List[Tuple[str, str, str, float]], metric: str, max_loops: int):
    bins = {i: [] for i in range(10)}
    for k, vals in contributions.items():
        coverage = k / max_loops * 100
        bin_idx = min(int((coverage - 1e-9) // 10), 9)
        target, source, sector, mult = edges[k - 1]
        bins[bin_idx].append({
            'k': k,
            'coverage': coverage,
            'value': vals[metric],
            'edge': f"{target}->{source}",
            'sector': sector,
        })
    top3 = {}
    for b, items in bins.items():
        items_sorted = sorted(items, key=lambda x: x['value'], reverse=True)
        top3[b] = items_sorted[:3]
    return top3


def plot_bars(top3_by_bin: Dict[int, List[Dict]], metric: str, ax, panel_label: str, ylabel: str):
    title_map = {
        'Robustness': 'Value Sustenance Floor',
        'Performance_Loss': 'Cumulative Economic Cost',
        'Recovery_Rate': 'Economic Resilience Speed'
    }
    centers = [5 + 10 * i for i in range(10)]
    width = 2.2
    offsets = [-width, 0.0, width]
    colors = [TOP1_COLOR, TOP2_COLOR, TOP3_COLOR]

    for bin_idx, center in enumerate(centers):
        items = top3_by_bin.get(bin_idx, [])
        for j in range(3):
            if j >= len(items):
                continue
            item = items[j]
            x = center + offsets[j]
            y = item['value']
            ax.bar(x, y, width=width, color=colors[j], alpha=0.9, zorder=3)

    ax.axhline(0, color='#333333', linewidth=0.8)
    ax.set_xlim(0, 100)
    ax.set_xticks([0, 20, 40, 60, 80, 100])
    ax.set_xlabel('Path Coverage Rate (%)', fontsize=12, fontweight='bold')
    ax.set_ylabel(ylabel, fontsize=12, fontweight='bold')
    ax.set_title(f"({panel_label}) {title_map.get(metric, metric)}", fontsize=14, fontweight='bold', loc='left')
    ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5, color='#BDBDBD', zorder=0)
    for spine in ax.spines.values():
        spine.set_linewidth(1.2)



def main():
    paths = PathConfig()
    results_dir = paths.results_data_dir
    figures_dir = paths.results_figures_dir

    baseline_file = find_latest_baseline_file(results_dir)
    df = pd.read_csv(baseline_file, encoding='utf-8-sig')

    series = compute_metric_series(df)
    edges = build_edge_list()
    max_loops = len(edges)
    if max_loops == 0:
        raise ValueError("No recycling edges available for contributions")
    contributions = compute_edge_contributions(series, max_loops)

    metrics = [
        ('Robustness', 'Robustness Contribution (%)'),
        ('Performance_Loss', 'Performance Loss Reduction (%)'),
        ('Recovery_Rate', 'Recovery Rate Contribution (%)')
    ]

    fig, axes = plt.subplots(1, 3, figsize=(11, 3.6), dpi=300)
    axes_flat = axes.flatten() if hasattr(axes, 'flatten') else [axes]

    for idx, (metric, ylabel) in enumerate(metrics):
        top3 = select_top3_by_bin(contributions, edges, metric, max_loops)
        plot_bars(top3, metric, axes_flat[idx], chr(103 + idx), ylabel)

    # legend for Top1/Top2/Top3
    handles = [
        plt.Line2D([0], [0], color=TOP1_COLOR, lw=6),
        plt.Line2D([0], [0], color=TOP2_COLOR, lw=6),
        plt.Line2D([0], [0], color=TOP3_COLOR, lw=6),
    ]
    labels = ['Top 1', 'Top 2', 'Top 3']
    fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(0.5, -0.08), ncol=3)

    plt.tight_layout(rect=[0, 0.08, 1, 1])

    png_file = figures_dir / 'path_coverage_vs_resilience_BED0.8_bars.png'
    pdf_file = figures_dir / 'path_coverage_vs_resilience_BED0.8_bars.pdf'
    fig.savefig(png_file, dpi=300, bbox_inches='tight', pad_inches=0.1, facecolor='white', edgecolor='none')
    fig.savefig(pdf_file, format='pdf', bbox_inches='tight', pad_inches=0.1, facecolor='white', edgecolor='none')
    plt.close()

    print(f"[OK] PNG: {png_file}")
    print(f"[OK] PDF: {pdf_file}")


if __name__ == '__main__':
    main()
