﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Scenario marginal contributions at 20% coverage steps (1x3, nature style).
"""
from pathlib import Path
from typing import Dict, List
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import sys

# add project root to path
BASE_DIR = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(BASE_DIR))

from src.utils.path_config import PathConfig

# Nature-style config
matplotlib.rcParams['font.family'] = 'Arial'
matplotlib.rcParams['font.size'] = 11
matplotlib.rcParams['axes.labelsize'] = 12
matplotlib.rcParams['axes.titlesize'] = 14
matplotlib.rcParams['xtick.labelsize'] = 10
matplotlib.rcParams['ytick.labelsize'] = 10
matplotlib.rcParams['legend.fontsize'] = 9
matplotlib.rcParams['figure.dpi'] = 300
matplotlib.rcParams['savefig.dpi'] = 300
matplotlib.rcParams['savefig.bbox'] = 'tight'
matplotlib.rcParams['savefig.pad_inches'] = 0.1
matplotlib.rcParams['savefig.facecolor'] = 'white'
matplotlib.rcParams['savefig.edgecolor'] = 'none'
matplotlib.rcParams['axes.linewidth'] = 1.2
matplotlib.rcParams['lines.linewidth'] = 1.8
matplotlib.rcParams['grid.linewidth'] = 0.5
matplotlib.rcParams['legend.frameon'] = True
matplotlib.rcParams['legend.framealpha'] = 0.95
matplotlib.rcParams['legend.edgecolor'] = '#333333'
matplotlib.rcParams['legend.fancybox'] = False
matplotlib.rcParams['xtick.major.width'] = 1.2
matplotlib.rcParams['ytick.major.width'] = 1.2
matplotlib.rcParams['xtick.major.size'] = 5
matplotlib.rcParams['ytick.major.size'] = 5
matplotlib.rcParams['xtick.direction'] = 'in'
matplotlib.rcParams['ytick.direction'] = 'in'

TOTAL_STEPS = 50
RECOVERY_STEPS = 45
MAX_PERFORMANCE_LOSS = TOTAL_STEPS + 1
MAX_RECOVERY_RATE = (1.0 / RECOVERY_STEPS) * 100

SCENARIOS = [
    ('2025 Baseline', '2025_baseline', 0.636, '#4965b0'),
    ('2030 Conservative', '2030_conservative', 0.612, '#f36f43'),
    ('2030 Optimistic', '2030_optimistic', 0.457, '#80cba4'),
    ('2035 Conservative', '2035_conservative', 0.581, '#a30543'),
    ('2035 Optimistic', '2035_optimistic', 0.440, '#fbda83'),
]

METRICS = [
    ('Robustness', 'Robustness Contribution (%)', 'Value Sustenance Floor'),
    ('Performance_Loss', 'Performance Loss Reduction (%)', 'Cumulative Economic Cost'),
    ('Recovery_Rate', 'Recovery Rate Contribution (%)', 'Economic Resilience Speed'),
]

# coverage steps (percent)
COVER_STEPS = [20, 40, 60, 80, 100]


def find_latest_scenario_file(results_dir: Path, bed_value: float) -> Path:
    files = sorted(results_dir.glob('recycling_num_loops_experiment_v2_*.csv'),
                   key=lambda p: p.stat().st_mtime, reverse=True)
    for f in files:
        try:
            df_check = pd.read_csv(f, nrows=1)
            if 'BED_target' not in df_check.columns:
                continue
            bed_val = float(df_check['BED_target'].iloc[0])
            if abs(bed_val - bed_value) > 0.001:
                continue
            return f
        except Exception:
            continue
    raise FileNotFoundError(f'No results file for bed={bed_value}')


def compute_metric_fits(df: pd.DataFrame) -> Dict[str, np.ndarray]:
    df = df[df['shock_intensity'] == 0.6].copy()
    ES_0_mean = df['ES_0'].mean() if 'ES_0' in df.columns else 1.0

    grouped = df.groupby('num_recycling_loops').agg({
        'Robustness': 'mean',
        'Recovery_Rate': 'mean',
        'Performance_Loss': 'mean',
    }).reset_index()

    x = grouped['num_recycling_loops'].values
    y_rob = grouped['Robustness'].values * 100
    y_rec = (grouped['Recovery_Rate'].values / ES_0_mean / MAX_RECOVERY_RATE) * 10000
    y_pl = (grouped['Performance_Loss'].values / ES_0_mean / MAX_PERFORMANCE_LOSS) * 100

    degree = min(3, max(1, len(np.unique(x)) - 1))
    return {
        'Robustness': np.polyfit(x, y_rob, deg=degree),
        'Recovery_Rate': np.polyfit(x, y_rec, deg=degree),
        'Performance_Loss': np.polyfit(x, y_pl, deg=degree),
    }

def compute_boundary_loops(max_loops: int) -> List[int]:
    boundaries = [1]
    for pct in COVER_STEPS:
        if pct >= 100:
            boundary = max_loops
        else:
            boundary = int(round(max_loops * pct / 100.0))
        if boundary <= boundaries[-1]:
            boundary = min(max_loops, boundaries[-1] + 1)
        boundaries.append(boundary)
    boundaries[-1] = max_loops
    for i in range(1, len(boundaries)):
        if boundaries[i] <= boundaries[i - 1]:
            boundaries[i] = min(max_loops, boundaries[i - 1] + 1)
    boundaries[-1] = max_loops
    return boundaries


def compute_marginal_at_steps(fits: Dict[str, np.ndarray], boundary_loops: List[int]) -> Dict[int, Dict[str, float]]:
    values = {}
    # evaluate fitted curves at coverage boundaries (0,20,...,100)
    y_rob = np.polyval(fits['Robustness'], boundary_loops)
    y_rec = np.polyval(fits['Recovery_Rate'], boundary_loops)
    y_pl = np.polyval(fits['Performance_Loss'], boundary_loops)

    for i, loop in enumerate(boundary_loops[1:], 1):
        delta = {
            'Robustness': y_rob[i] - y_rob[i - 1],
            'Recovery_Rate': y_rec[i] - y_rec[i - 1],
            'Performance_Loss': -(y_pl[i] - y_pl[i - 1]),
        }
        values[loop] = delta
    return values


def plot_panel(ax, metric: str, ylabel: str, title: str, scenario_values: Dict[str, List[float]]):
    # place each 20% group inside its bin: 0-20, 20-40, ...
    centers = [10, 30, 50, 70, 90]
    bar_width = 2.0
    offsets = [-4, -2, 0, 2, 4]

    for idx, (name, _, _, color) in enumerate(SCENARIOS):
        vals = scenario_values[name]
        xs = [c + offsets[idx] for c in centers]
        ax.bar(xs, vals, width=bar_width, color=color, alpha=0.9, zorder=3, label=name)

    ax.axhline(0, color='#333333', linewidth=0.8)
    ax.set_xlim(0, 100)
    ax.set_xticks([0, 20, 40, 60, 80, 100])
    ax.set_xlabel('Path Coverage Rate (%)', fontsize=12, fontweight='bold')
    ax.set_ylabel(ylabel, fontsize=12, fontweight='bold')
    ax.set_title(title, fontsize=14, fontweight='bold', loc='left')
    ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5, color='#BDBDBD', zorder=0)
    for spine in ax.spines.values():
        spine.set_linewidth(1.2)


def main():
    paths = PathConfig()
    results_dir = paths.results_data_dir
    figures_dir = paths.results_figures_dir

    scenario_fits = {}
    for label, tag, bed, _ in SCENARIOS:
        file_path = find_latest_scenario_file(results_dir, bed)
        df = pd.read_csv(file_path, encoding='utf-8-sig')
        max_loops = int(df['num_recycling_loops'].max())
        scenario_fits[label] = {
            'fits': compute_metric_fits(df),
            'boundary_loops': compute_boundary_loops(max_loops),
        }

    fig, axes = plt.subplots(1, 3, figsize=(11, 3.6), dpi=300)
    axes_flat = axes.flatten() if hasattr(axes, 'flatten') else [axes]

    for idx, (metric, ylabel, title_name) in enumerate(METRICS):
        scenario_values = {}
        for label, _, _, _ in SCENARIOS:
            boundary_loops = scenario_fits[label]['boundary_loops']
            deltas = compute_marginal_at_steps(scenario_fits[label]['fits'], boundary_loops)
            values = [deltas.get(loop, {}).get(metric, 0.0) for loop in boundary_loops[1:]]
            scenario_values[label] = values
        panel_label = chr(100 + idx)
        title = f"({panel_label}) {title_name}"
        plot_panel(axes_flat[idx], metric, ylabel, title, scenario_values)

    # legend
    handles = [
        plt.Line2D([0], [0], color=color, lw=6)
        for _, _, _, color in SCENARIOS
    ]
    labels = [f"{name} (BED={bed*100:.1f}%)" for name, _, bed, _ in SCENARIOS]
    fig.legend(handles, labels, loc='lower center', bbox_to_anchor=(0.5, -0.08), ncol=3)

    plt.tight_layout(rect=[0, 0.08, 1, 1])

    png_file = figures_dir / 'path_coverage_vs_resilience_BED0.8_bars_20pct_scenarios.png'
    pdf_file = figures_dir / 'path_coverage_vs_resilience_BED0.8_bars_20pct_scenarios.pdf'
    fig.savefig(png_file, dpi=300, bbox_inches='tight', pad_inches=0.1, facecolor='white', edgecolor='none')
    fig.savefig(pdf_file, format='pdf', bbox_inches='tight', pad_inches=0.1, facecolor='white', edgecolor='none')
    plt.close()

    print(f"[OK] PNG: {png_file}")
    print(f"[OK] PDF: {pdf_file}")


if __name__ == '__main__':
    main()
