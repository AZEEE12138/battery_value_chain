#!/usr/bin/env python

# -*- coding: utf-8 -*-

"""

在原有图表格式上添加三情境对比曲?保持 path_coverage_vs_resilience_BED0.8_smooth_lowess_thresholds.pdf 的原有格?只是添加2030保守情境?030乐观情境的曲?"""

import pandas as pd

import numpy as np

import matplotlib.pyplot as plt

import matplotlib

from scipy import stats

from scipy.interpolate import UnivariateSpline

from pathlib import Path

import sys
import warnings
import re
from collections import defaultdict
warnings.filterwarnings('ignore')

# Options (default: 3 panels, vertical 1x3)
SHOW_NODE_ATTRITION = False
ONE_ROW_LAYOUT = True

if '--with-node-attrition' in sys.argv:
    SHOW_NODE_ATTRITION = True
if '--layout-2x2' in sys.argv:
    ONE_ROW_LAYOUT = False



# 添加experiment目录到路径，确保可导入src

EXP_DIR = Path(__file__).resolve().parents[3]

sys.path.insert(0, str(EXP_DIR))



from src.utils.path_config import PathConfig



# Nature Communications标准配置

matplotlib.rcParams['font.family'] = 'Arial'

matplotlib.rcParams['font.size'] = 11

matplotlib.rcParams['axes.labelsize'] = 12

matplotlib.rcParams['axes.titlesize'] = 14

matplotlib.rcParams['xtick.labelsize'] = 10

matplotlib.rcParams['ytick.labelsize'] = 10

matplotlib.rcParams['legend.fontsize'] = 10

matplotlib.rcParams['figure.dpi'] = 300

matplotlib.rcParams['savefig.dpi'] = 300

matplotlib.rcParams['savefig.bbox'] = 'tight'

matplotlib.rcParams['savefig.pad_inches'] = 0.1

matplotlib.rcParams['savefig.facecolor'] = 'white'

matplotlib.rcParams['savefig.edgecolor'] = 'none'

matplotlib.rcParams['axes.linewidth'] = 1.2

matplotlib.rcParams['lines.linewidth'] = 2.0

matplotlib.rcParams['grid.linewidth'] = 0.5

matplotlib.rcParams['legend.frameon'] = True

matplotlib.rcParams['legend.framealpha'] = 0.95

matplotlib.rcParams['legend.edgecolor'] = '#333333'

matplotlib.rcParams['legend.fancybox'] = False

matplotlib.rcParams['xtick.major.width'] = 1.2

matplotlib.rcParams['ytick.major.width'] = 1.2

matplotlib.rcParams['xtick.major.size'] = 5

matplotlib.rcParams['ytick.major.size'] = 5

matplotlib.rcParams['xtick.direction'] = 'in'

matplotlib.rcParams['ytick.direction'] = 'in'



# Color palette (from new\\standard\\33444266607798430.jpg)
SMOOTH_COLOR_2035C = '#a30543'  # deep red
SMOOTH_COLOR_2030C = '#f36f43'  # orange
SMOOTH_COLOR_2035O = '#fbda83'  # light yellow
SMOOTH_COLOR_2030O = '#80cba4'  # light green
SMOOTH_COLOR_2025 = '#4965b0'  # blue
THRESHOLD_COLOR = '#fbda83'  # light yellow for threshold


TOTAL_STEPS = 50

RECOVERY_STEPS = 45

MAX_PERFORMANCE_LOSS = TOTAL_STEPS + 1
MAX_RECOVERY_RATE = (1.0 / RECOVERY_STEPS) * 100
TARGET_SHOCK = 0.6

REQUIRED_NUM_REPEATS = 10


# 五个情境的数据文件（2025基准线使?00次重复，其他使用100次重复）

scenarios = {
    '2025 Baseline': {
        'file': None,
        'bed': 0.636,
        'color': SMOOTH_COLOR_2025,
        'label': '2025 Baseline',
        'linestyle': '-',
        'linewidth': 2.5,
        'num_repeats': REQUIRED_NUM_REPEATS,
        'max_loops': None
    },
    '2030 Conservative': {
        'file': None,
        'bed': 0.612,
        'color': SMOOTH_COLOR_2030C,
        'label': '2030 Conservative',
        'linestyle': '-',
        'linewidth': 2.5,
        'num_repeats': REQUIRED_NUM_REPEATS,
        'max_loops': None
    },
    '2030 Optimistic': {
        'file': None,
        'bed': 0.457,
        'color': SMOOTH_COLOR_2030O,
        'label': '2030 Optimistic',
        'linestyle': '-',
        'linewidth': 2.5,
        'num_repeats': REQUIRED_NUM_REPEATS,
        'max_loops': None
    },
    '2035 Conservative': {
        'file': None,
        'bed': 0.581,
        'color': SMOOTH_COLOR_2035C,
        'label': '2035 Conservative',
        'linestyle': '-',
        'linewidth': 2.5,
        'num_repeats': REQUIRED_NUM_REPEATS,
        'max_loops': None
    },
    '2035 Optimistic': {
        'file': None,
        'bed': 0.440,
        'color': SMOOTH_COLOR_2035O,
        'label': '2035 Optimistic',
        'linestyle': '-',
        'linewidth': 2.5,
        'num_repeats': REQUIRED_NUM_REPEATS,
        'max_loops': None
    }
}




def transform_to_path_coverage(num_loops: np.ndarray, max_loops: int = 70) -> np.ndarray:

    """Transform num_recycling_loops to path coverage rate (%)"""

    return (num_loops / max_loops) * 100













def aggregate_with_ci(df: pd.DataFrame, group_cols: list, value_col: str, alpha: float = 0.05) -> pd.DataFrame:

    """按组聚合数据并计?5%置信区间"""

    grouped = df.groupby(group_cols)[value_col].agg(['mean', 'std', 'count']).reset_index()



    grouped['ci'] = grouped.apply(

        lambda row: stats.t.ppf(1 - alpha/2, row['count'] - 1) * row['std'] / np.sqrt(row['count'])

        if row['count'] > 1 else 0,

        axis=1

    )



    grouped['ci_lower'] = grouped['mean'] - grouped['ci']

    grouped['ci_upper'] = grouped['mean'] + grouped['ci']



    return grouped





def detect_threshold_point_derivative_zero(
    coeffs: np.ndarray,
    x_dense: np.ndarray,
    preferred_range: tuple = None
) -> tuple:
    """Threshold where derivative of fitted curve is zero (turning point)."""
    dcoeffs = np.polyder(coeffs)
    roots = np.roots(dcoeffs)
    real_roots = roots[np.isreal(roots)].real

    x_min = float(x_dense.min())
    x_max = float(x_dense.max())
    valid = real_roots[(real_roots >= x_min) & (real_roots <= x_max)]

    if preferred_range is not None and len(valid) > 0:
        pref_min, pref_max = preferred_range
        pref_valid = valid[(valid >= pref_min) & (valid <= pref_max)]
        if len(pref_valid) > 0:
            valid = pref_valid

    if len(valid) > 0:
        if len(valid) > 1:
            ddcoeffs = np.polyder(dcoeffs)
            dd_vals = np.polyval(ddcoeffs, valid)
            x_thr = valid[np.argmax(np.abs(dd_vals))]
        else:
            x_thr = valid[0]
    else:
        y_fit = np.polyval(coeffs, x_dense)
        dy = np.gradient(y_fit, x_dense)
        x_thr = x_dense[np.argmin(np.abs(dy))]

    y_thr = float(np.polyval(coeffs, x_thr))
    return float(x_thr), y_thr



print("=" * 80)

print("Generate path coverage vs resilience curves (5 scenarios)")

print("=" * 80)



paths = PathConfig()

results_data_dir = paths.results_data_dir

figures_dir = paths.results_figures_dir



# 动态查找所有情境的数据文件（支?00次和500次重复）

print("\n[动态查找所有情境数据文?- 支持100次和500次重复]")

all_experiment_files = sorted(results_data_dir.glob('recycling_num_loops_experiment_v2_*.csv'),

                               key=lambda x: x.stat().st_mtime, reverse=True)



for f in all_experiment_files:

    try:

        # 先检查文件大小（快速筛选）

        df_full = pd.read_csv(f)

        nrows = len(df_full)



        df_check = pd.read_csv(f, nrows=1)

        if 'BED_target' in df_check.columns:

            bed_val = df_check['BED_target'].iloc[0]



            # 为每个情境查找匹配的文件

            for scenario_name, scenario_info in scenarios.items():

                if scenario_info['file'] is None:

                    # 检查BED值是否匹?
                    if abs(bed_val - scenario_info['bed']) < 0.001:

                        # 根据文件中num_recycling_loops的实际数量计算期望行数
                        unique_loops = df_full['num_recycling_loops'].nunique() if 'num_recycling_loops' in df_full.columns else 0
                        expected_rows = unique_loops * scenario_info['num_repeats']

                        if nrows == expected_rows:

                            scenarios[scenario_name]['file'] = f.name
                            scenarios[scenario_name]['max_loops'] = unique_loops

                            print(f"  [OK] {scenario_name}: {f.name} (BED={bed_val:.4f}, {nrows}条记? {scenario_info['num_repeats']}次重?")

                            break

    except:

        pass



# 检查是否找到所有文?print("\n[数据文件完整性检查]")

missing_scenarios = []

for scenario_name, scenario_info in scenarios.items():

    if scenario_info['file'] is None:

        print(f"  [WARN] 未找?{scenario_name} 的{scenario_info['num_repeats']}次重复数?(BED={scenario_info['bed']:.4f})")

        missing_scenarios.append(scenario_name)

    else:

        print(f"  [OK] {scenario_name}: 数据就绪")



if missing_scenarios:

    print(f"\n[WARN] {len(missing_scenarios)}个情境缺少数据，这些曲线将被跳过")

else:

    print(f"\n[OK] 所?个情境的数据均已就绪?2025基准? 500次重? 其他: 100次重?")



# 四个韧性指标（与原图一致）

metrics_all = [
    ('num_failed_nodes', 'Value Node Attrition', 'D'),
    ('Robustness', 'Value Sustenance Floor', 'o'),
    ('Performance_Loss', 'Cumulative Economic Cost', '^'),
    ('Recovery_Rate', 'Economic Resilience Speed', 's')
]
metrics = metrics_all if SHOW_NODE_ATTRITION else metrics_all[1:]


y_labels = {

    'num_failed_nodes': 'Failed Nodes (%)',

    'Robustness': 'Robustness (%)',

    'Performance_Loss': 'Performance Loss (%)',

    'Recovery_Rate': 'Recovery Rate (%)'

}



TOTAL_NODES = 100



# 读取所有情境的数据

all_scenario_data = {}



for scenario_name, scenario_info in scenarios.items():

    # 如果文件为None，跳过此情境

    if scenario_info['file'] is None:

        print(f"\n[SKIP] 跳过 {scenario_name} (数据文件未找?")

        continue



    file_path = results_data_dir / scenario_info['file']

    if not file_path.exists():

        print(f"\n[WARN] 文件不存? {file_path}")

        continue



    df = pd.read_csv(file_path)

    print(f"\n[OK] 加载 {scenario_name}")

    print(f"  文件: {scenario_info['file']}")

    print(f"  BED? {scenario_info['bed']:.4f}")

    print(f"  记录? {len(df)}")



    # ??ES_0???
    ES_0_MEAN = df['ES_0'].mean() if 'ES_0' in df.columns else 1.0



    # 为每个指标聚合数据并平滑

    scenario_metric_data = {}

    for col_name, display_name, marker in metrics:

        df_agg = aggregate_with_ci(df, group_cols=['num_recycling_loops'], value_col=col_name)



        # 应用单位转换（与原图一致）

        if col_name == 'num_failed_nodes':

            df_agg['mean'] = df_agg['mean'] / TOTAL_NODES * 100

            df_agg['ci_lower'] = df_agg['ci_lower'] / TOTAL_NODES * 100

            df_agg['ci_upper'] = df_agg['ci_upper'] / TOTAL_NODES * 100

        elif col_name == 'Robustness':

            df_agg['mean'] = df_agg['mean'] * 100

            df_agg['ci_lower'] = df_agg['ci_lower'] * 100

            df_agg['ci_upper'] = df_agg['ci_upper'] * 100

        elif col_name == 'Performance_Loss':

            df_agg['mean'] = (df_agg['mean'] / ES_0_MEAN / MAX_PERFORMANCE_LOSS) * 100

            df_agg['ci_lower'] = (df_agg['ci_lower'] / ES_0_MEAN / MAX_PERFORMANCE_LOSS) * 100

            df_agg['ci_upper'] = (df_agg['ci_upper'] / ES_0_MEAN / MAX_PERFORMANCE_LOSS) * 100

        elif col_name == 'Recovery_Rate':

            df_agg['mean'] = (df_agg['mean'] / ES_0_MEAN / MAX_RECOVERY_RATE) * 10000

            df_agg['ci_lower'] = (df_agg['ci_lower'] / ES_0_MEAN / MAX_RECOVERY_RATE) * 10000

            df_agg['ci_upper'] = (df_agg['ci_upper'] / ES_0_MEAN / MAX_RECOVERY_RATE) * 10000



        x_raw = df_agg['num_recycling_loops'].values
        y = df_agg['mean'].values

        unique_x = np.unique(x_raw)
        # Use quadratic fit when possible; fall back to lower degree if data are insufficient.
        degree = 2 if len(unique_x) >= 3 else max(1, len(unique_x) - 1)
        coeffs = np.polyfit(x_raw, y, deg=degree)
        x_dense = np.linspace(x_raw.min(), x_raw.max(), 200)
        y_fit = np.polyval(coeffs, x_dense)

        # Threshold where derivative of fitted curve is zero
        max_loops = scenario_info.get('max_loops') or df_agg['num_recycling_loops'].max()
        preferred_range = (0.6 * max_loops, 0.8 * max_loops)
        threshold_x_raw, threshold_y = detect_threshold_point_derivative_zero(
            coeffs, x_dense, preferred_range
        )

        threshold_x_coverage = transform_to_path_coverage(

            np.array([threshold_x_raw]), max_loops=max_loops

        )[0]



        scenario_metric_data[col_name] = {

            'df_agg': df_agg,

            'x_dense': x_dense,
            'y_fit': y_fit,

            'threshold': (threshold_x_coverage, threshold_y)  # 存储阈值点坐标

        }



    all_scenario_data[scenario_name] = scenario_metric_data



# ????
if ONE_ROW_LAYOUT:
    fig, axes = plt.subplots(3, 1, figsize=(5.5, 9.5), dpi=300)
else:
    fig, axes = plt.subplots(2, 2, figsize=(7.5, 5.5), dpi=300)
axes_flat = axes.flatten() if hasattr(axes, 'flatten') else [axes]




for idx, (col_name, display_name, marker) in enumerate(metrics):

    ax = axes_flat[idx]



    # 绘制所有情境的曲线

    for scenario_name, scenario_info in scenarios.items():

        # 如果该情境没有数据，跳过

        if scenario_name not in all_scenario_data:

            continue



        metric_data = all_scenario_data[scenario_name][col_name]

        df_plot = metric_data['df_agg']

        y_fit = metric_data['y_fit']



        # ??X?????
        max_loops = scenario_info.get('max_loops') or df_plot['num_recycling_loops'].max()
        x_plot = transform_to_path_coverage(metric_data['x_dense'], max_loops=max_loops)



        # 绘制平滑曲线

        ax.plot(

            x_plot,

            y_fit,

            color=scenario_info['color'],

            linewidth=scenario_info['linewidth'],

            linestyle=scenario_info['linestyle'],

            zorder=3,

            label=scenario_info['label']

        )



        # 阈值点不再绘制



    # 设置标签和标题（与原图一致）

    ax.set_ylabel(y_labels[col_name], fontsize=12, fontweight='bold')

    ax.set_xlabel('Path Coverage Rate (%)', fontsize=12, fontweight='bold')

    subplot_label = chr(97 + idx)

    ax.set_title(

        f'({subplot_label}) {display_name}',

        fontsize=14, fontweight='bold', loc='left'

    )



    # 网格（Nature风格?
    ax.grid(

        True,

        alpha=0.3,

        linestyle='--',

        linewidth=0.5,

        color='#BDBDBD',

        zorder=0

    )

    ax.set_axisbelow(True)  # 确保网格在数据后?

    # 增强坐标轴边框（Nature标准?
    for spine in ax.spines.values():

        spine.set_linewidth(1.2)



# 收集所有图例项（从第一个子图）

handles, labels = axes_flat[0].get_legend_handles_labels()



# ??????????????????
fig.legend(
    handles,
    labels,
    loc='lower center',
    bbox_to_anchor=(0.5, -0.08),
    ncol=1,
    frameon=True,
    framealpha=0.95,
    edgecolor='#333333',
    facecolor='white',
    fancybox=False,
    fontsize=10,
    shadow=False,
    columnspacing=1.5
)



# 调整布局，为底部两行图例留出更多空间

plt.tight_layout(rect=[0, 0.08, 1, 1])



# 保存图表

print("\n[保存图表]")



# ??PNG?????????????
png_file = figures_dir / 'path_coverage_vs_resilience_BED0.8_nature_style.png'

fig.savefig(

    png_file,

    dpi=300,

    bbox_inches='tight',

    pad_inches=0.1,

    facecolor='white',

    edgecolor='none'

)

print(f"  [OK] PNG: {png_file}")



# ??PDF?????????????
pdf_file = figures_dir / 'path_coverage_vs_resilience_BED0.8_nature_style.pdf'

fig.savefig(

    pdf_file,

    format='pdf',

    bbox_inches='tight',

    pad_inches=0.1,

    facecolor='white',

    edgecolor='none'

)

print(f"  [OK] PDF: {pdf_file}")



plt.close()



print("\n" + "=" * 80)

print("Chart updated (path coverage vs resilience)")

print(f"Curves plotted: {len(all_scenario_data)}")

print("=" * 80)

