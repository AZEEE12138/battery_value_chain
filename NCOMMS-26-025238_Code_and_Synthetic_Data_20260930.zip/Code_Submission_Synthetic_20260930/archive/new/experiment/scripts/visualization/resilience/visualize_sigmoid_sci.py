# -*- coding: utf-8 -*-
"""
SCI-style sigmoid bankruptcy probability plot.

Outputs:
  new/rusult/figure/figures/profit loss rate.jpg
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np


# Matplotlib styling (SCI-like)
matplotlib.rcParams["font.family"] = "Times New Roman"
matplotlib.rcParams["font.size"] = 11
matplotlib.rcParams["axes.labelsize"] = 12
matplotlib.rcParams["axes.titlesize"] = 13
matplotlib.rcParams["xtick.labelsize"] = 10
matplotlib.rcParams["ytick.labelsize"] = 10
matplotlib.rcParams["legend.fontsize"] = 10
matplotlib.rcParams["figure.dpi"] = 300
matplotlib.rcParams["savefig.dpi"] = 300
matplotlib.rcParams["savefig.bbox"] = "tight"
matplotlib.rcParams["axes.linewidth"] = 1.2
matplotlib.rcParams["grid.linewidth"] = 0.5
matplotlib.rcParams["lines.linewidth"] = 2.0


# Parameters aligned with current dynamic resilience experiment defaults
# (see new/experiment/experiments/run_resilience_simulation.py)
THRESHOLD = 0.50
STEEPNESS = 10.0


def sigmoid(x: np.ndarray, theta: float, k: float) -> np.ndarray:
    """Sigmoid bankruptcy probability function."""
    return 1.0 / (1.0 + np.exp(-k * (x - theta)))


def main() -> None:
    # Output path: new/rusult/figure/figures/profit loss rate.jpg
    base_dir = Path(__file__).resolve().parents[4]
    output_dir = base_dir / "rusult" / "figure" / "figures"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "profit loss rate.jpg"

    # Data
    x = np.linspace(0.0, 1.0, 1000)
    y = sigmoid(x, THRESHOLD, STEEPNESS)

    # Figure
    fig, ax = plt.subplots(figsize=(5, 3.5))
    ax.plot(x, y, "b-", linewidth=2.5, label="Bankruptcy Probability", zorder=3)

    # Key points
    key_points_x = [0.40, 0.45, 0.50, THRESHOLD, 0.55, 0.60, 0.70]
    key_points_y = sigmoid(np.array(key_points_x), THRESHOLD, STEEPNESS)
    ax.scatter(
        key_points_x,
        key_points_y,
        color="red",
        s=60,
        zorder=4,
        edgecolors="darkred",
        linewidths=1.5,
        marker="o",
    )

    # Threshold lines
    ax.axvline(
        THRESHOLD,
        color="gray",
        linestyle="--",
        linewidth=1.2,
        alpha=0.7,
        label=f"Threshold (θ = {THRESHOLD:.2f})",
    )
    ax.axhline(0.5, color="gray", linestyle="--", linewidth=1.0, alpha=0.5)

    # Critical transition zone (theta ± 0.05)
    zone_left = max(0.0, THRESHOLD - 0.05)
    zone_right = min(1.0, THRESHOLD + 0.05)
    ax.axvspan(
        zone_left,
        zone_right,
        alpha=0.15,
        color="red",
        label="Critical Transition Zone",
    )

    # Stable / high-risk zones
    ax.text(
        0.20,
        0.05,
        "Stable Zone\n(Low Risk)",
        ha="center",
        va="bottom",
        fontsize=9,
        bbox=dict(
            boxstyle="round,pad=0.5",
            facecolor="lightgreen",
            edgecolor="darkgreen",
            alpha=0.6,
            linewidth=1.5,
        ),
    )
    ax.text(
        0.86,
        0.92,
        "High Risk Zone\n(Likely Failure)",
        ha="center",
        va="top",
        fontsize=9,
        bbox=dict(
            boxstyle="round,pad=0.5",
            facecolor="lightcoral",
            edgecolor="darkred",
            alpha=0.6,
            linewidth=1.5,
        ),
    )

    # Annotations with updated probabilities
    def _p(percent: float) -> float:
        return float(sigmoid(np.array([percent]), THRESHOLD, STEEPNESS)[0])

    annotations = [
        (0.60, f"Loss 60%\nP≈{_p(0.60)*100:.0f}%", (0.55, 0.42)),
        (THRESHOLD, "Threshold\nP=50%", (THRESHOLD - 0.08, 0.68)),
        (0.75, f"Loss 75%\nP≈{_p(0.75)*100:.0f}%", (0.87, 0.72)),
    ]
    for px, label, text_pos in annotations:
        py = sigmoid(px, THRESHOLD, STEEPNESS)
        ax.annotate(
            label,
            xy=(px, py),
            xytext=text_pos,
            ha="center",
            va="bottom",
            fontsize=8,
            bbox=dict(
                boxstyle="round,pad=0.4",
                facecolor="yellow",
                edgecolor="black",
                alpha=0.8,
                linewidth=1.0,
            ),
            arrowprops=dict(
                arrowstyle="->",
                connectionstyle="arc3,rad=0.15",
                color="black",
                linewidth=1.2,
            ),
        )

    # Formula box
    formula_text = (
        r"$P(x) = \frac{1}{1 + e^{-k(x - \theta)}}$"
        + f"\nwhere k={STEEPNESS:.1f}, θ={THRESHOLD:.2f}"
    )
    ax.text(
        0.98,
        0.15,
        formula_text,
        ha="right",
        va="bottom",
        fontsize=10,
        bbox=dict(
            boxstyle="round,pad=0.6",
            facecolor="white",
            edgecolor="blue",
            alpha=0.9,
            linewidth=1.5,
        ),
        transform=ax.transAxes,
    )

    # Axis labels and title
    ax.set_xlabel("Profit Loss Rate", fontweight="bold")
    ax.set_ylabel("Bankruptcy Probability P(x)", fontweight="bold")
    ax.set_title(
        "Sigmoid Bankruptcy Probability Function\n"
        + f"(Threshold={THRESHOLD:.2f}, Steepness={STEEPNESS:.1f})",
        fontweight="bold",
        pad=15,
    )

    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    ax.grid(True, alpha=0.3, linestyle="--", linewidth=0.5)
    ax.set_axisbelow(True)
    ax.legend(loc="upper left", frameon=True, edgecolor="black", fancybox=False, fontsize=9, framealpha=0.95)
    ax.set_xticks(np.arange(0.0, 1.1, 0.1))
    ax.set_yticks(np.arange(0.0, 1.1, 0.1))

    fig.savefig(output_path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    print("=" * 80)
    print("Sigmoid bankruptcy probability plot generated.")
    print(f"Output: {output_path}")
    print(f"Parameters: threshold={THRESHOLD:.2f}, steepness={STEEPNESS:.1f}")
    print("=" * 80)


if __name__ == "__main__":
    main()
