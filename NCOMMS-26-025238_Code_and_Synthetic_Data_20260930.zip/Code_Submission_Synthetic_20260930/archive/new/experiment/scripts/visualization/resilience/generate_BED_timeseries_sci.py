"""
BED Time-Series Visualization (CSV-driven)
Historical data with Conservative and Optimistic forecast scenarios
SCI publication standards

Features:
- Load time-series from zhanbi.csv (year/optimistic/conservative)
- Expect coverage 2015-2035; warn if missing years
- Pivot year inferred from last identical optimistic/conservative value
- Red dashed lines showing forecast differences for each year
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sys
import io
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(BASE_DIR))

from src.utils.path_config import PathConfig

# UTF-8 encoding setup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# SCI standard settings
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 11
plt.rcParams['axes.linewidth'] = 1.2
plt.rcParams['xtick.major.width'] = 1.2
plt.rcParams['ytick.major.width'] = 1.2
plt.rcParams['xtick.major.size'] = 5
plt.rcParams['ytick.major.size'] = 5
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['mathtext.fontset'] = 'stix'


def prepare_bed_data():
    """
    Prepare BED time-series data with three segments from external CSV.

    Returns:
        dict with keys: 'historical', 'conservative', 'optimistic'
    """
    paths = PathConfig()
    data_path = paths.get_input_file('zhanbi.csv')

    df = pd.read_csv(data_path, sep='\t', encoding='utf-8-sig')
    if df.shape[1] < 3:
        raise ValueError(f"Unexpected columns in {data_path}: {df.columns.tolist()}")

    explicit_cols = {'年份': 'year', '乐观情景占比（%）': 'optimistic', '保守情景占比（%）': 'conservative'}
    if set(explicit_cols.keys()).issubset(df.columns):
        df = df.rename(columns=explicit_cols)
    else:
        col_year, col_opt, col_cons = df.columns[:3]
        df = df.rename(columns={
            col_year: 'year',
            col_opt: 'optimistic',
            col_cons: 'conservative'
        })

    if not {'year', 'optimistic', 'conservative'}.issubset(df.columns):
        raise ValueError(f"Unexpected columns in {data_path}: {df.columns.tolist()}")

    df['year'] = pd.to_numeric(df['year'], errors='coerce')
    df['optimistic'] = pd.to_numeric(df['optimistic'], errors='coerce')
    df['conservative'] = pd.to_numeric(df['conservative'], errors='coerce')
    df = df.dropna(subset=['year', 'optimistic', 'conservative'])
    df['year'] = df['year'].astype(int)
    df = df.sort_values('year').reset_index(drop=True)

    years = df['year'].to_numpy()
    bed_opt = df['optimistic'].to_numpy(dtype=float)
    bed_cons = df['conservative'].to_numpy(dtype=float)

    # Coverage check for 2015-2035
    expected_years = np.arange(2015, 2036, dtype=int)
    missing_years = sorted(set(expected_years) - set(years))
    extra_years = sorted(set(years) - set(expected_years))
    if missing_years:
        print(f"\n[Warning] Missing years in zhanbi.csv: {missing_years}")
    if extra_years:
        print(f"\n[Info] Extra years in zhanbi.csv: {extra_years}")

    # Determine pivot year where scenarios are still identical
    equal_mask = (abs(bed_opt - bed_cons) <= 1e-6)
    if equal_mask.any():
        pivot_year = int(years[equal_mask][-1])
    else:
        pivot_year = int(years[0])

    # Ensure continuity at pivot year
    pivot_idx = (years == pivot_year).nonzero()[0]
    if pivot_idx.size:
        pivot_idx = int(pivot_idx[0])
        pivot_value = float((bed_opt[pivot_idx] + bed_cons[pivot_idx]) / 2.0)
        bed_opt[pivot_idx] = pivot_value
        bed_cons[pivot_idx] = pivot_value
    else:
        pivot_value = float((bed_opt[0] + bed_cons[0]) / 2.0)

    # Historical segment: all years up to pivot (use optimistic column; same as conservative here)
    hist_mask = years <= pivot_year
    years_hist = years[hist_mask]
    bed_hist = bed_opt[hist_mask]

    # Scenario segments: from pivot year onward
    scen_mask = years >= pivot_year
    years_cons = years[scen_mask]
    years_opt = years[scen_mask]
    bed_cons_seg = bed_cons[scen_mask]
    bed_opt_seg = bed_opt[scen_mask]

    print(f"\n[Pivot Year Selection]")
    print(f"  Pivot year: {pivot_year}")
    print(f"  Pivot value: {pivot_value:.2f}%")
    print(f"  Data range: {int(years.min())}-{int(years.max())}")

    return {
        'historical': {'years': years_hist, 'bed': bed_hist},
        'conservative': {'years': years_cons, 'bed': bed_cons_seg},
        'optimistic': {'years': years_opt, 'bed': bed_opt_seg}
    }


def validate_data_continuity(data):
    """
    Validate that all three lines meet at pivot year with same value.
    """
    hist_pivot = data['historical']['bed'][-1]
    cons_pivot = data['conservative']['bed'][0]
    opt_pivot = data['optimistic']['bed'][0]
    pivot_year = int(data['historical']['years'][-1])

    print(f"\n[Continuity Validation]")
    print(f"  Historical at {pivot_year}: {hist_pivot:.2f}%")
    print(f"  Conservative at {pivot_year}: {cons_pivot:.2f}%")
    print(f"  Optimistic at {pivot_year}: {opt_pivot:.2f}%")

    # Check convergence
    assert abs(hist_pivot - cons_pivot) < 0.01, "Discontinuity detected!"
    assert abs(hist_pivot - opt_pivot) < 0.01, "Discontinuity detected!"
    print("  [OK] All lines converge at pivot year")

    # Validate lengths
    assert len(data['historical']['years']) >= 2
    assert len(data['conservative']['years']) >= 2
    assert len(data['optimistic']['years']) >= 2
    print("  [OK] Segments have sufficient data points")


def plot_bed_timeseries(ax, data):
    """
    Plot three BED time-series lines.
    """
    print(f"\n[Plotting Main Lines]")

    hist_years = data['historical']['years']
    hist_label = f"Historical data ({int(hist_years[0])}-{int(hist_years[-1])})"

    # Define line specifications
    line_specs = {
        'historical': {
            'color': '#424242',
            'linestyle': '-',
            'linewidth': 2.5,
            'marker': 'o',
            'markersize': 6,
            'markeredgecolor': 'white',
            'markeredgewidth': 0.5,
            'label': hist_label,
            'alpha': 0.95,
            'zorder': 4
        },
        'conservative': {
            'color': '#1976D2',
            'linestyle': '-',
            'linewidth': 2.0,
            'marker': 's',
            'markersize': 5,
            'markeredgecolor': 'white',
            'markeredgewidth': 0.5,
            'label': 'Conservative scenario',
            'alpha': 0.85,
            'zorder': 3
        },
        'optimistic': {
            'color': '#D32F2F',
            'linestyle': '-',
            'linewidth': 2.0,
            'marker': '^',
            'markersize': 5,
            'markeredgecolor': 'white',
            'markeredgewidth': 0.5,
            'label': 'Optimistic scenario',
            'alpha': 0.85,
            'zorder': 3
        }
    }

    # Plot historical
    ax.plot(data['historical']['years'],
           data['historical']['bed'],
           **line_specs['historical'])
    print("  [OK] Historical line")

    # Plot conservative
    ax.plot(data['conservative']['years'],
           data['conservative']['bed'],
           **line_specs['conservative'])
    print("  [OK] Conservative scenario")

    # Plot optimistic
    ax.plot(data['optimistic']['years'],
           data['optimistic']['bed'],
           **line_specs['optimistic'])
    print("  [OK] Optimistic scenario")

    # Highlight pivot point
    bed_pivot = data['historical']['bed'][-1]
    pivot_year = int(data['historical']['years'][-1])
    ax.scatter(pivot_year, bed_pivot, s=150, color='gold',
              edgecolors='#424242', linewidths=2.0,
              zorder=5, marker='*', alpha=0.9)
    print("  [OK] Pivot point marker")


def add_forecast_differences(ax, data):
    """
    Add red dashed lines showing forecast differences for each year after pivot.
    """
    print(f"\n[Adding Forecast Difference Annotations]")

    years_cons = data['conservative']['years']
    bed_cons = data['conservative']['bed']
    bed_opt = data['optimistic']['bed']

    # For each forecast year after pivot
    for i in range(1, len(years_cons)):
        year = years_cons[i]
        cons_value = bed_cons[i]
        opt_value = bed_opt[i]
        diff = abs(cons_value - opt_value)

        # Draw red dashed line connecting the two scenarios
        ax.plot([year, year], [cons_value, opt_value],
               color='#D32F2F',
               linestyle='--',
               linewidth=1.2,
               alpha=0.7,
               zorder=2)

        # Optional: Add difference text annotation (last year only to avoid clutter)
        if year == years_cons[-1]:
            mid_y = (cons_value + opt_value) / 2
            ax.text(year + 0.3, mid_y, f'{diff:.1f}%',
                   fontsize=8,
                   ha='left',
                   va='center',
                   color='#D32F2F',
                   bbox=dict(boxstyle='round,pad=0.2',
                            facecolor='white',
                            edgecolor='#D32F2F',
                            alpha=0.9,
                            linewidth=0.8))

    print("  [OK] Added dashed lines for forecast years")
    print("  [OK] Added text annotations for last two years")


def configure_axes(ax, data):
    """
    Configure X and Y axes.
    """
    print(f"\n[Configuring Axes]")

    # X-axis
    ax.set_xlabel('Year', fontsize=12, fontweight='bold')

    all_years = np.concatenate([
        data['historical']['years'],
        data['conservative']['years'],
        data['optimistic']['years']
    ])
    year_min = int(all_years.min())
    year_max = int(all_years.max())

    ax.set_xlim(year_min - 1, year_max + 1)

    # Major ticks every 5 years within data range
    tick_start = year_min - (year_min % 5)
    major_ticks = np.arange(tick_start, year_max + 1, 5, dtype=int)
    ax.set_xticks(major_ticks)

    # Add vertical line at pivot year to mark transition
    pivot_year = int(data['historical']['years'][-1])
    ax.axvline(x=pivot_year, color='#757575', linestyle='--',
              linewidth=1.5, alpha=0.6, zorder=2)
    print(f"  [OK] X-axis configured ({year_min}-{year_max}, 5-year intervals)")
    print(f"  [OK] Pivot year line added at {pivot_year}")

    # Y-axis
    ax.set_ylabel('Battery-EV dependency (BED) [%]',
                 fontsize=12, fontweight='bold')

    # Determine range with 5% padding
    all_bed = np.concatenate([
        data['historical']['bed'],
        data['conservative']['bed'],
        data['optimistic']['bed']
    ])
    bed_min = all_bed.min()
    bed_max = all_bed.max()
    y_range = bed_max - bed_min
    y_padding = 0.05 * y_range if y_range > 0 else 1.0

    ax.set_ylim(bed_min - y_padding, bed_max + y_padding)

    # Ticks every 10%
    y_ticks = np.arange(30, 91, 10)
    ax.set_yticks(y_ticks)
    ax.set_yticklabels([f'{y}%' for y in y_ticks])
    print("  [OK] Y-axis configured (30%-90%, 10% intervals)")


def print_summary_statistics(data):
    """
    Print comprehensive data summary.
    """
    print("\n" + "=" * 80)
    print("DATA SUMMARY")
    print("=" * 80)

    # Historical segment
    hist = data['historical']
    hist_years = hist['years']
    hist_change = hist['bed'][-1] - hist['bed'][0]
    hist_span = int(hist_years[-1] - hist_years[0]) or 1
    hist_annual = hist_change / hist_span

    print(f"\n[Historical Data {int(hist_years[0])}-{int(hist_years[-1])}]")
    print(f"  BED range: {hist['bed'].min():.2f}% to {hist['bed'].max():.2f}%")
    print(f"  Total change: {hist_change:+.2f}%")
    print(f"  Avg annual change: {hist_annual:+.2f}%/year")

    # Conservative scenario
    cons = data['conservative']
    cons_years = cons['years']
    cons_change = cons['bed'][-1] - cons['bed'][0]
    cons_span = int(cons_years[-1] - cons_years[0]) or 1
    cons_annual = cons_change / cons_span

    print(f"\n[Conservative Scenario {int(cons_years[0])}-{int(cons_years[-1])}]")
    print(f"  BED range: {cons['bed'][0]:.2f}% to {cons['bed'][-1]:.2f}%")
    print(f"  Total change: {cons_change:+.2f}%")
    print(f"  Avg annual change: {cons_annual:+.2f}%/year")

    # Optimistic scenario
    opt = data['optimistic']
    opt_years = opt['years']
    opt_change = opt['bed'][-1] - opt['bed'][0]
    opt_span = int(opt_years[-1] - opt_years[0]) or 1
    opt_annual = opt_change / opt_span

    print(f"\n[Optimistic Scenario {int(opt_years[0])}-{int(opt_years[-1])}]")
    print(f"  BED range: {opt['bed'][0]:.2f}% to {opt['bed'][-1]:.2f}%")
    print(f"  Total change: {opt_change:+.2f}%")
    print(f"  Avg annual change: {opt_annual:+.2f}%/year")

    # Pivot point
    pivot_year = int(hist_years[-1])
    print(f"\n[Pivot Point]")
    print(f"  Year: {pivot_year}")
    print(f"  Value: {hist['bed'][-1]:.2f}%")

    # Forecast spread
    spread_last = cons['bed'][-1] - opt['bed'][-1]
    print(f"\n[Last-Year Forecast Spread]")
    print(f"  Conservative: {cons['bed'][-1]:.2f}%")
    print(f"  Optimistic: {opt['bed'][-1]:.2f}%")
    print(f"  Spread: {abs(spread_last):.2f}%")

    # Yearly differences
    print(f"\n[Forecast Differences by Year]")
    print(f"  {'Year':<6} {'Conservative':<14} {'Optimistic':<14} {'Difference':<10}")
    print(f"  {'-'*48}")
    for i in range(1, len(cons_years)):
        year = int(cons_years[i])
        cons_val = cons['bed'][i]
        opt_val = opt['bed'][i]
        diff = abs(cons_val - opt_val)
        print(f"  {year:<6} {cons_val:<14.2f}% {opt_val:<14.2f}% {diff:<10.2f}%")


def main():
    print("=" * 80)
    print("BED Time-Series Visualization (CSV-driven)")
    print("Historical + Conservative + Optimistic Scenarios")
    print("=" * 80)

    # 1. Prepare data
    data = prepare_bed_data()

    # 2. Validate continuity
    validate_data_continuity(data)

    # 3. Create figure
    fig, ax = plt.subplots(figsize=(7.5, 5.5), dpi=300)

    # 4. Plot main lines
    plot_bed_timeseries(ax, data)

    # 5. Add forecast difference annotations
    add_forecast_differences(ax, data)

    # 6. Configure axes
    configure_axes(ax, data)

    # 7. Add grid
    ax.grid(True, linestyle=':', linewidth=0.6,
           color='#BDBDBD', alpha=0.6, zorder=1)
    ax.set_axisbelow(True)
    print(f"\n[Grid]")
    print(f"  ✓ Grid added (dotted, gray)")

    # 8. Add legend
    ax.legend(loc='upper left', fontsize=11, frameon=True,
             framealpha=0.95, edgecolor='#424242', fancybox=False)
    print(f"\n[Legend]")
    print(f"  ✓ Legend added (upper left)")

    # 9. Save outputs
    plt.tight_layout()

    paths = PathConfig()
    output_dir = paths.results_figures_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    output_png = output_dir / 'BED_timeseries_sci.png'
    output_pdf = output_dir / 'BED_timeseries_sci.pdf'

    plt.savefig(output_png, dpi=300, bbox_inches='tight',
               facecolor='white', edgecolor='none')
    print(f"\n[PNG saved]: {output_png}")

    plt.savefig(output_pdf, format='pdf', bbox_inches='tight',
               facecolor='white', edgecolor='none')
    print(f"[PDF saved]: {output_pdf}")

    plt.close()

    # 10. Print summary
    print_summary_statistics(data)

    print("\n" + "=" * 80)
    print("BED Time-Series Visualization Complete!")
    print("=" * 80)


if __name__ == '__main__':
    main()
