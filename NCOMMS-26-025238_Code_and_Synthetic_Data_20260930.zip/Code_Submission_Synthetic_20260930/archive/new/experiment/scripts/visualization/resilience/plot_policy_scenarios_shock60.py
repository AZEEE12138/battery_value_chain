# -*- coding: utf-8 -*-
"""
Plot four policy scenario curves at a fixed shock intensity (default 60%).
X/Y axes follow combined_resilience_analysis_2x4.png definitions.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, Tuple

import matplotlib.pyplot as plt
import pandas as pd

THIS_DIR = Path(__file__).resolve().parent
PROJECT_DIR = THIS_DIR.parent.parent.parent
sys.path.insert(0, str(PROJECT_DIR))

from src.utils.path_config import PathConfig
from scripts.visualization.resilience.visualize_combined_resilience_analysis import (
    SMOOTH_FRAC,
    _normalize_values,
    _fit_quadratic_and_smooth,
)


METRICS = [
    ("failed_nodes_shock", "Value Node Attrition", "Failed Nodes (%)"),
    ("Robustness", "Value Sustenance Floor", "Robustness (%)"),
    ("Performance_Loss", "Cumulative Economic Cost", "Performance Loss (%)"),
    ("Recovery_Rate", "Economic Resilience Speed", "Recovery Rate (%)"),
]


def _load_df(path: Path, shock_intensity: float) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "shock_intensity" in df.columns:
        df = df[df["shock_intensity"] == shock_intensity].copy()
    return df


def _plot_curve(ax, df: pd.DataFrame, metric: str, label: str, color: str) -> None:
    if df.empty:
        return
    es0_mean = df["ES_0"].mean() if "ES_0" in df.columns else 1.0
    x = df["BED_target"].values
    y_raw = df[metric].values
    y = _normalize_values(y_raw, metric, es0_mean)

    x_dense, y_smooth = _fit_quadratic_and_smooth(x, y, frac=SMOOTH_FRAC.get(metric, 0.25))
    ax.plot(x_dense, y_smooth, color=color, linewidth=2.0, label=label)


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot policy scenarios at shock 60%.")
    parser.add_argument("--shock-intensity", type=float, default=0.6)
    parser.add_argument("--baseline-csv", type=str, default="")
    parser.add_argument("--supply-csv", type=str, default="")
    parser.add_argument("--buffer-csv", type=str, default="")
    parser.add_argument("--combined-csv", type=str, default="")
    parser.add_argument("--output-name", type=str, default="policy_scenarios_shock60_4curves")
    args = parser.parse_args()

    paths = PathConfig()
    results_dir = paths.results_data_dir
    figs_dir = paths.results_figures_dir

    baseline_csv = Path(args.baseline_csv) if args.baseline_csv else results_dir / f"policy_scenario_baseline_shock{int(args.shock_intensity*100)}.csv"
    supply_csv = Path(args.supply_csv) if args.supply_csv else results_dir / f"policy_scenario_supply_stability_shock{int(args.shock_intensity*100)}.csv"
    buffer_csv = Path(args.buffer_csv) if args.buffer_csv else results_dir / f"policy_scenario_inventory_buffer_shock{int(args.shock_intensity*100)}.csv"
    combined_csv = Path(args.combined_csv) if args.combined_csv else results_dir / f"policy_scenario_combined_shock{int(args.shock_intensity*100)}.csv"

    scenario_files: Dict[str, Tuple[Path, str]] = {
        "Baseline": (baseline_csv, "#333333"),
        "Supply Stability": (supply_csv, "#1f77b4"),
        "Inventory Buffer": (buffer_csv, "#ff7f0e"),
        "Combined": (combined_csv, "#2ca02c"),
    }

    scenario_data = {
        name: _load_df(path, args.shock_intensity) for name, (path, _) in scenario_files.items()
    }

    fig, axes = plt.subplots(1, 4, figsize=(13, 3.6), sharex=True)

    for idx, (metric, title, y_label) in enumerate(METRICS):
        ax = axes[idx]
        for name, (path, color) in scenario_files.items():
            _plot_curve(ax, scenario_data[name], metric, name, color)
        ax.set_title(title)
        ax.set_xlabel("BED")
        ax.set_ylabel(y_label)
        ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.5)

    axes[0].legend(frameon=True, fontsize=9)

    figs_dir.mkdir(parents=True, exist_ok=True)
    out_png = figs_dir / f"{args.output_name}.png"
    out_pdf = figs_dir / f"{args.output_name}.pdf"
    fig.tight_layout()
    fig.savefig(out_png, dpi=300)
    fig.savefig(out_pdf, dpi=300)
    print(f"[saved] {out_png}")
    print(f"[saved] {out_pdf}")


if __name__ == "__main__":
    main()
