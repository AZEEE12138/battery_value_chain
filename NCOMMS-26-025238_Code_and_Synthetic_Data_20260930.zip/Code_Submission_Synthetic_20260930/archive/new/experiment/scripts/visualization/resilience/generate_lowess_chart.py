"""重新生成 LOWESS 平滑的 num_loops 韧性图表"""
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(BASE_DIR))

import pandas as pd
from src.vis.recycling_policy_plots_smooth_thresholds import plot_smooth_resilience_with_thresholds
from src.utils.path_config import PathConfig

print("=" * 70)
print("重新生成 num_loops LOWESS 韧性图表")
print("=" * 70)

# 数据文件路径 - 使用最新的统一Robustness数据文件
paths = PathConfig()
target_bed = 0.8
result_files = sorted(paths.results_data_dir.glob('recycling_num_loops_experiment_v2_*.csv'),
                      key=lambda p: p.stat().st_mtime, reverse=True)
csv_file = None
for f in result_files:
    try:
        df_check = pd.read_csv(f, nrows=1)
        if 'BED_target' in df_check.columns and abs(float(df_check['BED_target'].iloc[0]) - target_bed) < 0.001:
            csv_file = f
            break
    except Exception:
        continue
if csv_file is None and result_files:
    csv_file = result_files[0]
output_dir = paths.results_figures_dir
output_dir.mkdir(exist_ok=True, parents=True)

print(f"\n[1] 读取数据文件...")
print(f"    文件: {csv_file}")

if csv_file is None or not csv_file.exists():
    print(f"    [ERROR] 未找到实验结果文件")
    sys.exit(1)

try:
    df = pd.read_csv(csv_file)
    print(f"    [OK] 成功读取 {len(df)} 行数据")

    # 验证必需列
    required_cols = ['num_failed_nodes', 'ES_0', 'Robustness', 'Performance_Loss',
                     'Recovery_Rate', 'BED_target', 'num_recycling_loops']
    print(f"\n[2] 验证数据列...")
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        print(f"    [ERROR] 缺失列: {missing_cols}")
        sys.exit(1)
    else:
        print(f"    [OK] 所有必需列存在")

    # 显示BED筛选信息
    bed_values = df['BED_target'].unique()
    print(f"\n[3] 数据筛选信息...")
    print(f"    BED目标值: {sorted(bed_values)}")
    df_filtered = df[df['BED_target'] == target_bed]
    print(f"    BED={target_bed}的数据行数: {len(df_filtered)}")

    if len(df_filtered) == 0:
        print(f"    [ERROR] 没有BED={target_bed}的数据!")
        sys.exit(1)

    # 显示ES_0统计信息
    if 'ES_0' in df_filtered.columns:
        es0_mean = df_filtered['ES_0'].mean()
        es0_std = df_filtered['ES_0'].std()
        print(f"\n[4] ES_0归一化参数...")
        print(f"    ES_0平均值: {es0_mean:.2f}")
        print(f"    ES_0标准差: {es0_std:.2f}")

    # 调用绘图函数 - 使用B-SPLINE平滑
    print(f"\n[5] 生成B-SPLINE平滑图表...")
    print(f"    平滑方法: B-SPLINE")
    print(f"    目标BED: {target_bed}")
    print(f"    输出目录: {output_dir}")

    fig, axes = plot_smooth_resilience_with_thresholds(
        df=df,
        output_dir=output_dir,
        show_plot=False,
        target_bed=target_bed,
        smooth_method='bspline'  # 使用B-Spline插值平滑
    )

    # 验证输出文件
    output_file = output_dir / f'path_coverage_vs_resilience_BED{target_bed:.1f}_smooth_bspline_thresholds.png'

    print(f"\n[6] 验证输出...")
    if output_file.exists():
        file_size = output_file.stat().st_size / 1024
        print(f"    [OK] 图表生成成功!")
        print(f"    文件: {output_file}")
        print(f"    大小: {file_size:.1f} KB")

        # 检查修改时间
        import time
        mod_time = output_file.stat().st_mtime
        mod_time_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(mod_time))
        print(f"    修改时间: {mod_time_str}")
    else:
        print(f"    [ERROR] 输出文件未找到: {output_file}")
        sys.exit(1)

    print("\n" + "=" * 70)
    print("[SUCCESS] B-SPLINE图表生成完成!")
    print("=" * 70)

    print("\n预期图表内容 (理论最大值归一化 + B-Spline平滑):")
    print("  (a) 左上: Value Node Attrition - Failed Nodes (%)")
    print("  (b) 右上: Value Sustenance Floor - Robustness (%)")
    print("  (c) 左下: Cumulative Economic Cost - Performance Loss (%) - 归一化至51.0×ES_0")
    print("  (d) 右下: Economic Resilience Speed - Recovery Rate (%) - 归一化至2.2222%ES_0/步")
    max_loops = int(df_filtered['num_recycling_loops'].max())
    print(f"  X轴: Path Coverage Rate (%) - num_recycling_loops / {max_loops} × 100%")
    print("  平滑: B-Spline插值（300点，超平滑）")
    print("  阈值点: 橙色圆点标记（黑边框）")
    print("\n优化完成：")
    print("  ✓ 删除了原始数据点和置信区间带")
    print("  ✓ 使用B-Spline插值实现超平滑曲线")
    print("  ✓ 添加了阈值点的圆形标记")
    print("\n请打开图表文件验证效果。")

except FileNotFoundError as e:
    print(f"\n[ERROR] 文件未找到")
    print(f"   {e}")
    sys.exit(1)

except Exception as e:
    print(f"\n[ERROR] {type(e).__name__}")
    print(f"   {e}")
    import traceback
    print("\n详细错误信息:")
    traceback.print_exc()
    sys.exit(1)
