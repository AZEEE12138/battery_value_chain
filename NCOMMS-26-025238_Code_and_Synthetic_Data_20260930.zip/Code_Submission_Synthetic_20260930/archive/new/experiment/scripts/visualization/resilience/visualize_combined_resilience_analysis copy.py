﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Combined resilience analysis (2x4).

Row 1: BED sensitivity curves across shock intensities (mean + 95% CI).
Row 2: Scenario comparison by year for conservative vs optimistic BED paths.

Outputs:
- combined_resilience_analysis_2x4.png
- combined_resilience_analysis_2x4.pdf
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
from matplotlib import gridspec
from matplotlib.lines import Line2D
from scipy import stats
from scipy.interpolate import make_interp_spline, interp1d


# Ensure project root is on sys.path when running standalone
THIS_DIR = Path(__file__).resolve().parent
PROJECT_DIR = THIS_DIR.parent.parent.parent
sys.path.insert(0, str(PROJECT_DIR))

from src.utils.path_config import PathConfig


# Nature Communications-like style
matplotlib.rcParams['font.family'] = 'Arial'
matplotlib.rcParams['font.size'] = 11
matplotlib.rcParams['axes.labelsize'] = 12
matplotlib.rcParams['axes.titlesize'] = 14
matplotlib.rcParams['xtick.labelsize'] = 10
matplotlib.rcParams['ytick.labelsize'] = 10
matplotlib.rcParams['legend.fontsize'] = 10
matplotlib.rcParams['figure.dpi'] = 300
matplotlib.rcParams['savefig.dpi'] = 300
matplotlib.rcParams['savefig.bbox'] = 'tight'
matplotlib.rcParams['savefig.pad_inches'] = 0.1
matplotlib.rcParams['savefig.facecolor'] = 'white'
matplotlib.rcParams['savefig.edgecolor'] = 'none'
matplotlib.rcParams['axes.linewidth'] = 1.2
matplotlib.rcParams['lines.linewidth'] = 2.0
matplotlib.rcParams['grid.linewidth'] = 0.5
matplotlib.rcParams['legend.frameon'] = True
matplotlib.rcParams['legend.framealpha'] = 0.95
matplotlib.rcParams['legend.edgecolor'] = '#333333'
matplotlib.rcParams['legend.fancybox'] = False
matplotlib.rcParams['xtick.major.width'] = 1.2
matplotlib.rcParams['ytick.major.width'] = 1.2
matplotlib.rcParams['xtick.major.size'] = 5
matplotlib.rcParams['ytick.major.size'] = 5
matplotlib.rcParams['xtick.direction'] = 'in'
matplotlib.rcParams['ytick.direction'] = 'in'


# Normalization constants
TOTAL_NODES = 100
TOTAL_STEPS = 50
RECOVERY_STEPS = 45
MAX_PERFORMANCE_LOSS = TOTAL_STEPS + 1
MAX_RECOVERY_RATE = (1.0 / RECOVERY_STEPS) * 100


# Warning thresholds (normalized to percent scale for plotting)
WARNING_THRESHOLDS = {
    'failed_nodes_pct': 50.0,
    'robustness_pct': 50.0,
    'performance_loss_pct': (20.0 / MAX_PERFORMANCE_LOSS) * 100.0,
}


# Shock colors (sampled from standard/33444266607798430.jpg)
SHOCK_COLORS = {
    0.4: '#7ECAA3',  # green
    0.6: '#FBDA83',  # yellow
    0.8: '#DC5143',  # red
}

SHOCK_LABELS = {
    0.4: 'Shock 40%',
    0.6: 'Shock 60%',
    0.8: 'Shock 80%'
}

SCENARIO_STYLES = {
    'conservative': {'linestyle': '-', 'marker': 's'},
    'optimistic': {'linestyle': '--', 'marker': 'o'},
}

# Smoothing strength (LOWESS window fraction) by metric
SMOOTH_FRAC = {
    'failed_nodes_shock': 0.25,
    'Robustness': 0.25,
    'Performance_Loss': 0.30,
    'Recovery_Rate': 0.25,
}


def _aggregate_with_ci(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Group by BED_target and compute mean and 95% CI."""
    grouped = df.groupby('BED_target')[col].agg(['mean', 'std', 'count']).reset_index()

    def _ci(row):
        if row['count'] <= 1 or np.isnan(row['std']):
            return 0.0
        t_val = stats.t.ppf(0.975, row['count'] - 1)
        return t_val * row['std'] / np.sqrt(row['count'])

    grouped['ci'] = grouped.apply(_ci, axis=1)
    grouped['ci_lower'] = grouped['mean'] - grouped['ci']
    grouped['ci_upper'] = grouped['mean'] + grouped['ci']
    grouped = grouped.sort_values('BED_target')
    return grouped


def _normalize_grouped(df: pd.DataFrame, metric: str, es0_mean: float) -> pd.DataFrame:
    """Normalize metric to percent scale for plotting."""
    df = df.copy()
    cols = ['mean', 'ci_lower', 'ci_upper']

    if metric == 'failed_nodes_shock':
        for c in cols:
            df[c] = df[c] / TOTAL_NODES * 100.0
    elif metric == 'Robustness':
        for c in cols:
            df[c] = df[c] * 100.0
    elif metric == 'Performance_Loss':
        for c in cols:
            df[c] = (df[c] / es0_mean / MAX_PERFORMANCE_LOSS) * 100.0
    elif metric == 'Recovery_Rate':
        for c in cols:
            df[c] = (df[c] / es0_mean / MAX_RECOVERY_RATE) * 10000.0

    return df


def _smooth_lowess(x: np.ndarray, y: np.ndarray, frac: float = 0.15) -> np.ndarray:
    """Lightweight LOWESS-like smoothing."""
    order = np.argsort(x)
    x_sorted = x[order]
    y_sorted = y[order]

    n = len(x_sorted)
    window = max(int(frac * n), 5)
    y_smooth = np.zeros(n)

    for i in range(n):
        left = max(0, i - window // 2)
        right = min(n, left + window)
        left = max(0, right - window)

        x_window = x_sorted[left:right]
        y_window = y_sorted[left:right]

        distances = np.abs(x_window - x_sorted[i])
        max_dist = np.max(distances) + 1e-10
        weights = np.exp(-(distances / max_dist) ** 2)

        if len(x_window) >= 2:
            A = np.vstack([x_window, np.ones(len(x_window))]).T
            W = np.diag(weights)
            coeffs = np.linalg.lstsq(W @ A, W @ y_window, rcond=None)[0]
            y_smooth[i] = coeffs[0] * x_sorted[i] + coeffs[1]
        else:
            y_smooth[i] = y_sorted[i]

    # Restore original order
    y_out = np.zeros(n)
    y_out[order] = y_smooth
    return y_out


def _smooth_and_interpolate(
    x: np.ndarray,
    y: np.ndarray,
    frac: float = 0.15,
    num_points: int = 300,
    x_dense: np.ndarray | None = None
) -> Tuple[np.ndarray, np.ndarray]:
    """Smooth with LOWESS then interpolate with cubic spline."""
    order = np.argsort(x)
    x_sorted = x[order]
    y_sorted = y[order]

    y_lowess = _smooth_lowess(x_sorted, y_sorted, frac=frac)

    if x_dense is None:
        if len(x_sorted) >= 4:
            x_dense = np.linspace(x_sorted.min(), x_sorted.max(), num_points)
        else:
            x_dense = x_sorted

    if len(x_sorted) >= 4:
        spline = make_interp_spline(x_sorted, y_lowess, k=3)
        y_dense = spline(x_dense)
    else:
        y_dense = np.interp(x_dense, x_sorted, y_lowess)

    return x_dense, y_dense


def get_bed_scenarios() -> Dict[str, np.ndarray]:
    """BED scenarios for 2026-2035 (percent values)."""
    years = np.array([2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035])
    bed_conservative = np.array([63.5, 63.4, 62.7, 61.9, 61.2, 60.6, 59.9, 59.3, 58.7, 58.1])
    bed_optimistic = np.array([56.5, 53.1, 50.0, 47.5, 45.7, 44.8, 44.5, 44.2, 44.1, 44.0])

    return {
        'years': years,
        'conservative': bed_conservative,
        'optimistic': bed_optimistic,
    }


def interpolate_metrics(
    results_df: pd.DataFrame,
    bed_values: np.ndarray,
    shock_intensity: float
) -> Dict[str, np.ndarray]:
    """Interpolate metrics for given BED values (percent) using smoothed curves."""
    df_filtered = results_df[results_df['shock_intensity'] == shock_intensity].copy()
    es0_mean = df_filtered['ES_0'].mean() if 'ES_0' in df_filtered.columns else 1.0

    grouped = df_filtered.groupby('BED_target').agg({
        'failed_nodes_shock': 'mean',
        'Robustness': 'mean',
        'Recovery_Rate': 'mean',
        'Performance_Loss': 'mean'
    }).reset_index().sort_values('BED_target')

    bed_norm = bed_values / 100.0

    metrics: Dict[str, np.ndarray] = {}
    for col in ['failed_nodes_shock', 'Robustness', 'Recovery_Rate', 'Performance_Loss']:
        x = grouped['BED_target'].values
        y = grouped[col].values

        # Normalize to plotting scale before smoothing
        if col == 'failed_nodes_shock':
            y = y / TOTAL_NODES * 100.0
        elif col == 'Robustness':
            y = y * 100.0
        elif col == 'Performance_Loss':
            y = (y / es0_mean / MAX_PERFORMANCE_LOSS) * 100.0
        elif col == 'Recovery_Rate':
            y = (y / es0_mean / MAX_RECOVERY_RATE) * 10000.0

        # Smooth then sample on scenario BED values
        x_dense, y_dense = _smooth_and_interpolate(x, y, frac=SMOOTH_FRAC.get(col, 0.25))
        metrics[col] = np.interp(bed_norm, x_dense, y_dense)

    return metrics


def plot_combined_resilience_analysis(
    results_df: pd.DataFrame,
    output_dir: str,
    shock_intensities: List[float] | None = None
) -> Tuple[Path, Path]:
    """Generate the 2x4 combined resilience analysis chart."""
    if shock_intensities is None:
        shock_intensities = sorted(results_df['shock_intensity'].unique())

    # Ensure deterministic order
    shock_intensities = [s for s in [0.4, 0.6, 0.8] if s in shock_intensities] + [
        s for s in shock_intensities if s not in [0.4, 0.6, 0.8]
    ]

    fig = plt.figure(figsize=(15, 7))
    gs = gridspec.GridSpec(2, 4, figure=fig, hspace=0.45, wspace=0.30)

    metrics = [
        ('failed_nodes_shock', 'Value Node Attrition', 'Failed Nodes (%)'),
        ('Robustness', 'Value Sustenance Floor', 'Robustness (%)'),
        ('Performance_Loss', 'Cumulative Economic Cost', 'Performance Loss (%)'),
        ('Recovery_Rate', 'Economic Resilience Speed', 'Recovery Rate (%)'),
    ]

    # Row 1: BED sensitivity curves
    for idx, (metric, title, y_label) in enumerate(metrics):
        ax = fig.add_subplot(gs[0, idx])

        for intensity in shock_intensities:
            df_shock = results_df[results_df['shock_intensity'] == intensity]
            if df_shock.empty:
                continue

            es0_mean = df_shock['ES_0'].mean() if 'ES_0' in df_shock.columns else 1.0
            grouped = _aggregate_with_ci(df_shock, metric)
            grouped = _normalize_grouped(grouped, metric, es0_mean)

            x = grouped['BED_target'].values
            y = grouped['mean'].values
            y_low = grouped['ci_lower'].values
            y_high = grouped['ci_upper'].values

            x_dense, y_dense = _smooth_and_interpolate(x, y, frac=SMOOTH_FRAC[metric])
            _, y_low_dense = _smooth_and_interpolate(x, y_low, frac=SMOOTH_FRAC[metric], x_dense=x_dense)
            _, y_high_dense = _smooth_and_interpolate(x, y_high, frac=SMOOTH_FRAC[metric], x_dense=x_dense)

            ax.fill_between(
                x_dense,
                y_low_dense,
                y_high_dense,
                color=SHOCK_COLORS.get(intensity, '#666666'),
                alpha=0.15,
                zorder=1
            )
            ax.plot(
                x_dense,
                y_dense,
                color=SHOCK_COLORS.get(intensity, '#666666'),
                linewidth=2.0,
                zorder=3
            )

        # Warning lines on (a)(b)(c)
        if metric == 'failed_nodes_shock':
            ax.axhline(
                y=WARNING_THRESHOLDS['failed_nodes_pct'],
                color='red', linestyle='--', linewidth=1.5, alpha=0.7
            )
        elif metric == 'Robustness':
            ax.axhline(
                y=WARNING_THRESHOLDS['robustness_pct'],
                color='red', linestyle='--', linewidth=1.5, alpha=0.7
            )
        elif metric == 'Performance_Loss':
            ax.axhline(
                y=WARNING_THRESHOLDS['performance_loss_pct'],
                color='red', linestyle='--', linewidth=1.5, alpha=0.7
            )

        ax.set_xlabel('Battery-EV Dependency (BED)', fontweight='bold')
        ax.set_ylabel(y_label, fontweight='bold')
        ax.set_title(f'({chr(97 + idx)}) {title}', fontweight='bold', loc='left')
        ax.grid(True, linestyle='--', alpha=0.3, zorder=0)
        ax.set_axisbelow(True)

    # Row 2: Scenario comparison by year
    bed_data = get_bed_scenarios()
    years = bed_data['years']
    bed_cons = bed_data['conservative']
    bed_opt = bed_data['optimistic']

    scenario_metrics: Dict[float, Dict[str, Dict[str, np.ndarray]]] = {}
    for intensity in shock_intensities:
        scenario_metrics[intensity] = {
            'conservative': interpolate_metrics(results_df, bed_cons, intensity),
            'optimistic': interpolate_metrics(results_df, bed_opt, intensity),
        }

    for idx, (metric, title, y_label) in enumerate(metrics):
        ax = fig.add_subplot(gs[1, idx])

        for intensity in shock_intensities:
            for scenario, style in SCENARIO_STYLES.items():
                y_vals = scenario_metrics[intensity][scenario][metric]
                ax.plot(
                    years,
                    y_vals,
                    color=SHOCK_COLORS.get(intensity, '#666666'),
                    linestyle=style['linestyle'],
                    marker=style['marker'],
                    markersize=4,
                    linewidth=1.8,
                    zorder=3
                )

        # Warning lines for (e)(f)(g)
        if metric == 'failed_nodes_shock':
            ax.axhline(
                y=WARNING_THRESHOLDS['failed_nodes_pct'],
                color='red', linestyle='--', linewidth=1.5, alpha=0.7
            )
        elif metric == 'Robustness':
            ax.axhline(
                y=WARNING_THRESHOLDS['robustness_pct'],
                color='red', linestyle='--', linewidth=1.5, alpha=0.7
            )
        elif metric == 'Performance_Loss':
            ax.axhline(
                y=WARNING_THRESHOLDS['performance_loss_pct'],
                color='red', linestyle='--', linewidth=1.5, alpha=0.7
            )

        ax.set_xlabel('Year', fontweight='bold')
        ax.set_ylabel(y_label, fontweight='bold')
        ax.set_title(f'({chr(101 + idx)}) {title}', fontweight='bold', loc='left')
        ax.set_xticks(years)
        ax.set_xticklabels([str(y) for y in years], rotation=45, ha='right')
        ax.grid(True, linestyle='--', alpha=0.3, zorder=0)
        ax.set_axisbelow(True)

    # Unified legend
    legend_handles = [
        Line2D([0], [0], color=SHOCK_COLORS.get(0.4, '#666666'), lw=2.0, label=SHOCK_LABELS.get(0.4, 'Shock 40%')),
        Line2D([0], [0], color=SHOCK_COLORS.get(0.6, '#666666'), lw=2.0, label=SHOCK_LABELS.get(0.6, 'Shock 60%')),
        Line2D([0], [0], color=SHOCK_COLORS.get(0.8, '#666666'), lw=2.0, label=SHOCK_LABELS.get(0.8, 'Shock 80%')),
        Line2D([0], [0], color='red', lw=1.5, linestyle='--', label='Warning'),
        Line2D([0], [0], color='black', lw=2.0, linestyle='-', marker='s', label='Conservative'),
        Line2D([0], [0], color='black', lw=2.0, linestyle='--', marker='o', label='Optimistic'),
    ]

    fig.legend(
        handles=legend_handles,
        loc='lower center',
        bbox_to_anchor=(0.5, -0.04),
        ncol=6,
        frameon=True,
        framealpha=0.95,
        edgecolor='#333333',
        fancybox=False
    )

    plt.tight_layout(rect=[0, 0.06, 1, 1])

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    png_file = output_path / 'combined_resilience_analysis_2x4.png'
    pdf_file = output_path / 'combined_resilience_analysis_2x4.pdf'

    fig.savefig(png_file, dpi=300, bbox_inches='tight')
    fig.savefig(pdf_file, bbox_inches='tight')
    plt.close(fig)

    return png_file, pdf_file


def main() -> None:
    """CLI entry."""
    paths = PathConfig()
    results_file = paths.get_results_file('battery_chain_resilience_results_sensitivity.csv')

    if not results_file.exists():
        raise FileNotFoundError(f"Results file not found: {results_file}")

    results_df = pd.read_csv(results_file, encoding='utf-8-sig')
    plot_combined_resilience_analysis(
        results_df=results_df,
        output_dir=str(paths.results_figures_dir),
        shock_intensities=[0.4, 0.6, 0.8]
    )


if __name__ == '__main__':
    main()
