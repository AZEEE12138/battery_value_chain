"""复用已有仿真，生成申诉用图和可追溯表；不调用仿真入口。"""
import ast
import csv
import json
from hashlib import sha256
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'NC-appeal/evidence_revision_20260930'
DATA = OUT / 'figure_source_data'
ASSETS = OUT / 'source_assets'
QA = ROOT / 'logs/nc_evidence_revision_20260930'
RAW = ROOT / 'new/data/output/results_data'
OLD_FIG = ROOT / 'new/rusult/figure/figures'
SCAN = ROOT / 'new/rusult/report/appeal_smoke_tests'
sys.path.insert(0, str(ROOT/'new/experiment/scripts/visualization/resilience'))
from visualize_combined_resilience_analysis import _fit_quadratic_and_smooth, _smooth_lowess, _normalize_values, SMOOTH_FRAC

COLORS = {0.4:'#287D8E', 0.6:'#B1841A', 0.8:'#BB3C49'}
METRICS = ['Robustness','Performance_Loss','Recovery_Rate']
LABELS = ['Robustness (%)','Normalized performance loss (%)','Normalized recovery rate (%)']
plt.rcParams.update({'font.family':'Arial','font.size':9,'pdf.fonttype':42,'ps.fonttype':42})


def save(fig, name):
    for ext in ['png','pdf']:
        fig.savefig(ASSETS/f'{name}.{ext}', dpi=300, bbox_inches='tight', facecolor='white')
    plt.close(fig)


def audit_metrics(df):
    maxima = {m:0. for m in METRICS}
    for r in df.itertuples():
        t=np.asarray(ast.literal_eval(r.complete_trajectory)); emin=t.min(); tr=t.argmin(); te=len(t)-1
        expected=[emin/t[0],np.maximum(t[0]-t,0).sum(),(t[-1]-emin)/(te-tr) if te>tr else 0.]
        for m,v in zip(METRICS,expected):
            maxima[m]=max(maxima[m],abs(getattr(r,m)-v)/max(1,abs(v)))
    assert max(maxima.values()) < 1e-10, maxima
    return maxima


def response_curves(df):
    rng=np.random.default_rng(20260930)
    curves={}; rows=[]; point_differences={}
    for shock in COLORS:
        part=df[df.shock_intensity==shock]; groups=list(part.groupby('BED_target',sort=True))
        x=np.array([k for k,g in groups]); n=np.array([len(g) for k,g in groups]); es0=part.ES_0.mean()
        assert np.all(n==200), n
        design=np.stack([x*x,x,np.ones_like(x)],axis=1)
        inverse=np.linalg.pinv(design)
        boot=np.empty((1000,len(x),3))
        for j,(_,g) in enumerate(groups):
            values=np.column_stack([_normalize_values(g[m].to_numpy(),m,es0) for m in METRICS])
            indices=rng.integers(0,len(g),size=(1000,len(g)))
            boot[:,j,:]=values[indices].mean(axis=1)
        for mi,m in enumerate(METRICS):
            xd,mean=_fit_quadratic_and_smooth(part.BED_target.to_numpy(),_normalize_values(part[m].to_numpy(),m,es0),frac=SMOOTH_FRAC[m])
            # 原平滑器对y为线性算子，作用于三个多项式基底等价于逐条拟合平滑。
            basis=np.stack([_smooth_lowess(xd,v,frac=SMOOTH_FRAC[m]) for v in [xd*xd,xd,np.ones_like(xd)]],axis=0)
            predictions=(boot[:,:,mi]@inverse.T)@basis
            lo,hi=np.quantile(predictions,[.025,.975],axis=0)
            grouped=np.array([_normalize_values(g[m].to_numpy(),m,es0).mean() for _,g in groups])
            difference=float(np.max(np.abs((inverse@grouped)@basis-mean)))
            assert difference<1e-8
            point_differences[f'{shock}_{m}']=difference
            curves[shock,m]=(xd,mean,lo,hi)
            for vals in zip(xd,mean,lo,hi):
                rows.append(dict(shock=shock,metric=m,BED=vals[0],estimate=vals[1],ci_lower=vals[2],ci_upper=vals[3],bootstrap_resamples=1000))
        print('曲线与bootstrap完成',shock,flush=True)
    pd.DataFrame(rows).to_csv(DATA/'Figure_3_response_curves.csv',index=False)
    return curves,point_differences


def annual_inputs():
    p=ROOT/'new/data/input/inputs/zhanbi.csv'
    original=pd.read_csv(p,sep='\t',encoding='utf-8-sig')
    table=original.iloc[:,:3].copy();table.columns=['year','optimistic_pct','conservative_pct']
    table['status']=np.where(table.year<=2025,'historical mixed-source proxy; not independently calibrated','assigned scenario input; not a forecast validation')
    table.to_csv(DATA/'Annual_BED_inputs.csv',index=False)
    from openpyxl import load_workbook
    w=load_workbook(ROOT/'new/data/input/inputs/bed_year.xlsx',read_only=True,data_only=True)
    values=list(w.active.values)
    inputs=[]
    for year,total,power,source in values[1:]:
        inputs.append({'year':year,'total_in_workbook':total,'power_in_workbook':power,'ratio_pct':100*power/total if total and power else None,'archived_source_note':source,'verification':'archived inputs, not an independent source audit'})
    pd.DataFrame(inputs).to_csv(QA/'annual_workbook_provenance.csv',index=False,encoding='utf-8-sig')
    return table


def main_figure(curves,annual):
    fig=plt.figure(figsize=(12,13))
    gs=fig.add_gridspec(4,3,height_ratios=[1,1,1.05,1.05],hspace=.46,wspace=.36)
    mapped=[]; crossing={}
    for mi,m in enumerate(METRICS):
        ax=fig.add_subplot(gs[0,mi]); by=fig.add_subplot(gs[1,mi])
        for shock,color in COLORS.items():
            x,y,lo,hi=curves[shock,m]
            ax.plot(x,y,color=color,lw=1.6);ax.fill_between(x,lo,hi,color=color,alpha=.18)
            a=annual[annual.year>=2026]
            for scenario,ls in [('conservative','--'),('optimistic','-')]:
                yyear=np.interp(a[f'{scenario}_pct']/100,x,y)
                by.plot(a.year,yyear,color=color,ls=ls,lw=1.6,marker='s' if scenario=='conservative' else 'o',ms=2.8)
                for year,bed,value in zip(a.year,a[f'{scenario}_pct']/100,yyear):
                    mapped.append(dict(year=int(year),scenario=scenario,BED=bed,shock=shock,metric=m,estimate=value))
                if shock==.8:
                    good=yyear>=50 if m=='Robustness' else yyear<=100*20/51 if m=='Performance_Loss' else np.zeros(len(yyear),bool)
                    crossing[f'{scenario}_{m}']=int(a.year.to_numpy()[np.flatnonzero(good)[0]]) if good.any() else None
            if mi<2:
                for aa in [ax,by]:aa.axhline(50 if mi==0 else 100*20/51,color='#666666',ls=':',lw=1)
        for aa,panel in [(ax,chr(97+mi)),(by,chr(100+mi))]:
            aa.set_title(panel,loc='left',fontweight='bold');aa.set_ylabel(LABELS[mi]);aa.grid(alpha=.18)
            aa.spines[['top','right']].set_visible(False)
        ax.set_xlabel('Battery-EV dependence (BED)');by.set_xlabel('Scenario year')
        by.set_xticks([2026,2029,2032,2035]);ax.set_xlim(.3,.9)
    handles=[Line2D([0],[0],color=c,lw=2,label=f'{int(s*100)}% shock') for s,c in COLORS.items()]
    handles += [Line2D([0],[0],color='#444444',ls='--',label='Conservative'),Line2D([0],[0],color='#444444',label='Optimistic')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.51,.93),ncol=5,frameon=False)
    paths=[]
    for j,(scenario,shock) in enumerate((s,q) for s in ['optimistic','conservative'] for q in [40,60,80]):
        p=RAW/f'cascade_main_path_2030_{scenario}_shock{shock}_representative_similar_unique.json'
        metadata=json.loads(p.read_text(encoding='utf-8'))
        expected=float(annual.loc[annual.year==2030,f'{scenario}_pct'].iloc[0]/100)
        assert abs(metadata['bed_target']-expected)<1e-12
        paths.append(metadata)
        ax=fig.add_subplot(gs[2+j//3,j%3]);ax.set_axis_off()
        picture=OLD_FIG/f'cascade_main_path_2030_{scenario}_shock{shock}_representative_similar_unique.png'
        picture_image=Image.open(picture)
        # 仅去掉旧面板标题的上边距，网络数据、节点和路径保持原图。
        picture_image=picture_image.crop((0,int(picture_image.height*.08),picture_image.width,picture_image.height))
        ax.imshow(picture_image);ax.set_title(f'{chr(103+j)}  {scenario.title()}, {shock}% shock',loc='left',fontsize=9,fontweight='bold')
    fig.text(.5,.052,'Network edges: grey; failure path and failed nodes: red; upstream: blue; downstream: green; EV manufacturing: orange.',ha='center',fontsize=8)
    save(fig,'Figure_3')
    pd.DataFrame(mapped).to_csv(DATA/'Figure_3_annual_mapping.csv',index=False)
    (DATA/'Figure_3_path_records.json').write_text(json.dumps(paths,indent=2),encoding='utf-8')
    return crossing


def annual_figure(annual):
    fig,ax=plt.subplots(figsize=(8,4.2));h=annual[annual.year<=2025];a=annual[annual.year>=2025]
    ax.plot(h.year,h.optimistic_pct,'o-',color='#555555',label='Historical proxy')
    ax.plot(a.year,a.conservative_pct,'s--',color='#287D8E',label='Conservative scenario')
    ax.plot(a.year,a.optimistic_pct,'^-',color='#BB3C49',label='Optimistic scenario')
    ax.axvline(2025,color='#777777',ls=':',lw=1);ax.set(xlabel='Year',ylabel='Assigned BED input (%)',xticks=[2015,2020,2025,2030,2035])
    ax.legend(frameon=False,fontsize=9);ax.grid(alpha=.2);save(fig,'Supplementary_Figure_1')


def phase_figure():
    df=pd.read_csv(SCAN/'phase_diagram_tau_beta_multishock_production.csv')
    df['degenerate_grid']=np.isclose(df.bed_grid_lo,df.bed_grid_hi)
    df['grid_scope']='adaptive window only'
    df['estimate_type']='first mean-robustness crossing of 50%; not logistic midpoint'
    df=df.rename(columns={'critical_BED_empirical':'critical_BED_simulated'})
    df.to_csv(DATA/'Supplementary_Figure_2_phase_grid.csv',index=False)
    fig=plt.figure(figsize=(10,7.4));gs=fig.add_gridspec(2,3,height_ratios=[1,1],hspace=.60,wspace=.36)
    betas=sorted(df.beta.unique());taus=sorted(df.tau.unique())
    for col,shock in enumerate(COLORS):
        ax=fig.add_subplot(gs[0,col]);a=np.full((5,3),np.nan)
        sub=df[df.shock==shock]
        for r in sub.itertuples():
            iy=taus.index(r.tau);ix=betas.index(r.beta)
            if not r.degenerate_grid:a[iy,ix]=r.critical_BED_simulated
        im=ax.imshow(a,vmin=0,vmax=1,cmap='viridis',origin='lower',aspect='auto')
        for r in sub.itertuples():
            iy=taus.index(r.tau);ix=betas.index(r.beta)
            if r.degenerate_grid:
                ax.add_patch(Rectangle((ix-.5,iy-.5),1,1,fc='#dddddd',hatch='///',ec='#aaaaaa'));label='D'
            elif pd.notna(r.critical_BED_simulated):label=f'{r.critical_BED_simulated:.2f}'
            else:label='NC'
            ax.text(ix,iy,label,ha='center',va='center',fontsize=9,color='white' if np.isfinite(a[iy,ix]) and a[iy,ix]<.7 else 'black')
        ax.set(xticks=range(3),xticklabels=[str(int(b)) for b in betas],yticks=range(5),yticklabels=[f'{t:.1f}' for t in taus],xlabel='Steepness',ylabel='Failure threshold')
        ax.set_title(f'{chr(97+col)}  {int(shock*100)}% shock',loc='left',fontweight='bold')
    cb=fig.colorbar(im,ax=fig.axes[:3],shrink=.8,pad=.015);cb.set_label('Simulated critical BED')
    ax=fig.add_subplot(gs[1,:]);v=df[~df.degenerate_grid].sort_values('spearman_rho_BED_vs_Robustness')
    for shock,color in COLORS.items():
        mask=v.shock==shock;ax.scatter(np.flatnonzero(mask)+1,v.loc[mask,'spearman_rho_BED_vs_Robustness'],color=color,label=f'{int(shock*100)}% shock',s=24)
    ax.set(xlabel='Parameter setting ranked by correlation',ylabel='Spearman correlation',ylim=(-1.05,.05));ax.axhline(0,color='#888888',lw=1);ax.grid(alpha=.2)
    ax.set_title('d  Direction of the BED-robustness relationship',loc='left',fontweight='bold');ax.legend(frameon=False,ncol=3)
    fig.text(.12,.485,'NC: no downward crossing in the sampled window. D: all BED inputs equal 0.97; not an identifiable scan.',fontsize=9)
    save(fig,'Supplementary_Figure_2')
    return {'settings':len(df),'crossings':int(df.critical_BED_simulated.notna().sum()),'degenerate':int(df.degenerate_grid.sum()),'defined_correlations':int(df.spearman_rho_BED_vs_Robustness.notna().sum())}


def main():
    for p in [DATA,ASSETS,QA]:p.mkdir(parents=True,exist_ok=True)
    source=RAW/'battery_chain_resilience_results_sensitivity.csv';df=pd.read_csv(source)
    audit={'raw_rows':len(df),'metric_relative_error':audit_metrics(df)}
    curves,diff=response_curves(df);audit['preserved_curve_max_difference']=diff
    annual=annual_inputs();audit['annual_first_warning_satisfaction']=main_figure(curves,annual)
    annual_figure(annual);audit['phase']=phase_figure()
    audit['research_simulation_runs_added']=0
    audit['source_hashes']={str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in [source,ROOT/'new/data/input/inputs/zhanbi.csv',SCAN/'phase_diagram_tau_beta_multishock_production.csv']}
    (QA/'evidence_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps(audit,indent=2),flush=True)


if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');main()
