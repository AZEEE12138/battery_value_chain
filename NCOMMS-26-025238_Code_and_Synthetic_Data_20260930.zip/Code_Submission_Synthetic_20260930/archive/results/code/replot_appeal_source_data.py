"""Regenerate numerical panels from distributed estimates; this does not run the model.

Usage: python replot_appeal_source_data.py [directory containing the CSV files]
Requires: numpy, pandas, matplotlib.
"""
from pathlib import Path
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Rectangle


def main():
    root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
    out=root/'replotted';out.mkdir(exist_ok=True)
    curves=pd.read_csv(root/'Figure_3_response_curves.csv')
    annual=pd.read_csv(root/'Figure_3_annual_mapping.csv')
    colors={.4:'#287D8E',.6:'#B1841A',.8:'#BB3C49'}
    metrics=['Robustness','Performance_Loss','Recovery_Rate']
    labels=['Robustness (%)','Normalized performance loss (%)','Normalized recovery rate (%)']
    plt.rcParams.update({'font.size':9,'pdf.fonttype':42})
    fig,axes=plt.subplots(2,3,figsize=(12,7),layout='constrained')
    for j,m in enumerate(metrics):
        for s,c in colors.items():
            t=curves[(curves.shock==s)&(curves.metric==m)]
            axes[0,j].plot(t.BED,t.estimate,color=c,label=f'{int(100*s)}% shock')
            axes[0,j].fill_between(t.BED,t.ci_lower,t.ci_upper,color=c,alpha=.18)
            for scenario,style in [('conservative','--'),('optimistic','-')]:
                a=annual[(annual.shock==s)&(annual.metric==m)&(annual.scenario==scenario)]
                assert np.allclose(a.estimate,np.interp(a.BED,t.BED,t.estimate))
                axes[1,j].plot(a.year,a.estimate,style,color=c)
        for i in range(2):
            ax=axes[i,j];ax.set_ylabel(labels[j]);ax.set_title(chr(97+3*i+j),loc='left')
            ax.set_xlabel('BED' if i==0 else 'Scenario year');ax.grid(alpha=.2)
            if j<2:ax.axhline(50 if j==0 else 100*20/51,color='#666666',ls=':')
    axes[0,0].legend(frameon=False)
    fig.savefig(out/'Figure_3a-f.pdf');plt.close(fig)
    a=pd.read_csv(root/'Annual_BED_inputs.csv');h=a[a.year<=2025];p=a[a.year>=2025]
    fig,ax=plt.subplots(figsize=(8,4),layout='constrained')
    ax.plot(h.year,h.optimistic_pct,'o-',label='Historical proxy',color='#555555')
    ax.plot(p.year,p.conservative_pct,'s--',label='Conservative',color=colors[.4])
    ax.plot(p.year,p.optimistic_pct,'^-',label='Optimistic',color=colors[.8])
    ax.set(xlabel='Year',ylabel='Assigned BED input (%)');ax.legend(frameon=False)
    fig.savefig(out/'Supplementary_Figure_1.pdf');plt.close(fig)
    t=pd.read_csv(root/'Supplementary_Figure_2_phase_grid.csv')
    fig=plt.figure(figsize=(10,7),layout='constrained');grid=fig.add_gridspec(2,3)
    top=[];tau=sorted(t.tau.unique());beta=sorted(t.beta.unique())
    for k,(s,c) in enumerate(colors.items()):
        ax=fig.add_subplot(grid[0,k]);top.append(ax);a=t[t.shock==s];z=np.full((5,3),np.nan)
        for r in a.itertuples():
            if not r.degenerate_grid:z[tau.index(r.tau),beta.index(r.beta)]=r.critical_BED_simulated
        im=ax.imshow(z,vmin=0,vmax=1,origin='lower',aspect='auto',cmap='viridis')
        for r in a.itertuples():
            x=beta.index(r.beta);y=tau.index(r.tau)
            if r.degenerate_grid:
                ax.add_patch(Rectangle((x-.5,y-.5),1,1,fc='#dddddd',hatch='///'));label='D'
            else:label=f'{r.critical_BED_simulated:.2f}' if np.isfinite(r.critical_BED_simulated) else 'NC'
            ax.text(x,y,label,ha='center',va='center',color='white' if np.isfinite(z[y,x]) and z[y,x]<.7 else 'black')
        ax.set(xticks=range(3),xticklabels=beta,yticks=range(5),yticklabels=tau,xlabel='Steepness',ylabel='Failure threshold')
        ax.set_title(f'{chr(97+k)}  {int(100*s)}% shock',loc='left')
    fig.colorbar(im,ax=top,label='Simulated critical BED')
    ax=fig.add_subplot(grid[1,:]);v=t[~t.degenerate_grid].sort_values('spearman_rho_BED_vs_Robustness')
    for s,c in colors.items():
        mask=v.shock==s;ax.scatter(np.flatnonzero(mask)+1,v.loc[mask,'spearman_rho_BED_vs_Robustness'],color=c)
    ax.set(xlabel='Ranked setting',ylabel='Spearman correlation',ylim=(-1.05,.05));ax.set_title('d',loc='left')
    fig.savefig(out/'Supplementary_Figure_2.pdf');plt.close(fig)
    print('Replotted 6 main numerical panels and 2 supplementary figures; annual interpolation verified.')


if __name__=='__main__':main()
