# Battery Value-Chain Resilience: Review Code Package

Manuscript: **EV lock-in erodes the resilience of China's battery value chain**  
Manuscript ID: **NCOMMS-26-025238A-Z**

## Scope

This package supplies the available archived research scripts, a portable entry point,
fresh synthetic inputs, and a reconstructed example environment. It supports code
inspection and execution of the archived baseline algorithm without confidential data.

**No empirical adjacency matrix or original transaction records are included.** The
108-node, 739-edge matrix is independently generated synthetic data, not a de-identified,
resampled or perturbed version of the empirical graph. Matching dimensions do not imply
matching topology, weights, sector identities or paper results. The archived study inputs
remain commercially restricted under the manuscript's availability statement.

The historical environment was not recovered. `uv.lock`, `requirements.lock` and
`validation/environment.json` identify a **reconstructed, tested example environment**,
not the package versions originally used to generate the paper. The archived code
snapshot is identified by hashes, not claimed to be the exact version of every historical run.

## Quick Start

Python 3.12 is required. From this directory, with `uv` installed:

```bash
uv sync --frozen
uv run --frozen python run.py verify-manifest
uv run --frozen python -m unittest discover -s tests -v
uv run --frozen python run.py smoke
```

The smoke test runs nine synthetic cases and repeats one case to check deterministic
execution. It writes metrics, complete 51-point trajectories, a synthetic BED plot,
environment details and a validation report to `outputs/`. The wrapper starts its
simulation process with `PYTHONHASHSEED=0` and uses the archived `42 + simulation_id`
Python/NumPy seed scheme. These checks are software validation, not new empirical results.

An alternative installation route using an isolated Python 3.12 environment:

```bash
python -m venv .venv
# Activate the environment using the command appropriate for your operating system.
python -m pip install --require-hashes -r requirements.lock
python run.py smoke
```

Windows PowerShell activation: `.\.venv\Scripts\Activate.ps1`.  
Linux/macOS activation: `source .venv/bin/activate`.

The lock file includes exact direct and transitive dependency versions and distribution
hashes. Internet access is needed for installation; wheel files are not bundled. Runtime
simulations do not use the network. Dockerfile is an optional environment recipe and is
not evidence of a tested historical container or a validated Linux run.

## Other Commands

```bash
# Regenerate only synthetic input files from the documented generator seed.
uv run --frozen python scripts/generate_synthetic.py

# A larger illustrative scan; this is still not the empirical paper scan.
uv run --frozen python run.py bed-scan --beds 0.3,0.4,0.5,0.6,0.7,0.8,0.9 --repeats 5

# Record the current example environment.
uv run --frozen python run.py environment
```

The wrapper restricts BED to 0.03-0.94 to avoid special legacy boundary branches. Inspect
the archived code before extending that range. Do not change parameters to force a
particular threshold or interpret a synthetic transition as the paper's estimate.

## Contents

| Location | Meaning |
| --- | --- |
| `data/nodes_synthetic.csv` | Synthetic node attributes in the archived engine's schema |
| `data/edges_synthetic.csv` | Fresh synthetic directed edges and arbitrary positive weights |
| `data/adjacency_synthetic.csv` | Full 108 by 108 synthetic weighted adjacency matrix |
| `data/node_order.json` | Common row/column order for the matrix |
| `config/example_parameters.json` | Explicit example parameters, seed scheme and provenance labels |
| `scripts/generate_synthetic.py` | Generator; never opens empirical files |
| `run.py` | Portable synthetic baseline simulation/scan entry point |
| `archive/` | Byte-preserved available research scripts for inspection |
| `tests/` | Input, matrix, rewiring and implementation-contract tests |
| `validation/` | Executed test evidence from the reconstructed environment |
| `PROVENANCE.json` | Source hashes and data/environment scope |
| `SHA256SUMS.txt` | Package file-integrity manifest |

## Algorithm and Reproduction Boundary

The wrapper calls `archive/new/experiment/experiments/run_resilience_simulation.py`
directly. Its core dependency is `src/core/ev_shock_recovery.py`. It does not substitute
the earlier public demo's priority-free probabilistic recovery rule.

- The archived baseline uses five shock updates and 45 recovery updates.
- One eligible failed node is selected per recovery update by priority, with a secondary
  score used for ties; that score is not a Bernoulli trial in this branch.
- Raw robustness is minimum performance divided by initial performance. Raw recovery
  rate is the slope from the first minimum to the final state. Loss sums positive
  performance shortfalls over 51 stored observations.
- The public synthetic repository inspected for this revision uses a different simplified
  recovery implementation. This package preserves the available research branch instead.

`IMPLEMENTATION_NOTES.md` records a legacy attribute-name mismatch and other boundaries.
We preserve, document and test these behaviours rather than silently change the engine.
Archived headers/docstrings are retained as provenance; executed code and the implementation
notes take precedence where legacy prose differs.

The archive contains additional phase-scan, warning-line, counterfactual, policy and plotting
scripts. These are **inspection sources, not commands guaranteed to run with synthetic
inputs**: they reference study-specific files and sector identifiers excluded here. Some
legacy plotting scripts contain superseded uncertainty treatment. Their presence is not
an instruction to regenerate revised figures with that method. The supported, tested
entry points are the commands listed above. The complete 87-edge empirical decomposition,
original edge-screening decisions and all paper figures are not independently reproduced.

## Data Access and Rights

Requests for restricted empirical inputs must be made to the corresponding author,
subject to the data provider's conditions. This package does not grant access to those
records or imply that empirical reproducibility concerns have been fully resolved.

The code and synthetic files are supplied for editorial and peer-review inspection.
No new public licence for archived research code or proprietary derived data is asserted
by this package; public redistribution requires the rights holder's authorization.
