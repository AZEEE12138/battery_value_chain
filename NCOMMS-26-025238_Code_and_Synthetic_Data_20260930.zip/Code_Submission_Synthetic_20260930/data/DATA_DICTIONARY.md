# Synthetic Data Dictionary

All values in the supplied network tables and matrix are synthetic. The generator reads
only the package's example configuration, not empirical files or empirical statistics
apart from the publicly stated dimensions of 108 nodes and 739 edges.

- `Industry_Code`, `Node_Code`, `Id`: node identifier strings. The two role IDs are retained
  solely for compatibility with constants in the archived engine.
- `Node_Name`, `Abbreviation`: generated labels. Material keywords exercise the classifier.
- `Out_Degree`, `In_Degree`: degrees calculated from the synthetic edge list.
- `Out_Weight`, `In_Weight`, `Total_Weight`: arbitrary synthetic weight totals; not currency,
  physical production or original transaction values. See the implementation note about
  the graph builder's lower-case attribute storage.
- `Source_Code`, `Source`: supplier/origin node. `Target_Code`, `Target`: recipient node.
- `Weight`: strictly positive arbitrary synthetic edge weight. Duplicate directed pairs
  and self-loops are absent. Zero in the matrix means no directed edge.
- `Transactions`: constant illustrative value 1; not a transaction count from source data.
- `Data_Origin`: literal `SYNTHETIC` on every node and edge record.

In `adjacency_synthetic.csv`, rows are origins and columns are destinations. The first
column is the row identifier. Both axis orders are given by `node_order.json`.
The matrix contains exactly the same weights as `edges_synthetic.csv`; this equivalence
is checked in the tests. The seed is 20260930 and the initial synthetic BED is 0.55.
