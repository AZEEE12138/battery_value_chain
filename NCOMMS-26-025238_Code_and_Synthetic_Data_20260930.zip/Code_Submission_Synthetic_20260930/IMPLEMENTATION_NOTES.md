# Implementation Notes

## Preserved Attribute-Name Mismatch

The archived `cascade_failure.build_network_from_data` reads CSV `Total_Weight` but
stores it on the NetworkX node as `total_weight`. The recovery priority function reads
`Total_Weight`, defaulting to zero if absent. Thus the weight-priority component is
inactive for graphs built by this archived baseline entry point, although the general
priority function includes a weight term when the upper-case attribute is supplied.

The package does not rename that attribute or silently activate the term. A unit test
records the behaviour. This should be taken into account when describing equation (11).
Other graph constructors and historical code versions require separate checking.

## Additional Boundaries

- Material classification uses keywords in node-name attributes. A subset of synthetic
  labels includes the literal material keyword to exercise that branch. These are generated
  labels, not disclosures of real sector identities.
- `36901` and `37111` are compatibility role identifiers required by the archived entry
  point. All other node identifiers are fresh synthetic codes. No empirical edge is copied.
- Reweighting conserves the battery outgoing total and total graph weight over the tested
  BED range, not each recipient node's incoming strength.
- The archived priority function caches a maximum weight when upper-case `Total_Weight`
  attributes are present. The supplied baseline builder does not activate that branch.
  Multi-graph use with a different constructor needs its own cache-scope audit.
- Hash-seed control is added by the wrapper for a reproducible example. Historical
  cross-process hash ordering is not known, so matching random seeds alone cannot prove
  exact reproduction of historical trajectories.
- The default validation performs synthetic runs only. It does not validate a commercial
  data licence, historical results, empirical threshold, annual calibration, or all archived
  auxiliary scripts.
