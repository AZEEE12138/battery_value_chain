"""Portable entry point to the archived engine, using synthetic inputs only by default."""
import argparse
import csv
from hashlib import sha256
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def load():
    import pandas as pd
    engine=ROOT/'archive/new/experiment'
    sys.path.insert(0,str(engine/'experiments'));sys.path.insert(0,str(engine))
    from run_resilience_simulation import run_single_simulation
    nodes=pd.read_csv(ROOT/'data/nodes_synthetic.csv',dtype={'Industry_Code':str,'Node_Code':str,'Id':str})
    edges=pd.read_csv(ROOT/'data/edges_synthetic.csv',dtype={'Source_Code':str,'Target_Code':str,'Source':str,'Target':str})
    assert set(nodes.Data_Origin)=={'SYNTHETIC'} and set(edges.Data_Origin)=={'SYNTHETIC'}
    config=json.loads((ROOT/'config/example_parameters.json').read_text())
    keys=['shock_steps','recovery_steps','bankruptcy_threshold','steepness','max_cascade_rounds','p_recover','recovery_threshold','noise_level']
    return nodes,edges,run_single_simulation,{k:config[k] for k in keys}


def serial(value):
    import numpy as np
    if isinstance(value,dict):return {str(k):serial(v) for k,v in value.items()}
    if isinstance(value,(list,tuple,set)):return [serial(v) for v in value]
    if isinstance(value,np.generic):return value.item()
    return value


def metric_check(r):
    import numpy as np
    t=np.asarray(r['complete_trajectory']);i=int(t.argmin())
    checks={'Robustness':t.min()/t[0], 'Recovery_Rate':(t[-1]-t[i])/(50-i) if i<50 else 0,
            'Performance_Loss':np.maximum(t[0]-t,0).sum()}
    assert len(t)==51 and np.all(np.isfinite(t))
    for key,value in checks.items():assert np.isclose(r[key],value,rtol=1e-10,atol=1e-9),(key,r[key],value)


def simulate(beds,shocks,repeats):
    nodes,edges,engine,config=load();rows=[]
    for bed in beds:
        for shock in shocks:
            for rep in range(repeats):
                r=engine(nodes,edges,bed,rep,shock_intensity=shock,**config)
                metric_check(r);rows.append(serial(r))
                print(f'Completed {len(rows)}/{len(beds)*len(shocks)*repeats}',flush=True)
    return rows


def environment():
    dependencies=['numpy','pandas','scipy','networkx','matplotlib','seaborn','openpyxl','tqdm','statsmodels','PyYAML']
    return {'environment_kind':'reconstructed example, not a recovered historical environment',
            'python':platform.python_version(),'platform':platform.platform(),'python_hash_seed':os.environ.get('PYTHONHASHSEED'),
            'implementation':platform.python_implementation(),'architecture':platform.machine(),
            'packages':{p:importlib.metadata.version(p) for p in dependencies},
            'all_installed_distributions':dict(sorted((d.metadata['Name'],d.version) for d in importlib.metadata.distributions()))}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['smoke','bed-scan','environment','verify-manifest'])
    p.add_argument('--beds',default='0.35,0.55,0.75');p.add_argument('--shocks',default='0.4,0.6,0.8')
    p.add_argument('--repeats',type=int,default=1);p.add_argument('--out',default='outputs')
    args=p.parse_args()
    out=ROOT/args.out;out.mkdir(parents=True,exist_ok=True)
    if args.command=='verify-manifest':
        for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
            digest,name=line.split('  ',1);assert sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
        print('Manifest verified');return
    env=environment();(out/'environment.json').write_text(json.dumps(env,indent=2),encoding='utf-8')
    if args.command=='environment':print(json.dumps(env,indent=2));return
    beds=list(map(float,args.beds.split(',')));shocks=list(map(float,args.shocks.split(',')))
    assert all(.03<=x<=.94 for x in beds),'Example wrapper restricts BED away from legacy edge-case branches.'
    assert all(0<s<1 for s in shocks) and args.repeats>0
    rows=simulate(beds,shocks,args.repeats)
    if args.command=='smoke':
        a=simulate([beds[0]],[shocks[0]],1)[0]
        assert a==rows[0],'Seeded within-process result did not repeat'
    (out/'simulation_records.json').write_text(json.dumps(rows,indent=2,ensure_ascii=True),encoding='utf-8')
    keys=['BED_target','BED_achieved','shock_intensity','simulation_id','Robustness','Recovery_Rate','Performance_Loss','ES_0']
    with (out/'metrics_synthetic.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows({k:r.get(k) for k in keys} for r in rows)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import pandas as pd
    t=pd.DataFrame(rows);fig,ax=plt.subplots(figsize=(6,4),layout='constrained')
    for shock,group in t.groupby('shock_intensity'):
        a=group.groupby('BED_target').Robustness.mean();ax.plot(a.index,a.values,'o-',label=f'{shock:.0%} shock')
    ax.set(xlabel='Assigned BED',ylabel='Mean model robustness',title='Synthetic example only');ax.legend(frameon=False)
    fig.savefig(out/'bed_scan_synthetic.png',dpi=180);plt.close(fig)
    report={'dataset':'fully synthetic','metric_checks':'passed','runs':len(rows),
            'repeat_check':args.command=='smoke','empirical_reproduction':False,'historical_environment_recovered':False}
    (out/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    if os.environ.get('PYTHONHASHSEED')!='0':
        env=os.environ.copy();env['PYTHONHASHSEED']='0';env['PYTHONIOENCODING']='utf-8'
        raise SystemExit(subprocess.call([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]],env=env))
    sys.stdout.reconfigure(encoding='utf-8');main()
